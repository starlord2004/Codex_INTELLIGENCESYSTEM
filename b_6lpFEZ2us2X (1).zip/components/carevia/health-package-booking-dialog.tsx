"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useUser } from "@/contexts/user-context"
import { Calendar, Clock, Mail, Phone, User, CheckCircle, IndianRupee } from "lucide-react"

interface HealthPackage {
  name: string
  price: number
  originalPrice: number
  tests: number
  description?: string
}

interface HealthPackageBookingDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  healthPackage: HealthPackage | null
}

export function HealthPackageBookingDialog({
  open,
  onOpenChange,
  healthPackage,
}: HealthPackageBookingDialogProps) {
  const { user, isLoggedIn, addBooking } = useUser()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [preferredDate, setPreferredDate] = useState("")
  const [preferredTime, setPreferredTime] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState("")

  // Pre-fill with user data if logged in
  useState(() => {
    if (isLoggedIn && user) {
      setName(user.name)
      setEmail(user.email)
      setPhone(user.phone)
    }
  })

  const resetForm = () => {
    if (!isLoggedIn) {
      setName("")
      setEmail("")
      setPhone("")
    }
    setPreferredDate("")
    setPreferredTime("")
    setError("")
    setIsSuccess(false)
  }

  const handleClose = () => {
    resetForm()
    onOpenChange(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!healthPackage) return

    // Validate date is in the future
    const selectedDate = new Date(preferredDate)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    if (selectedDate < today) {
      setError("Please select a future date")
      return
    }

    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Add booking to localStorage
    addBooking({
      packageName: healthPackage.name,
      packagePrice: healthPackage.price,
      userName: name,
      userPhone: phone,
      userEmail: email,
      preferredDate,
      preferredTime,
    })

    setIsLoading(false)
    setIsSuccess(true)
  }

  if (!healthPackage) return null

  // Success state
  if (isSuccess) {
    return (
      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-[425px]">
          <div className="flex flex-col items-center justify-center py-8">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 mb-4">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-xl font-bold text-center mb-2">Booking Confirmed!</h2>
            <p className="text-muted-foreground text-center mb-4">
              Your health package has been booked successfully.
            </p>
            <div className="w-full bg-secondary/50 rounded-lg p-4 space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Package:</span>
                <span className="font-medium">{healthPackage.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Date:</span>
                <span className="font-medium">
                  {new Date(preferredDate).toLocaleDateString("en-IN", {
                    weekday: "short",
                    day: "numeric",
                    month: "short",
                    year: "numeric",
                  })}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Time:</span>
                <span className="font-medium">{preferredTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Amount:</span>
                <span className="font-medium text-primary flex items-center">
                  <IndianRupee className="h-3 w-3" />
                  {healthPackage.price}
                </span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-4 text-center">
              A confirmation has been sent to {email}
            </p>
            <Button className="mt-6 w-full" onClick={handleClose}>
              Done
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Get minimum date (today)
  const today = new Date().toISOString().split("T")[0]

  // Time slots
  const timeSlots = [
    "07:00 AM - 09:00 AM",
    "09:00 AM - 11:00 AM",
    "11:00 AM - 01:00 PM",
    "02:00 PM - 04:00 PM",
    "04:00 PM - 06:00 PM",
  ]

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Book Health Package</DialogTitle>
          <DialogDescription>
            Complete your booking for {healthPackage.name}
          </DialogDescription>
        </DialogHeader>

        {/* Package Summary */}
        <div className="bg-secondary/50 rounded-lg p-4 flex items-center justify-between">
          <div>
            <h3 className="font-semibold">{healthPackage.name}</h3>
            <p className="text-sm text-muted-foreground">
              Includes {healthPackage.tests} tests
            </p>
          </div>
          <div className="text-right">
            <div className="flex items-center text-lg font-bold text-primary">
              <IndianRupee className="h-4 w-4" />
              {healthPackage.price}
            </div>
            <div className="flex items-center text-sm text-muted-foreground line-through">
              <IndianRupee className="h-3 w-3" />
              {healthPackage.originalPrice}
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="space-y-2">
            <Label htmlFor="booking-name">Full Name</Label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="booking-name"
                type="text"
                placeholder="Enter your full name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="pl-10"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="booking-email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="booking-email"
                  type="email"
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="booking-phone">Phone</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="booking-phone"
                  type="tel"
                  placeholder="Phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="booking-date">Preferred Date</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="booking-date"
                  type="date"
                  value={preferredDate}
                  onChange={(e) => setPreferredDate(e.target.value)}
                  min={today}
                  className="pl-10"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="booking-time">Preferred Time</Label>
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <select
                  id="booking-time"
                  value={preferredTime}
                  onChange={(e) => setPreferredTime(e.target.value)}
                  className="w-full h-10 pl-10 pr-3 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  required
                >
                  <option value="">Select time</option>
                  {timeSlots.map((slot) => (
                    <option key={slot} value={slot}>
                      {slot}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {error && (
            <p className="text-sm text-destructive text-center">{error}</p>
          )}

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Booking..." : `Confirm Booking - ₹${healthPackage.price}`}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}
