"use client"

import { useState } from "react"
import { ChevronDown, Search, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"

interface Question {
  id: string
  category: string
  question: string
  answer: string
  views: number
  helpful: number
}

const trendingQuestions: Question[] = [
  {
    id: "1",
    category: "Headache",
    question: "What causes recurring headaches and when should I see a doctor?",
    answer: "Recurring headaches can be caused by stress, tension, migraines, dehydration, or underlying health conditions. You should consult a doctor if: headaches are severe, occur more than 15 days a month, change in pattern, or are accompanied by other symptoms like vision changes or weakness.",
    views: 2543,
    helpful: 1892,
  },
  {
    id: "2",
    category: "Fever",
    question: "How to manage fever at home safely?",
    answer: "To manage fever safely at home: Stay hydrated by drinking water, herbal teas, and warm broths. Use over-the-counter fever reducers like paracetamol or ibuprofen as directed. Rest adequately, avoid strenuous activities. Take lukewarm baths. If fever persists beyond 3 days or exceeds 103°F, consult a doctor.",
    views: 3124,
    helpful: 2756,
  },
  {
    id: "3",
    category: "Cough",
    question: "What's the difference between dry cough and productive cough?",
    answer: "Dry cough produces no mucus and is often caused by allergies, asthma, or post-nasal drip. Productive cough expels mucus or phlegm and indicates your body is fighting an infection. A dry cough lasting more than 3 weeks or a productive cough with colored mucus warrants medical attention.",
    views: 2891,
    helpful: 2234,
  },
  {
    id: "4",
    category: "Body Ache",
    question: "Why do I experience body aches and how to relieve them?",
    answer: "Body aches can result from viral infections, flu, dehydration, stress, or intense exercise. Relief methods include: rest and sleep, staying hydrated, light stretching, warm compresses, over-the-counter pain relievers, and maintaining proper posture. If aches persist beyond 5 days or are severe, seek medical advice.",
    views: 2145,
    helpful: 1678,
  },
  {
    id: "5",
    category: "Sore Throat",
    question: "What are natural remedies for a sore throat?",
    answer: "Natural remedies for sore throat include: gargling with salt water, consuming honey (for adults and children over 1 year), drinking warm herbal teas with ginger or turmeric, using throat lozenges, staying hydrated, and avoiding irritants like smoke. If sore throat persists beyond 10 days or causes difficulty swallowing, consult an ENT specialist.",
    views: 1987,
    helpful: 1456,
  },
  {
    id: "6",
    category: "Nausea",
    question: "What causes nausea and how to treat it?",
    answer: "Nausea can be caused by infections, motion sickness, medication side effects, anxiety, or digestive issues. Treatment includes: sipping water slowly, eating bland foods, avoiding strong smells, resting in a cool environment, ginger or peppermint tea, and acupressure bands. Seek medical help if nausea persists beyond 24 hours or is accompanied by vomiting.",
    views: 1845,
    helpful: 1234,
  },
  {
    id: "7",
    category: "Fatigue",
    question: "What are the common causes of persistent fatigue?",
    answer: "Persistent fatigue can be caused by anemia, thyroid disorders, depression, sleep disorders, nutritional deficiencies, or chronic illnesses. To address it: ensure 7-9 hours of sleep, maintain balanced diet, exercise regularly, manage stress, and limit caffeine. If fatigue interferes with daily activities, consult your doctor for proper evaluation.",
    views: 2234,
    helpful: 1876,
  },
  {
    id: "8",
    category: "Diarrhea",
    question: "How to manage diarrhea and prevent dehydration?",
    answer: "To manage diarrhea: stay hydrated with water, electrolyte drinks, or oral rehydration solutions. Eat bland, easily digestible foods like rice, banana, and crackers. Avoid dairy, fatty, and spicy foods. Wash hands frequently to prevent spread. Most cases resolve within 2-3 days. Seek medical help if it persists, contains blood, or you develop severe dehydration.",
    views: 2567,
    helpful: 2123,
  },
]

const categories = ["All", "Headache", "Fever", "Cough", "Body Ache", "Sore Throat", "Nausea", "Fatigue", "Diarrhea"]

const sortOptions = [
  { value: "views", label: "Most Viewed" },
  { value: "helpful", label: "Most Helpful" },
  { value: "recent", label: "Most Recent" },
]

export function TrendingQuestions() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [sortBy, setSortBy] = useState("views")
  const [searchTerm, setSearchTerm] = useState("")
  const [expandedId, setExpandedId] = useState<string | null>(null)

  const filteredQuestions = trendingQuestions
    .filter((q) =>
      selectedCategory === "All" ? true : q.category === selectedCategory
    )
    .filter((q) =>
      q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.answer.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === "views") return b.views - a.views
      if (sortBy === "helpful") return b.helpful - a.helpful
      return 0
    })

  return (
    <section className="w-full">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">
          Trending Health Questions
        </h2>
        <p className="text-muted-foreground">
          Find answers to common health questions from our community
        </p>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search health questions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Filters and Sort */}
      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-all ${
                selectedCategory === category
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 ml-auto">
          <Filter className="h-5 w-5 text-muted-foreground" />
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {sortOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Questions List */}
      <div className="space-y-4">
        {filteredQuestions.length > 0 ? (
          filteredQuestions.map((q) => (
            <Card key={q.id} className="overflow-hidden">
              <Collapsible
                open={expandedId === q.id}
                onOpenChange={() =>
                  setExpandedId(expandedId === q.id ? null : q.id)
                }
              >
                <CollapsibleTrigger className="w-full">
                  <CardHeader className="pb-4 hover:bg-secondary/50 transition-colors text-left">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                            {q.category}
                          </span>
                        </div>
                        <CardTitle className="text-lg font-semibold text-foreground text-left">
                          {q.question}
                        </CardTitle>
                      </div>
                      <ChevronDown
                        className={`h-5 w-5 text-muted-foreground transition-transform flex-shrink-0 ${
                          expandedId === q.id ? "rotate-180" : ""
                        }`}
                      />
                    </div>
                  </CardHeader>
                </CollapsibleTrigger>

                <CollapsibleContent>
                  <CardContent className="pt-0">
                    <div className="bg-muted/50 p-4 rounded-lg mb-4">
                      <p className="text-foreground leading-relaxed">{q.answer}</p>
                    </div>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex gap-6">
                        <span>👁️ {q.views.toLocaleString()} views</span>
                        <span>👍 {q.helpful.toLocaleString()} found helpful</span>
                      </div>
                      <button className="text-primary hover:text-primary/80 font-medium">
                        Report issue
                      </button>
                    </div>
                  </CardContent>
                </CollapsibleContent>
              </Collapsible>
            </Card>
          ))
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">
                No questions found. Try adjusting your filters or search term.
              </p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Disclaimer */}
      <Card className="mt-8 bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <p className="text-sm text-blue-900">
            <span className="font-semibold">Medical Disclaimer:</span> The information provided here is for educational purposes only and should not be considered medical advice. Always consult with a qualified healthcare professional for diagnosis and treatment of any health condition.
          </p>
        </CardContent>
      </Card>
    </section>
  )
}
