"use client"

import Link from "next/link"
import { Zap, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export function SymptomCheckerFeature() {
  return (
    <section 
      className="w-full rounded-2xl overflow-hidden relative py-12"
      style={{
        backgroundImage: "url(/images/symptom-checker-bg.jpg)",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-primary/60" />
      
      <div className="relative z-10">
        <div className="flex items-center gap-4 mb-6">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white/20">
            <Zap className="h-7 w-7 text-white" />
          </div>
          <div>
            <p className="text-sm font-semibold text-white/90 uppercase tracking-wide">
              TRY OUT OUR NEW FEATURE
            </p>
            <h2 className="text-3xl md:text-4xl font-bold text-white mt-1">
              AI-Powered Symptom Checker
            </h2>
          </div>
        </div>
        
        <p className="text-lg text-white/80 mb-8 max-w-2xl break-words">
          Experience our advanced AI technology that analyzes your symptoms, considers your age, and asks intelligent follow-up questions to provide accurate health insights. Get personalized recommendations for doctors, medicines, and treatments.
        </p>

        <div className="flex flex-col sm:flex-row gap-4">
          <Link href="/symptom-checker" className="flex-1 sm:flex-none">
            <Button 
              size="lg" 
              className="w-full sm:w-auto bg-white text-primary hover:bg-white/90"
            >
              <Zap className="h-5 w-5 mr-2" />
              Try Symptom Checker
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>
          <p className="flex items-center text-white/80 text-sm">
            ✓ Fast • Accurate • Privacy Protected
          </p>
        </div>
      </div>
    </section>
  )
}
