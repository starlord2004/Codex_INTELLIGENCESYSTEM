"use client"

import { useState, useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import { ChevronDown, Menu, X, User, LogOut, ChevronRight, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { useLocation, cities } from "@/contexts/location-context"
import { useUser } from "@/contexts/user-context"
import { AuthDialogs } from "./auth-dialogs"

export function Header() {
  const { selectedCity, selectedArea, setLocation } = useLocation()
  const { user, isLoggedIn, logout } = useUser()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [loginOpen, setLoginOpen] = useState(false)
  const [signupOpen, setSignupOpen] = useState(false)
  const [expandedCity, setExpandedCity] = useState<string | null>(null)
  const [desktopDropdownOpen, setDesktopDropdownOpen] = useState(false)

  const handleAreaSelect = (cityId: string, areaId: string) => {
    setLocation(cityId, areaId)
    setExpandedCity(null)
    setDesktopDropdownOpen(false)
  }

  const displayLocation = selectedCity && selectedArea 
    ? `${selectedCity.name}, ${selectedArea.name}` 
    : "Select Location"

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            {/* Logo */}
            <a href="/" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg overflow-hidden">
                <Image 
                  src="/images/carevia-logo.jpg" 
                  alt="CAREVIA Logo" 
                  width={40} 
                  height={40}
                  className="object-cover"
                />
              </div>
              <span className="text-xl font-bold text-foreground">CAREVIA</span>
            </a>

            {/* Location Selector - Desktop */}
            <div className="hidden md:flex items-center">
              <DropdownMenu open={desktopDropdownOpen} onOpenChange={setDesktopDropdownOpen}>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-1 text-foreground hover:bg-secondary">
                    <span className="font-medium">{displayLocation}</span>
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-64 max-h-[400px] overflow-y-auto">
                  {cities.map((city) => (
                    <div key={city.id}>
                      <DropdownMenuItem
                        className="flex items-center justify-between cursor-pointer"
                        onClick={(e) => {
                          e.preventDefault()
                          setExpandedCity(expandedCity === city.id ? null : city.id)
                        }}
                      >
                        <span className={selectedCity?.id === city.id ? "font-semibold text-primary" : ""}>
                          {city.name}
                        </span>
                        <ChevronRight 
                          className={`h-4 w-4 transition-transform ${
                            expandedCity === city.id ? "rotate-90" : ""
                          }`} 
                        />
                      </DropdownMenuItem>
                      {expandedCity === city.id && (
                        <div className="ml-4 border-l-2 border-secondary pl-2">
                          {city.areas.map((area) => (
                            <DropdownMenuItem
                              key={area.id}
                              className={`cursor-pointer ${
                                selectedArea?.id === area.id && selectedCity?.id === city.id
                                  ? "bg-primary/10 text-primary font-medium"
                                  : ""
                              }`}
                              onClick={() => handleAreaSelect(city.id, area.id)}
                            >
                              {area.name}
                            </DropdownMenuItem>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Navigation Links - Desktop */}
            <nav className="hidden lg:flex items-center gap-6">
              <a href="/doctors" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Find Doctors
              </a>
              <a href="/video-consultation" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Video Consult
              </a>
              <a href="/medicines" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Medicines
              </a>
              <a href="/lab-tests" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Lab Tests
              </a>
            </nav>

            {/* Auth Buttons - Desktop */}
            <div className="hidden md:flex items-center gap-3">
              {isLoggedIn ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center gap-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                        {user?.name?.charAt(0).toUpperCase()}
                      </div>
                      <span className="font-medium">{user?.name?.split(" ")[0]}</span>
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <div className="px-2 py-1.5">
                      <p className="text-sm font-medium">{user?.name}</p>
                      <p className="text-xs text-muted-foreground">{user?.email}</p>
                    </div>
                    <DropdownMenuSeparator />
                    <Link href="/dashboard">
                      <DropdownMenuItem className="cursor-pointer">
                        <FileText className="h-4 w-4 mr-2" />
                        My Account
                      </DropdownMenuItem>
                    </Link>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={logout} className="text-destructive cursor-pointer">
                      <LogOut className="h-4 w-4 mr-2" />
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-foreground"
                    onClick={() => setLoginOpen(true)}
                  >
                    Login
                  </Button>
                  <Button 
                    size="sm" 
                    className="bg-primary text-primary-foreground hover:bg-primary/90"
                    onClick={() => setSignupOpen(true)}
                  >
                    <User className="h-4 w-4 mr-1" />
                    Sign Up
                  </Button>
                </>
              )}
            </div>

            {/* Mobile Menu Button */}
            <Button 
              variant="ghost" 
              size="icon" 
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-border py-4">
              {/* Mobile Location */}
              <div className="px-2 py-2">
                <p className="text-xs text-muted-foreground mb-2 px-2">Select Location</p>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="w-full flex items-center justify-between">
                      <span>{displayLocation}</span>
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="w-64 max-h-[300px] overflow-y-auto">
                    {cities.map((city) => (
                      <div key={city.id}>
                        <DropdownMenuItem
                          className="flex items-center justify-between cursor-pointer"
                          onClick={(e) => {
                            e.preventDefault()
                            setExpandedCity(expandedCity === city.id ? null : city.id)
                          }}
                        >
                          <span className={selectedCity?.id === city.id ? "font-semibold text-primary" : ""}>
                            {city.name}
                          </span>
                          <ChevronRight 
                            className={`h-4 w-4 transition-transform ${
                              expandedCity === city.id ? "rotate-90" : ""
                            }`} 
                          />
                        </DropdownMenuItem>
                        {expandedCity === city.id && (
                          <div className="ml-4 border-l-2 border-secondary pl-2">
                            {city.areas.map((area) => (
                              <DropdownMenuItem
                                key={area.id}
                                className={`cursor-pointer ${
                                  selectedArea?.id === area.id && selectedCity?.id === city.id
                                    ? "bg-primary/10 text-primary font-medium"
                                    : ""
                                }`}
                                onClick={() => {
                                  handleAreaSelect(city.id, area.id)
                                  setMobileMenuOpen(false)
                                }}
                              >
                                {area.name}
                              </DropdownMenuItem>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* Mobile Nav Links */}
              <nav className="flex flex-col gap-1 mt-2">
                <a href="/doctors" className="px-4 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-md">
                  Find Doctors
                </a>
                <a href="/video-consultation" className="px-4 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-md">
                  Video Consult
                </a>
                <a href="/medicines" className="px-4 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-md">
                  Medicines
                </a>
                <a href="/lab-tests" className="px-4 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-md">
                  Lab Tests
                </a>
              </nav>

              {/* Mobile Auth */}
              <div className="flex items-center gap-2 mt-4 px-2">
                {isLoggedIn ? (
                  <div className="w-full">
                    <div className="flex items-center gap-2 px-2 py-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                        {user?.name?.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="text-sm font-medium">{user?.name}</p>
                        <p className="text-xs text-muted-foreground">{user?.email}</p>
                      </div>
                    </div>
                    <Link href="/dashboard" onClick={() => setMobileMenuOpen(false)}>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full mt-2"
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        My Account
                      </Button>
                    </Link>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full mt-2 text-destructive"
                      onClick={() => {
                        logout()
                        setMobileMenuOpen(false)
                      }}
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Logout
                    </Button>
                  </div>
                ) : (
                  <>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => {
                        setLoginOpen(true)
                        setMobileMenuOpen(false)
                      }}
                    >
                      Login
                    </Button>
                    <Button 
                      size="sm" 
                      className="flex-1 bg-primary text-primary-foreground"
                      onClick={() => {
                        setSignupOpen(true)
                        setMobileMenuOpen(false)
                      }}
                    >
                      Sign Up
                    </Button>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </header>

      <AuthDialogs
        loginOpen={loginOpen}
        setLoginOpen={setLoginOpen}
        signupOpen={signupOpen}
        setSignupOpen={setSignupOpen}
      />
    </>
  )
}
