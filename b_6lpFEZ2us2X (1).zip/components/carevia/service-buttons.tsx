"use client"

import Link from "next/link"
import { CalendarCheck, Video, Pill, FlaskConical, Scissors } from "lucide-react"

const services = [
  {
    icon: CalendarCheck,
    title: "Physical Appointment",
    description: "Book in-person doctor visits",
    href: "/appointment",
    bgImage: "/images/physical-appointment-bg.jpg",
  },
  {
    icon: Pill,
    title: "Medicines",
    description: "Order medicines online",
    href: "/medicines",
    bgImage: "/images/medicines-bg.jpg",
  },
  {
    icon: FlaskConical,
    title: "Lab Tests",
    description: "Book diagnostic tests",
    href: "/lab-tests",
    bgImage: "/images/lab-tests-bg.jpg",
  },
  {
    icon: Scissors,
    title: "Surgeries",
    description: "Plan surgical procedures",
    href: "/surgeries",
    bgImage: "/images/surgeries-bg.jpg",
  },
]

export function ServiceButtons() {
  return (
    <section className="w-full space-y-6">
      {/* Video Consultation - Large Button */}
      <Link
        href="/video-consultation"
        className="group relative overflow-hidden flex flex-col items-center justify-center p-8 rounded-2xl border border-primary/30 shadow-md hover:shadow-lg transition-all duration-200 hover:-translate-y-1 text-white min-h-48"
        style={{
          backgroundImage: "url(/images/video-consultation-bg.jpg)",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-primary/70 to-primary/50 group-hover:from-primary/75 group-hover:to-primary/60 transition-all duration-200" />
        <div className="relative z-10 flex flex-col items-center justify-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-white/20 mb-4">
            <Video className="h-8 w-8" />
          </div>
          <h3 className="text-2xl font-bold text-center">
            Video Consultation
          </h3>
          <p className="mt-2 text-sm text-white/90 text-center">
            Consult with doctors online from home
          </p>
        </div>
      </Link>

      {/* Other Services Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {services.map((service) => (
          <Link
            key={service.title}
            href={service.href}
            className="group relative overflow-hidden flex flex-col items-center justify-center p-6 rounded-2xl border border-border/50 shadow-sm hover:shadow-md transition-all duration-200 hover:-translate-y-1 min-h-40"
            style={{
              backgroundImage: `url(${service.bgImage})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-black/60 to-black/40 group-hover:from-black/65 group-hover:to-black/45 transition-all duration-200" />
            <div className="relative z-10 flex flex-col items-center text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-white/20 group-hover:bg-white/30 transition-colors mb-3">
                <service.icon className="h-7 w-7 text-white" />
              </div>
              <h3 className="text-base font-semibold text-white">
                {service.title}
              </h3>
              <p className="mt-1 text-sm text-white/80">
                {service.description}
              </p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  )
}
