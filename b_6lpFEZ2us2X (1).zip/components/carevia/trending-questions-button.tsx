"use client"

import Link from "next/link"
import { HelpCircle, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export function TrendingQuestionsButton() {
  return (
    <section className="w-full">
      <div className="flex flex-col items-center text-center gap-6 py-12">
        <div className="space-y-3">
          <div className="flex justify-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <HelpCircle className="h-8 w-8 text-primary" />
            </div>
          </div>
          <h2 className="text-3xl font-bold text-foreground">
            Have Health Questions?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl">
            Explore trending health questions answered by medical professionals. Get insights into common health concerns and learn from trusted health information.
          </p>
        </div>

        <Link href="/trending-questions">
          <Button size="lg" className="gap-2">
            Read Trending Questions
            <ArrowRight className="h-5 w-5" />
          </Button>
        </Link>
      </div>
    </section>
  )
}
