"use client"

import { useState } from "react"
import { 
  Heart,
  Activity,
  Shield,
  Zap,
  FlaskConical,
  Thermometer,
  Droplets,
  Brain,
  Bone,
  Eye,
  Baby,
  Stethoscope,
  ChevronDown,
  ChevronUp,
  Star,
  Clock,
  FileText
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { HealthPackageBookingDialog } from "./health-package-booking-dialog"

const packages = [
  { 
    icon: Heart, 
    name: "Full Body Checkup", 
    tests: 85, 
    price: 1999, 
    originalPrice: 4500,
    discount: "56% off",
    popular: true,
    duration: "6-8 hours",
    color: "bg-red-100 text-red-600"
  },
  { 
    icon: Activity, 
    name: "Cardiac Health Package", 
    tests: 42, 
    price: 2499, 
    originalPrice: 5000,
    discount: "50% off",
    popular: true,
    duration: "4-5 hours",
    color: "bg-rose-100 text-rose-600"
  },
  { 
    icon: Shield, 
    name: "Diabetes Screening", 
    tests: 28, 
    price: 899, 
    originalPrice: 2000,
    discount: "55% off",
    popular: false,
    duration: "3-4 hours",
    color: "bg-blue-100 text-blue-600"
  },
  { 
    icon: Zap, 
    name: "Thyroid Profile", 
    tests: 12, 
    price: 599, 
    originalPrice: 1200,
    discount: "50% off",
    popular: false,
    duration: "2-3 hours",
    color: "bg-amber-100 text-amber-600"
  },
  { 
    icon: FlaskConical, 
    name: "Vitamin Deficiency Panel", 
    tests: 18, 
    price: 1299, 
    originalPrice: 3000,
    discount: "57% off",
    popular: false,
    duration: "4-5 hours",
    color: "bg-purple-100 text-purple-600"
  },
  { 
    icon: Thermometer, 
    name: "Fever Profile", 
    tests: 22, 
    price: 749, 
    originalPrice: 1500,
    discount: "50% off",
    popular: false,
    duration: "3-4 hours",
    color: "bg-orange-100 text-orange-600"
  },
  { 
    icon: Droplets, 
    name: "Kidney Function Test", 
    tests: 15, 
    price: 649, 
    originalPrice: 1300,
    discount: "50% off",
    popular: false,
    duration: "2-3 hours",
    color: "bg-cyan-100 text-cyan-600"
  },
  { 
    icon: Brain, 
    name: "Liver Function Test", 
    tests: 12, 
    price: 549, 
    originalPrice: 1100,
    discount: "50% off",
    popular: false,
    duration: "2-3 hours",
    color: "bg-indigo-100 text-indigo-600"
  },
  { 
    icon: Bone, 
    name: "Bone Health Package", 
    tests: 20, 
    price: 1199, 
    originalPrice: 2500,
    discount: "52% off",
    popular: false,
    duration: "3-4 hours",
    color: "bg-amber-100 text-amber-600"
  },
  { 
    icon: Eye, 
    name: "Eye Health Checkup", 
    tests: 8, 
    price: 799, 
    originalPrice: 1600,
    discount: "50% off",
    popular: false,
    duration: "2-3 hours",
    color: "bg-blue-100 text-blue-600"
  },
  { 
    icon: Baby, 
    name: "Women Wellness Package", 
    tests: 45, 
    price: 2299, 
    originalPrice: 5000,
    discount: "54% off",
    popular: true,
    duration: "5-6 hours",
    color: "bg-pink-100 text-pink-600"
  },
  { 
    icon: Stethoscope, 
    name: "Senior Citizen Package", 
    tests: 65, 
    price: 2799, 
    originalPrice: 6000,
    discount: "53% off",
    popular: true,
    duration: "6-8 hours",
    color: "bg-emerald-100 text-emerald-600"
  },
  { 
    icon: Activity, 
    name: "Lipid Profile", 
    tests: 8, 
    price: 399, 
    originalPrice: 800,
    discount: "50% off",
    popular: false,
    duration: "2-3 hours",
    color: "bg-rose-100 text-rose-600"
  },
  { 
    icon: Shield, 
    name: "Allergy Panel", 
    tests: 30, 
    price: 1499, 
    originalPrice: 3500,
    discount: "57% off",
    popular: false,
    duration: "4-5 hours",
    color: "bg-teal-100 text-teal-600"
  },
]

interface SelectedPackage {
  name: string
  price: number
  originalPrice: number
  tests: number
}

export function HealthPackages() {
  const [showAll, setShowAll] = useState(false)
  const [bookingOpen, setBookingOpen] = useState(false)
  const [selectedPackage, setSelectedPackage] = useState<SelectedPackage | null>(null)
  
  const visiblePackages = showAll ? packages : packages.slice(0, 4)

  const handleBookNow = (pkg: typeof packages[0]) => {
    setSelectedPackage({
      name: pkg.name,
      price: pkg.price,
      originalPrice: pkg.originalPrice,
      tests: pkg.tests,
    })
    setBookingOpen(true)
  }

  return (
    <section className="w-full">
      <div className="text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-bold text-foreground">
          Popular Health Checkup Packages
        </h2>
        <p className="mt-2 text-muted-foreground">
          Comprehensive health screenings at affordable prices
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {visiblePackages.map((pkg) => (
          <div
            key={pkg.name}
            className="group relative flex flex-col p-5 bg-card rounded-xl border border-border hover:border-primary/50 hover:shadow-lg transition-all duration-200"
          >
            {pkg.popular && (
              <div className="absolute -top-2 -right-2 flex items-center gap-1 px-2 py-1 bg-amber-500 text-white text-xs font-medium rounded-full">
                <Star className="h-3 w-3 fill-current" />
                Popular
              </div>
            )}
            
            <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${pkg.color} mb-4`}>
              <pkg.icon className="h-6 w-6" />
            </div>
            
            <h3 className="text-base font-semibold text-foreground mb-2">
              {pkg.name}
            </h3>
            
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
              <FileText className="h-4 w-4" />
              <span>{pkg.tests} Tests Included</span>
            </div>
            
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
              <Clock className="h-4 w-4" />
              <span>Reports in {pkg.duration}</span>
            </div>
            
            <div className="mt-auto">
              <div className="flex items-baseline gap-2 mb-3">
                <span className="text-xl font-bold text-primary">₹{pkg.price.toLocaleString()}</span>
                <span className="text-sm text-muted-foreground line-through">₹{pkg.originalPrice.toLocaleString()}</span>
                <span className="text-xs font-medium text-emerald-600 bg-emerald-100 px-2 py-0.5 rounded">
                  {pkg.discount}
                </span>
              </div>
              
              <Button 
                className="w-full" 
                size="sm"
                onClick={() => handleBookNow(pkg)}
              >
                Book Now
              </Button>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-center mt-8">
        <Button
          variant="outline"
          size="lg"
          onClick={() => setShowAll(!showAll)}
          className="gap-2"
        >
          {showAll ? (
            <>
              <ChevronUp className="h-4 w-4" />
              Show Less
            </>
          ) : (
            <>
              <ChevronDown className="h-4 w-4" />
              View All Packages ({packages.length})
            </>
          )}
        </Button>
      </div>

      <HealthPackageBookingDialog
        open={bookingOpen}
        onOpenChange={setBookingOpen}
        healthPackage={selectedPackage}
      />
    </section>
  )
}
