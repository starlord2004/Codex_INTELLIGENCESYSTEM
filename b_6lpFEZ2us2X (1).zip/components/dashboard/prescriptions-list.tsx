"use client"

import { useState } from "react"
import { Download, Trash2, FileText, Image as ImageIcon, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useUser, type Prescription } from "@/contexts/user-context"
import { useToast } from "@/hooks/use-toast"

export function PrescriptionsList() {
  const { prescriptions, removePrescription } = useUser()
  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(null)
  const { toast } = useToast()

  const handleDelete = (prescriptionId: string) => {
    removePrescription(prescriptionId)
    toast({
      title: "Success",
      description: "Prescription deleted successfully",
    })
  }

  const handleDownload = (prescription: Prescription) => {
    // Create a link and trigger download
    const link = document.createElement("a")
    link.href = prescription.fileUrl
    link.download = prescription.fileName
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "Download started",
      description: `${prescription.fileName} is being downloaded`,
    })
  }

  if (prescriptions.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>My Prescriptions</CardTitle>
          <CardDescription>No prescriptions uploaded yet</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Upload your medical prescriptions to keep them organized in one place.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>My Prescriptions</CardTitle>
          <CardDescription>{prescriptions.length} prescription(s) uploaded</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {prescriptions.map((prescription) => (
              <div
                key={prescription.id}
                className="border rounded-lg p-4 hover:shadow-lg transition-shadow"
              >
                {/* File Preview or Icon */}
                <div className="mb-3 flex-shrink-0">
                  {prescription.fileType.startsWith("image/") && prescription.fileUrl ? (
                    <img
                      src={prescription.fileUrl}
                      alt={prescription.fileName}
                      className="w-full h-32 object-cover rounded"
                    />
                  ) : (
                    <div className="w-full h-32 bg-secondary rounded flex items-center justify-center">
                      {prescription.fileType === "application/pdf" ? (
                        <FileText className="h-12 w-12 text-red-500" />
                      ) : (
                        <ImageIcon className="h-12 w-12 text-blue-500" />
                      )}
                    </div>
                  )}
                </div>

                {/* File Info */}
                <div className="mb-3">
                  <p className="font-medium text-sm truncate">{prescription.fileName}</p>
                  {prescription.doctorName && (
                    <p className="text-xs text-muted-foreground">
                      Dr. {prescription.doctorName}
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(prescription.uploadedDate).toLocaleDateString("en-IN", {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                    })}
                  </p>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  {prescription.fileType.startsWith("image/") && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => setSelectedPrescription(prescription)}
                    >
                      <Eye className="h-3 w-3 mr-1" />
                      View
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => handleDownload(prescription)}
                  >
                    <Download className="h-3 w-3 mr-1" />
                    Download
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    onClick={() => handleDelete(prescription.id)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Image Preview Dialog */}
      <Dialog open={!!selectedPrescription} onOpenChange={() => setSelectedPrescription(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedPrescription?.fileName}</DialogTitle>
          </DialogHeader>
          {selectedPrescription?.fileType.startsWith("image/") && (
            <img
              src={selectedPrescription.fileUrl}
              alt={selectedPrescription.fileName}
              className="w-full rounded"
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
