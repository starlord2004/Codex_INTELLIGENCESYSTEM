"use client"

import { useState, useRef } from "react"
import { Upload, X, File, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { useUser } from "@/contexts/user-context"
import { useToast } from "@/hooks/use-toast"

interface PrescriptionUploadProps {
  onUploadComplete?: () => void
}

export function PrescriptionUpload({ onUploadComplete }: PrescriptionUploadProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [fileName, setFileName] = useState("")
  const [filePreview, setFilePreview] = useState<string>("")
  const [isUploading, setIsUploading] = useState(false)
  const [doctorName, setDoctorName] = useState("")
  const [description, setDescription] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { addPrescription } = useUser()
  const { toast } = useToast()

  const ALLOWED_TYPES = ["application/pdf", "image/jpeg", "image/png", "image/jpg"]
  const MAX_SIZE = 10 * 1024 * 1024 // 10MB

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const processFile = (file: File) => {
    if (!ALLOWED_TYPES.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please upload PDF or image files only (JPG, PNG)",
        variant: "destructive",
      })
      return
    }

    if (file.size > MAX_SIZE) {
      toast({
        title: "File too large",
        description: "Please upload files smaller than 10MB",
        variant: "destructive",
      })
      return
    }

    setSelectedFile(file)
    setFileName(file.name)

    // Create preview for images
    if (file.type.startsWith("image/")) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setFilePreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    } else {
      setFilePreview("")
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    const files = e.dataTransfer.files
    if (files.length > 0) {
      processFile(files[0])
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.currentTarget.files
    if (files && files.length > 0) {
      processFile(files[0])
    }
  }

  const handleUpload = async () => {
    if (!selectedFile) {
      toast({
        title: "No file selected",
        description: "Please select a file to upload",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)

    try {
      // Read file as data URL for storage
      const reader = new FileReader()
      reader.onload = (e) => {
        const fileUrl = e.target?.result as string

        addPrescription({
          fileName: fileName || selectedFile.name,
          fileUrl: fileUrl,
          fileType: selectedFile.type,
          doctorName: doctorName || undefined,
          description: description || undefined,
        })

        toast({
          title: "Success",
          description: "Prescription uploaded successfully",
        })

        // Reset form
        setSelectedFile(null)
        setFileName("")
        setFilePreview("")
        setDoctorName("")
        setDescription("")
        if (fileInputRef.current) {
          fileInputRef.current.value = ""
        }

        onUploadComplete?.()
      }
      reader.readAsDataURL(selectedFile)
    } catch (error) {
      console.error("Upload error:", error)
      toast({
        title: "Upload failed",
        description: "An error occurred while uploading the file",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  const getFileIcon = () => {
    if (selectedFile?.type === "application/pdf") {
      return <FileText className="h-12 w-12 text-red-500" />
    }
    return <File className="h-12 w-12 text-blue-500" />
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Upload Prescription</CardTitle>
        <CardDescription>Upload your medical prescriptions (PDF or image files)</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {!selectedFile ? (
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isDragging
                ? "border-primary bg-primary/5"
                : "border-border bg-secondary/20"
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={handleFileInput}
              className="hidden"
            />

            <div className="flex flex-col items-center gap-2">
              <Upload className="h-8 w-8 text-muted-foreground" />
              <div>
                <p className="font-medium">Drag and drop your file here</p>
                <p className="text-sm text-muted-foreground">or click to browse</p>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Supported formats: PDF, JPG, PNG (max 10MB)
              </p>
            </div>

            <Button
              variant="outline"
              size="sm"
              className="mt-4"
              onClick={() => fileInputRef.current?.click()}
            >
              Choose File
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="border rounded-lg p-4 flex items-start gap-4 bg-secondary/20">
              <div className="flex-shrink-0">
                {filePreview ? (
                  <img
                    src={filePreview}
                    alt="Preview"
                    className="h-20 w-20 object-cover rounded"
                  />
                ) : (
                  <div className="h-20 w-20 bg-secondary rounded flex items-center justify-center">
                    {getFileIcon()}
                  </div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{fileName}</p>
                <p className="text-sm text-muted-foreground">
                  {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  setSelectedFile(null)
                  setFileName("")
                  setFilePreview("")
                  if (fileInputRef.current) {
                    fileInputRef.current.value = ""
                  }
                }}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            <Input
              placeholder="Doctor's name (optional)"
              value={doctorName}
              onChange={(e) => setDoctorName(e.target.value)}
            />

            <Textarea
              placeholder="Add notes about this prescription (optional)"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />

            <div className="flex gap-2 pt-2">
              <Button
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
              >
                Change File
              </Button>
              <Button
                onClick={handleUpload}
                disabled={isUploading || !selectedFile}
              >
                {isUploading ? "Uploading..." : "Upload Prescription"}
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
