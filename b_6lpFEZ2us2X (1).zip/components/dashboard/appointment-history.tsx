"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useUser, type DoctorAppointment } from "@/contexts/user-context"
import { Calendar, Clock, MapPin, User } from "lucide-react"

export function AppointmentHistory() {
  const { appointments } = useUser()

  const completedAppointments = appointments.filter((a) => a.status === "completed")
  const upcomingAppointments = appointments.filter((a) => a.status === "upcoming")
  const cancelledAppointments = appointments.filter((a) => a.status === "cancelled")

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "upcoming":
        return "bg-blue-100 text-blue-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const AppointmentCard = ({ appointment }: { appointment: DoctorAppointment }) => (
    <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h4 className="font-semibold text-foreground">Dr. {appointment.doctorName}</h4>
          <p className="text-sm text-muted-foreground">{appointment.doctorSpecialty}</p>
        </div>
        <Badge className={getStatusColor(appointment.status)}>
          {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
        </Badge>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm">
          <User className="h-4 w-4 text-muted-foreground" />
          <span className="text-muted-foreground">{appointment.clinicName}</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <MapPin className="h-4 w-4 text-muted-foreground" />
          <span className="text-muted-foreground">{appointment.clinicAddress}</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <span className="text-muted-foreground">
            {new Date(appointment.appointmentDate).toLocaleDateString("en-IN", {
              year: "numeric",
              month: "short",
              day: "numeric",
            })}
          </span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <span className="text-muted-foreground">{appointment.appointmentTime}</span>
        </div>
      </div>

      {appointment.reason && (
        <div className="mt-3 pt-3 border-t">
          <p className="text-sm font-medium text-foreground">Reason:</p>
          <p className="text-sm text-muted-foreground">{appointment.reason}</p>
        </div>
      )}

      {appointment.notes && (
        <div className="mt-2">
          <p className="text-sm font-medium text-foreground">Notes:</p>
          <p className="text-sm text-muted-foreground">{appointment.notes}</p>
        </div>
      )}
    </div>
  )

  const EmptyState = ({ title }: { title: string }) => (
    <div className="text-center py-8">
      <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-2 opacity-50" />
      <p className="text-muted-foreground">{title}</p>
    </div>
  )

  if (appointments.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Appointment History</CardTitle>
          <CardDescription>No appointments yet</CardDescription>
        </CardHeader>
        <CardContent>
          <EmptyState title="You haven't booked any appointments yet" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Appointment History</CardTitle>
        <CardDescription>View your past and upcoming appointments</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="upcoming" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="upcoming">
              Upcoming ({upcomingAppointments.length})
            </TabsTrigger>
            <TabsTrigger value="completed">
              Completed ({completedAppointments.length})
            </TabsTrigger>
            <TabsTrigger value="cancelled">
              Cancelled ({cancelledAppointments.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming" className="mt-4">
            {upcomingAppointments.length === 0 ? (
              <EmptyState title="No upcoming appointments" />
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {upcomingAppointments.map((appointment) => (
                  <AppointmentCard key={appointment.id} appointment={appointment} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="completed" className="mt-4">
            {completedAppointments.length === 0 ? (
              <EmptyState title="No completed appointments" />
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {completedAppointments.map((appointment) => (
                  <AppointmentCard key={appointment.id} appointment={appointment} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="cancelled" className="mt-4">
            {cancelledAppointments.length === 0 ? (
              <EmptyState title="No cancelled appointments" />
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {cancelledAppointments.map((appointment) => (
                  <AppointmentCard key={appointment.id} appointment={appointment} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
