"use client"

import React, { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { ArrowLeft } from "lucide-react"

interface Question {
  id: string
  question: string
  options: string[]
  detail?: string
}

interface FollowUpQuestionsStageProps {
  questions: Question[]
  selectedSymptoms: string[]
  onBack: () => void
  onSubmit: (answers: Record<string, string>) => void
}

export function FollowUpQuestionsStage({
  questions,
  selectedSymptoms,
  onBack,
  onSubmit,
}: FollowUpQuestionsStageProps) {
  const [answers, setAnswers] = useState<Record<string, string>>({})

  const handleSubmit = () => {
    const allAnswered = questions.every(q => answers[q.id])
    if (!allAnswered) {
      alert("Please answer all questions")
      return
    }
    onSubmit(answers)
  }

  const allAnswered = questions.every(q => answers[q.id])

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur">
        <div className="container px-4 flex h-16 items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            className="gap-2"
            onClick={onBack}
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <div className="flex-1">
            <h1 className="text-xl font-bold">Clarifying Questions</h1>
            <p className="text-sm text-muted-foreground">Help us identify your main symptom</p>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Selected Symptoms Summary */}
          <Card className="bg-primary/5 border-primary/20">
            <CardHeader>
              <CardTitle className="text-sm">Your Symptoms</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {selectedSymptoms.map((symptom) => (
                  <span
                    key={symptom}
                    className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium"
                  >
                    {symptom}
                  </span>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Questions */}
          <div className="space-y-6">
            {questions.map((question, idx) => (
              <Card key={question.id}>
                <CardHeader>
                  <CardTitle className="text-lg">
                    <span className="text-primary mr-2">{idx + 1}.</span>
                    {question.question}
                  </CardTitle>
                  {question.detail && (
                    <p className="text-sm text-muted-foreground font-normal mt-2">
                      {question.detail}
                    </p>
                  )}
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    value={answers[question.id] || ""}
                    onValueChange={(value) =>
                      setAnswers((prev) => ({ ...prev, [question.id]: value }))
                    }
                  >
                    <div className="space-y-3">
                      {question.options.map((option) => (
                        <div key={option} className="flex items-center space-x-2">
                          <RadioGroupItem value={option} id={`${question.id}-${option}`} />
                          <Label
                            htmlFor={`${question.id}-${option}`}
                            className="font-normal cursor-pointer flex-1 py-2"
                          >
                            {option}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </RadioGroup>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleSubmit}
            disabled={!allAnswered}
            className="w-full py-6 text-base"
          >
            Get Diagnosis
          </Button>
        </div>
      </main>
    </div>
  )
}
