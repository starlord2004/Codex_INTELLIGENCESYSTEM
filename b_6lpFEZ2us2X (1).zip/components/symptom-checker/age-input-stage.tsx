"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { AlertCircle } from "lucide-react"

interface AgeInputStageProps {
  onAgeSubmit: (age: number) => void
}

export function AgeInputStage({ onAgeSubmit }: AgeInputStageProps) {
  const [age, setAge] = useState<string>("")
  const [error, setError] = useState<string>("")

  const handleSubmit = () => {
    setError("")

    if (!age.trim()) {
      setError("Please enter your age")
      return
    }

    const ageNum = parseInt(age, 10)

    if (isNaN(ageNum) || ageNum < 0 || ageNum > 120) {
      setError("Please enter a valid age (0-120 years)")
      return
    }

    onAgeSubmit(ageNum)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSubmit()
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-2 border-primary/20">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl mb-2">Symptom Checker</CardTitle>
          <p className="text-muted-foreground">Let&apos;s start by knowing your age</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="age" className="block text-sm font-medium">
              Your Age
            </label>
            <Input
              id="age"
              type="number"
              min="0"
              max="120"
              placeholder="Enter your age in years"
              value={age}
              onChange={(e) => {
                setAge(e.target.value)
                setError("")
              }}
              onKeyPress={handleKeyPress}
              className="text-lg py-6"
            />
          </div>

          {error && (
            <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg flex gap-2">
              <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
              <p className="text-sm text-destructive font-medium">{error}</p>
            </div>
          )}

          <div className="space-y-3 text-sm text-muted-foreground">
            <div className="flex items-start gap-2">
              <span className="text-primary font-bold mt-0.5">ℹ️</span>
              <p>Your age helps us provide more accurate health recommendations tailored to your age group.</p>
            </div>
          </div>

          <Button
            onClick={handleSubmit}
            className="w-full py-6 text-base"
          >
            Continue to Symptoms
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
