# ML Features Quick Reference Guide

## File Structure
```
lib/
├── ml/
│   ├── doctor-recommendation.ts       # Collaborative Filtering
│   ├── medicine-recommendation.ts     # Association Rules
│   ├── risk-scoring.ts                # Logistic Regression
│   ├── trending-topics.ts             # TF-IDF + Clustering
│   ├── appointment-optimizer.ts       # Time Series Analysis
│   ├── lab-test-recommendation.ts     # Decision Trees
│   └── patient-health-profile.ts      # Pattern Recognition
├── symptom-checker-logic.ts           # Enhanced Naive Bayes + DT
└── [other utilities]
```

---

## Quick API Reference

### 1. Symptom Checker Enhancement
```typescript
import { predictDiseaseWithFollowUp } from '@/lib/symptom-checker-logic'

const diagnosis = predictDiseaseWithFollowUp(
  symptoms: string[],      // ["Fever", "Cough"]
  followUpAnswers: {},      // Answers to follow-up questions
  age: number               // User's age
)
// Returns: "Influenza" | "Common Cold" | etc.
```

### 2. Doctor Recommendation
```typescript
import { recommendDoctors } from '@/lib/ml/doctor-recommendation'

const doctors = recommendDoctors(
  diagnosis: string,        // "Influenza"
  userAge: number           // 35
)
// Returns: DoctorScore[] - Top 3 doctors with scores
```

### 3. Medicine Recommendation
```typescript
import { recommendMedicines } from '@/lib/ml/medicine-recommendation'

const medicines = recommendMedicines(
  diagnosis: string,        // "Influenza"
  userAge: number           // 35
)
// Returns: MedicineScore[] - Sorted by effectiveness & age safety
```

### 4. Risk Scoring
```typescript
import { calculateRiskScore } from '@/lib/ml/risk-scoring'

const risk = calculateRiskScore(
  symptoms: string[],       // ["Chest Pain", "Shortness of Breath"]
  age: number,              // 70
  duration: number          // 48 (hours)
)
// Returns: RiskAssessment with level, score, urgency, recommendation
```

### 5. Trending Topics
```typescript
import { getTrendingTopics } from '@/lib/ml/trending-topics'

const topics = getTrendingTopics()
// Returns: TrendingTopic[] - Top 5 trending health topics
```

### 6. Appointment Optimizer
```typescript
import { getOptimizedSlots, predictNoShowRisk } from '@/lib/ml/appointment-optimizer'

// Get optimized slots
const slots = getOptimizedSlots(
  availableSlots: string[]  // ["09:00", "10:00", "14:00"]
)
// Returns: OptimizedSlot[] - Sorted by score (best first)

// Predict no-show risk
const risk = predictNoShowRisk(
  patientAge: number,       // 25
  dayOfWeek: number,        // 1 (Monday)
  timeOfDay: number         // 15 (3 PM)
)
// Returns: 0-100 risk score
```

### 7. Lab Test Recommendation
```typescript
import { recommendLabTests } from '@/lib/ml/lab-test-recommendation'

const tests = recommendLabTests(
  symptoms: string[],       // ["Chest Pain", "Fever"]
  age: number,              // 55
  severity: "High" | "Medium" | "Low" | "Critical"
)
// Returns: LabTestRecommendation[] - Sorted by urgency
```

### 8. Patient Health Profile
```typescript
import { buildHealthProfile } from '@/lib/ml/patient-health-profile'

const profile = buildHealthProfile(
  patientId: string,        // "user_123"
  age: number,              // 45
  medicalHistory: string[], // ["Diabetes", "Hypertension"]
  recentSymptoms: string[]  // ["Fever", "Fatigue", "Fever"]
)
// Returns: PatientHealthProfile with scores and recommendations
```

---

## Integration Examples

### Example 1: Symptom Checker Results Page
```typescript
// File: app/symptom-checker/page.tsx

import { recommendDoctors } from '@/lib/ml/doctor-recommendation'
import { recommendMedicines } from '@/lib/ml/medicine-recommendation'
import { calculateRiskScore } from '@/lib/ml/risk-scoring'

// After diagnosis
const diagnosis = "Influenza"
const userAge = 35

// Get all recommendations
const doctors = recommendDoctors(diagnosis, userAge)
const medicines = recommendMedicines(diagnosis, userAge)
const risk = calculateRiskScore(selectedSymptoms, userAge, duration)

// Display results
return (
  <div>
    <RiskBadge risk={risk.riskLevel} />
    <DoctorList doctors={doctors} />
    <MedicineList medicines={medicines} />
  </div>
)
```

### Example 2: Appointment Booking
```typescript
// File: app/doctors/[doctorId]/book/page.tsx

import { getOptimizedSlots, predictNoShowRisk } from '@/lib/ml/appointment-optimizer'

// Get available slots
const availableSlots = ["09:00", "09:30", "10:00", "14:00", "15:00"]

// Optimize slots
const optimizedSlots = getOptimizedSlots(availableSlots)

// Check no-show risk
const noShowRisk = predictNoShowRisk(
  userAge,
  new Date().getDay(),
  parseInt(slot.split(":")[0])
)

if (noShowRisk > 30) {
  console.warn("High no-show risk for this patient")
}
```

### Example 3: Dashboard Health Overview
```typescript
// File: app/dashboard/page.tsx

import { buildHealthProfile } from '@/lib/ml/patient-health-profile'

// Build health profile
const profile = buildHealthProfile(
  userId,
  userAge,
  userMedicalHistory,
  userRecentSymptoms
)

return (
  <div>
    <HealthScore score={profile.healthScore} />
    <RiskFactors factors={profile.riskFactors} />
    <Recommendations recommendations={profile.recommendations} />
    <HealthMetrics metrics={profile.metrics} />
  </div>
)
```

---

## Common ML Patterns

### Pattern 1: Weighted Scoring
```typescript
const score = (
  factor1 * 0.40 +      // 40% weight
  factor2 * 0.30 +      // 30% weight
  factor3 * 0.30        // 30% weight
)
```

### Pattern 2: Age Stratification
```typescript
const ageGroup = age < 18 ? "pediatric" : age < 65 ? "adult" : "elderly"
const adjustedScore = baseScore * ageGroupMultiplier[ageGroup]
```

### Pattern 3: Risk Classification
```typescript
if (score >= 75) return "Critical"
if (score >= 55) return "High"
if (score >= 35) return "Medium"
return "Low"
```

### Pattern 4: Trend Detection
```typescript
const percentChange = ((current - previous) / previous) * 100
const trend = percentChange > 20 ? "Rising" : percentChange < -20 ? "Declining" : "Stable"
```

---

## Performance Tips

1. **Cache Results:** Store recommendations for 5 minutes
2. **Batch Predictions:** Calculate multiple predictions together
3. **Lazy Load:** Only load ML modules when needed
4. **Pre-calculate:** Pre-compute common recommendations on app startup

---

## Testing ML Features

```typescript
// Example test
describe('Doctor Recommendation', () => {
  it('should recommend cardiologists for angina', () => {
    const doctors = recommendDoctors("Angina", 45)
    const cardios = doctors.filter(d => d.specialty === "Cardiologist")
    expect(cardios.length).toBeGreaterThan(0)
  })
})
```

---

## Monitoring & Debugging

```typescript
// Debug ML predictions
console.log("[ML] Symptom Checker Result:", diagnosis)
console.log("[ML] Risk Score:", risk.riskScore)
console.log("[ML] Top Doctor:", doctors[0].name, doctors[0].score)
```

---

## Error Handling

```typescript
try {
  const result = predictDiseaseWithFollowUp(symptoms, answers, age)
  if (!result) {
    // Fallback to general physician
    return "General Consultation Recommended"
  }
} catch (error) {
  console.error("[ML] Prediction failed:", error)
  // Return safe default
}
```

