"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export interface Area {
  id: string
  name: string
  nearbyAreas: string[] // IDs of nearby areas
}

export interface City {
  id: string
  name: string
  areas: Area[]
}

export const cities: City[] = [
  {
    id: "bangalore",
    name: "Bangalore",
    areas: [
      { id: "indiranagar", name: "Indiranagar", nearbyAreas: ["koramangala", "domlur", "ulsoor"] },
      { id: "koramangala", name: "Koramangala", nearbyAreas: ["indiranagar", "hsr-layout", "btm-layout"] },
      { id: "whitefield", name: "Whitefield", nearbyAreas: ["marathahalli", "kr-puram", "mahadevapura"] },
      { id: "hsr-layout", name: "HSR Layout", nearbyAreas: ["koramangala", "btm-layout", "bommanahalli"] },
      { id: "jayanagar", name: "Jayanagar", nearbyAreas: ["jp-nagar", "basavanagudi", "btm-layout"] },
      { id: "marathahalli", name: "Marathahalli", nearbyAreas: ["whitefield", "bellandur", "sarjapur"] },
      { id: "electronic-city", name: "Electronic City", nearbyAreas: ["bommanahalli", "hsr-layout", "sarjapur"] },
      { id: "malleshwaram", name: "Malleshwaram", nearbyAreas: ["rajajinagar", "sadashivanagar", "yeshwanthpur"] },
      { id: "btm-layout", name: "BTM Layout", nearbyAreas: ["koramangala", "hsr-layout", "jayanagar"] },
      { id: "jp-nagar", name: "JP Nagar", nearbyAreas: ["jayanagar", "bannerghatta-road", "btm-layout"] },
      { id: "domlur", name: "Domlur", nearbyAreas: ["indiranagar", "koramangala", "ulsoor"] },
      { id: "ulsoor", name: "Ulsoor", nearbyAreas: ["indiranagar", "domlur", "mg-road"] },
      { id: "bellandur", name: "Bellandur", nearbyAreas: ["marathahalli", "sarjapur", "hsr-layout"] },
      { id: "sarjapur", name: "Sarjapur", nearbyAreas: ["bellandur", "marathahalli", "electronic-city"] },
      { id: "rajajinagar", name: "Rajajinagar", nearbyAreas: ["malleshwaram", "basaveshwaranagar", "vijayanagar"] },
    ],
  },
  {
    id: "mumbai",
    name: "Mumbai",
    areas: [
      { id: "andheri", name: "Andheri", nearbyAreas: ["bandra", "juhu", "goregaon"] },
      { id: "bandra", name: "Bandra", nearbyAreas: ["andheri", "khar", "santacruz"] },
      { id: "juhu", name: "Juhu", nearbyAreas: ["andheri", "santacruz", "vile-parle"] },
      { id: "powai", name: "Powai", nearbyAreas: ["vikhroli", "kanjurmarg", "mulund"] },
      { id: "thane", name: "Thane", nearbyAreas: ["mulund", "ghodbunder", "kalwa"] },
      { id: "dadar", name: "Dadar", nearbyAreas: ["prabhadevi", "matunga", "wadala"] },
      { id: "colaba", name: "Colaba", nearbyAreas: ["fort", "churchgate", "cuffe-parade"] },
      { id: "lower-parel", name: "Lower Parel", nearbyAreas: ["worli", "prabhadevi", "dadar"] },
      { id: "goregaon", name: "Goregaon", nearbyAreas: ["andheri", "malad", "jogeshwari"] },
      { id: "malad", name: "Malad", nearbyAreas: ["goregaon", "kandivali", "borivali"] },
    ],
  },
  {
    id: "delhi",
    name: "Delhi",
    areas: [
      { id: "south-delhi", name: "South Delhi", nearbyAreas: ["greater-kailash", "saket", "hauz-khas"] },
      { id: "greater-kailash", name: "Greater Kailash", nearbyAreas: ["south-delhi", "nehru-place", "kalkaji"] },
      { id: "connaught-place", name: "Connaught Place", nearbyAreas: ["karol-bagh", "rajiv-chowk", "janpath"] },
      { id: "dwarka", name: "Dwarka", nearbyAreas: ["janakpuri", "uttam-nagar", "palam"] },
      { id: "rohini", name: "Rohini", nearbyAreas: ["pitampura", "shalimar-bagh", "prashant-vihar"] },
      { id: "saket", name: "Saket", nearbyAreas: ["south-delhi", "malviya-nagar", "hauz-khas"] },
      { id: "hauz-khas", name: "Hauz Khas", nearbyAreas: ["south-delhi", "saket", "green-park"] },
      { id: "vasant-kunj", name: "Vasant Kunj", nearbyAreas: ["vasant-vihar", "mehrauli", "chattarpur"] },
    ],
  },
  {
    id: "chennai",
    name: "Chennai",
    areas: [
      { id: "t-nagar", name: "T. Nagar", nearbyAreas: ["nungambakkam", "kodambakkam", "west-mambalam"] },
      { id: "adyar", name: "Adyar", nearbyAreas: ["besant-nagar", "thiruvanmiyur", "kotturpuram"] },
      { id: "velachery", name: "Velachery", nearbyAreas: ["guindy", "taramani", "medavakkam"] },
      { id: "anna-nagar", name: "Anna Nagar", nearbyAreas: ["kilpauk", "aminjikarai", "shenoy-nagar"] },
      { id: "porur", name: "Porur", nearbyAreas: ["ramapuram", "valasaravakkam", "guindy"] },
      { id: "omr", name: "OMR", nearbyAreas: ["sholinganallur", "perungudi", "thoraipakkam"] },
    ],
  },
  {
    id: "hyderabad",
    name: "Hyderabad",
    areas: [
      { id: "hitech-city", name: "HITEC City", nearbyAreas: ["madhapur", "kondapur", "gachibowli"] },
      { id: "madhapur", name: "Madhapur", nearbyAreas: ["hitech-city", "jubilee-hills", "kondapur"] },
      { id: "banjara-hills", name: "Banjara Hills", nearbyAreas: ["jubilee-hills", "somajiguda", "road-no-12"] },
      { id: "jubilee-hills", name: "Jubilee Hills", nearbyAreas: ["banjara-hills", "madhapur", "film-nagar"] },
      { id: "gachibowli", name: "Gachibowli", nearbyAreas: ["hitech-city", "kondapur", "nanakramguda"] },
      { id: "secunderabad", name: "Secunderabad", nearbyAreas: ["begumpet", "ameerpet", "paradise"] },
      { id: "kukatpally", name: "Kukatpally", nearbyAreas: ["miyapur", "jntu", "moosapet"] },
    ],
  },
]

interface LocationContextType {
  selectedCity: City | null
  selectedArea: Area | null
  setLocation: (cityId: string, areaId: string) => void
  setCity: (cityId: string) => void
  getNearbyAreas: () => Area[]
  getAllAreasInCity: () => Area[]
}

const LocationContext = createContext<LocationContextType | undefined>(undefined)

export function LocationProvider({ children }: { children: ReactNode }) {
  const [selectedCity, setSelectedCity] = useState<City | null>(null)
  const [selectedArea, setSelectedArea] = useState<Area | null>(null)

  // Load from localStorage on mount
  useEffect(() => {
    const savedLocation = localStorage.getItem("carevia-location")
    if (savedLocation) {
      try {
        const { cityId, areaId } = JSON.parse(savedLocation)
        const city = cities.find((c) => c.id === cityId)
        if (city) {
          setSelectedCity(city)
          const area = city.areas.find((a) => a.id === areaId)
          if (area) {
            setSelectedArea(area)
          }
        }
      } catch (e) {
        console.error("Failed to parse saved location", e)
      }
    } else {
      // Default to Bangalore, Indiranagar
      const defaultCity = cities.find((c) => c.id === "bangalore")
      if (defaultCity) {
        setSelectedCity(defaultCity)
        const defaultArea = defaultCity.areas.find((a) => a.id === "indiranagar")
        if (defaultArea) {
          setSelectedArea(defaultArea)
          localStorage.setItem(
            "carevia-location",
            JSON.stringify({ cityId: "bangalore", areaId: "indiranagar" })
          )
        }
      }
    }
  }, [])

  const setLocation = (cityId: string, areaId: string) => {
    const city = cities.find((c) => c.id === cityId)
    if (city) {
      setSelectedCity(city)
      const area = city.areas.find((a) => a.id === areaId)
      if (area) {
        setSelectedArea(area)
        localStorage.setItem("carevia-location", JSON.stringify({ cityId, areaId }))
      }
    }
  }

  const setCity = (cityId: string) => {
    const city = cities.find((c) => c.id === cityId)
    if (city) {
      setSelectedCity(city)
      // Auto-select first area
      if (city.areas.length > 0) {
        setSelectedArea(city.areas[0])
        localStorage.setItem(
          "carevia-location",
          JSON.stringify({ cityId, areaId: city.areas[0].id })
        )
      }
    }
  }

  const getNearbyAreas = (): Area[] => {
    if (!selectedCity || !selectedArea) return []
    return selectedCity.areas.filter((a) => selectedArea.nearbyAreas.includes(a.id))
  }

  const getAllAreasInCity = (): Area[] => {
    if (!selectedCity) return []
    return selectedCity.areas
  }

  return (
    <LocationContext.Provider
      value={{
        selectedCity,
        selectedArea,
        setLocation,
        setCity,
        getNearbyAreas,
        getAllAreasInCity,
      }}
    >
      {children}
    </LocationContext.Provider>
  )
}

export function useLocation() {
  const context = useContext(LocationContext)
  if (context === undefined) {
    throw new Error("useLocation must be used within a LocationProvider")
  }
  return context
}
