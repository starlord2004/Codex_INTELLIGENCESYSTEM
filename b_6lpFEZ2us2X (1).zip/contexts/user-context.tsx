"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export interface User {
  id: string
  name: string
  email: string
  phone: string
  createdAt: string
}

export interface HealthPackageBooking {
  id: string
  packageName: string
  packagePrice: number
  userName: string
  userPhone: string
  userEmail: string
  preferredDate: string
  preferredTime: string
  bookedAt: string
  status: "confirmed" | "pending" | "completed" | "cancelled"
}

export interface DoctorAppointment {
  id: string
  doctorName: string
  doctorSpecialty: string
  clinicName: string
  clinicAddress: string
  appointmentDate: string
  appointmentTime: string
  reason: string
  status: "completed" | "upcoming" | "cancelled"
  notes?: string
  bookedAt: string
}

export interface Prescription {
  id: string
  fileName: string
  fileUrl: string
  fileType: "application/pdf" | "image/jpeg" | "image/png" | "image/jpg" | string
  uploadedDate: string
  doctorName?: string
  description?: string
}

interface UserContextType {
  user: User | null
  isLoggedIn: boolean
  login: (email: string, password: string) => boolean
  signup: (name: string, email: string, phone: string, password: string) => boolean
  logout: () => void
  bookings: HealthPackageBooking[]
  addBooking: (booking: Omit<HealthPackageBooking, "id" | "bookedAt" | "status">) => void
  getBookings: () => HealthPackageBooking[]
  appointments: DoctorAppointment[]
  addAppointment: (appointment: Omit<DoctorAppointment, "id" | "bookedAt">) => void
  getAppointments: () => DoctorAppointment[]
  prescriptions: Prescription[]
  addPrescription: (prescription: Omit<Prescription, "id" | "uploadedDate">) => void
  getPrescriptions: () => Prescription[]
  removePrescription: (prescriptionId: string) => void
}

const UserContext = createContext<UserContextType | undefined>(undefined)

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [bookings, setBookings] = useState<HealthPackageBooking[]>([])
  const [appointments, setAppointments] = useState<DoctorAppointment[]>([])
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([])

  // Load user, bookings, appointments and prescriptions from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem("carevia-user")
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser))
      } catch (e) {
        console.error("Failed to parse saved user", e)
      }
    }

    const savedBookings = localStorage.getItem("carevia-bookings")
    if (savedBookings) {
      try {
        setBookings(JSON.parse(savedBookings))
      } catch (e) {
        console.error("Failed to parse saved bookings", e)
      }
    }

    const savedAppointments = localStorage.getItem("carevia-appointments")
    if (savedAppointments) {
      try {
        setAppointments(JSON.parse(savedAppointments))
      } catch (e) {
        console.error("Failed to parse saved appointments", e)
      }
    }

    const savedPrescriptions = localStorage.getItem("carevia-prescriptions")
    if (savedPrescriptions) {
      try {
        setPrescriptions(JSON.parse(savedPrescriptions))
      } catch (e) {
        console.error("Failed to parse saved prescriptions", e)
      }
    }
  }, [])

  const login = (email: string, password: string): boolean => {
    // Check if user exists in localStorage
    const savedUsers = localStorage.getItem("carevia-users")
    if (savedUsers) {
      try {
        const users = JSON.parse(savedUsers) as Array<User & { password: string }>
        const foundUser = users.find((u) => u.email === email && u.password === password)
        if (foundUser) {
          const { password: _, ...userWithoutPassword } = foundUser
          setUser(userWithoutPassword)
          localStorage.setItem("carevia-user", JSON.stringify(userWithoutPassword))
          return true
        }
      } catch (e) {
        console.error("Failed to parse users", e)
      }
    }
    return false
  }

  const signup = (name: string, email: string, phone: string, password: string): boolean => {
    // Check if email already exists
    const savedUsers = localStorage.getItem("carevia-users")
    let users: Array<User & { password: string }> = []
    
    if (savedUsers) {
      try {
        users = JSON.parse(savedUsers)
        if (users.some((u) => u.email === email)) {
          return false // Email already exists
        }
      } catch (e) {
        console.error("Failed to parse users", e)
      }
    }

    const newUser: User & { password: string } = {
      id: `user-${Date.now()}`,
      name,
      email,
      phone,
      password,
      createdAt: new Date().toISOString(),
    }

    users.push(newUser)
    localStorage.setItem("carevia-users", JSON.stringify(users))

    // Auto-login after signup
    const { password: _, ...userWithoutPassword } = newUser
    setUser(userWithoutPassword)
    localStorage.setItem("carevia-user", JSON.stringify(userWithoutPassword))

    return true
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("carevia-user")
  }

  const addBooking = (bookingData: Omit<HealthPackageBooking, "id" | "bookedAt" | "status">) => {
    const newBooking: HealthPackageBooking = {
      ...bookingData,
      id: `booking-${Date.now()}`,
      bookedAt: new Date().toISOString(),
      status: "confirmed",
    }

    const updatedBookings = [...bookings, newBooking]
    setBookings(updatedBookings)
    localStorage.setItem("carevia-bookings", JSON.stringify(updatedBookings))
  }

  const getBookings = (): HealthPackageBooking[] => {
    return bookings
  }

  const addAppointment = (appointmentData: Omit<DoctorAppointment, "id" | "bookedAt">) => {
    const newAppointment: DoctorAppointment = {
      ...appointmentData,
      id: `appointment-${Date.now()}`,
      bookedAt: new Date().toISOString(),
    }

    const updatedAppointments = [...appointments, newAppointment]
    setAppointments(updatedAppointments)
    localStorage.setItem("carevia-appointments", JSON.stringify(updatedAppointments))
  }

  const getAppointments = (): DoctorAppointment[] => {
    return appointments
  }

  const addPrescription = (prescriptionData: Omit<Prescription, "id" | "uploadedDate">) => {
    const newPrescription: Prescription = {
      ...prescriptionData,
      id: `prescription-${Date.now()}`,
      uploadedDate: new Date().toISOString(),
    }

    const updatedPrescriptions = [...prescriptions, newPrescription]
    setPrescriptions(updatedPrescriptions)
    localStorage.setItem("carevia-prescriptions", JSON.stringify(updatedPrescriptions))
  }

  const getPrescriptions = (): Prescription[] => {
    return prescriptions
  }

  const removePrescription = (prescriptionId: string) => {
    const updatedPrescriptions = prescriptions.filter((p) => p.id !== prescriptionId)
    setPrescriptions(updatedPrescriptions)
    localStorage.setItem("carevia-prescriptions", JSON.stringify(updatedPrescriptions))
  }

  return (
    <UserContext.Provider
      value={{
        user,
        isLoggedIn: !!user,
        login,
        signup,
        logout,
        bookings,
        addBooking,
        getBookings,
        appointments,
        addAppointment,
        getAppointments,
        prescriptions,
        addPrescription,
        getPrescriptions,
        removePrescription,
      }}
    >
      {children}
    </UserContext.Provider>
  )
}

export function useUser() {
  const context = useContext(UserContext)
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider")
  }
  return context
}
