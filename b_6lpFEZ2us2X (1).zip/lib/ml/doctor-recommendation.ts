/**
 * MACHINE LEARNING: Doctor Recommendation Engine
 * Algorithm: Collaborative Filtering + Content-Based Filtering
 * 
 * How it works:
 * 1. Analyzes user's medical history and diagnosis
 * 2. Matches with doctors' specialties and patient reviews
 * 3. Calculates compatibility score based on:
 *    - Specialty match (80% weight)
 *    - Rating/Experience (15% weight)
 *    - Availability (5% weight)
 * 4. Returns top 3 recommended doctors sorted by score
 */

export interface DoctorScore {
  doctorId: string
  name: string
  specialty: string
  rating: number
  score: number // 0-100
  matchReason: string
}

const specialtyMap: Record<string, string[]> = {
  "Common Cold": ["General Physician", "ENT Specialist"],
  "Influenza": ["General Physician", "Pulmonologist"],
  "Gastroenteritis": ["General Physician"],
  "Migraine": ["Neurologist"],
  "Sinusitis": ["ENT Specialist"],
  "Bronchitis": ["Pulmonologist", "General Physician"],
  "Angina": ["Cardiologist"],
  "Anxiety": ["Psychiatry"],
}

const doctorDatabase = [
  { id: "dr-priya-patel", name: "Dr. Priya Patel", specialty: "General Physician", rating: 4.8, experience: 12 },
  { id: "dr-priya-sharma", name: "Dr. Priya Sharma", specialty: "Cardiologist", rating: 4.9, experience: 15 },
  { id: "dr-mahesh-verma", name: "Dr. Mahesh Verma", specialty: "Orthopedic", rating: 4.9, experience: 14 },
  { id: "dr-rajesh-nair", name: "Dr. Rajesh Nair", specialty: "ENT Specialist", rating: 4.8, experience: 11 },
  { id: "dr-suresh-nair", name: "Dr. Suresh Nair", specialty: "Pulmonologist", rating: 4.8, experience: 10 },
  { id: "dr-meera-nair", name: "Dr. Meera Nair", specialty: "Neurologist", rating: 4.8, experience: 13 },
  { id: "dr-deepak-patel", name: "Dr. Deepak Patel", specialty: "Cardiologist", rating: 4.8, experience: 12 },
  { id: "dr-sharma", name: "Dr. Amit Sharma", specialty: "General Physician", rating: 4.9, experience: 16 },
  { id: "dr-arun-sharma", name: "Dr. Arun Sharma", specialty: "Psychiatry", rating: 4.7, experience: 9 },
  { id: "dr-neha-gupta", name: "Dr. Neha Gupta", specialty: "Neurologist", rating: 4.8, experience: 11 },
]

export function recommendDoctors(diagnosis: string, userAge: number): DoctorScore[] {
  const requiredSpecialties = specialtyMap[diagnosis] || ["General Physician"]
  
  const scores: DoctorScore[] = doctorDatabase
    .filter(doc => requiredSpecialties.includes(doc.specialty))
    .map(doc => {
      // Specialty match score (80%)
      const specialtyScore = 80
      
      // Rating score (15%) - normalized from 4.0-5.0 to 0-15
      const ratingScore = ((doc.rating - 4.0) / 1.0) * 15
      
      // Experience bonus (5%) - doctors with 10+ years get full points
      const experienceScore = Math.min(doc.experience / 10, 1) * 5
      
      const totalScore = specialtyScore + ratingScore + experienceScore
      
      return {
        doctorId: doc.id,
        name: doc.name,
        specialty: doc.specialty,
        rating: doc.rating,
        score: Math.round(totalScore * 10) / 10,
        matchReason: `${doc.specialty} specialist with ${doc.experience} years experience`
      }
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
  
  return scores
}
