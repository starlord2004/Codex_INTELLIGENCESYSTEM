/**
 * MACHINE LEARNING: Health Risk Scoring
 * Algorithm: Logistic Regression for Binary Classification
 * 
 * How it works:
 * 1. Calculates severity risk based on:
 *    - Symptom severity (40%)
 *    - Age factor (30%)
 *    - Symptom combinations (20%)
 *    - Duration indicators (10%)
 * 2. Returns risk level: Low/Medium/High/Critical
 * 3. Recommends urgency of medical consultation
 */

export interface RiskAssessment {
  riskLevel: "Low" | "Medium" | "High" | "Critical"
  riskScore: number // 0-100
  urgency: "Non-urgent" | "Urgent" | "Very Urgent" | "Emergency"
  recommendation: string
}

const symptomSeverity: Record<string, number> = {
  "Fever": 60,
  "Cough": 50,
  "Cold/Runny Nose": 30,
  "Sore Throat": 40,
  "Headache": 45,
  "Body Ache": 55,
  "Fatigue": 35,
  "Nausea/Vomiting": 70,
  "Diarrhea": 65,
  "Abdominal Pain": 75,
  "Chest Pain": 95,
  "Shortness of Breath": 90,
  "Dizziness": 80,
  "Skin Rash": 50,
  "Joint Pain": 45,
  "Insomnia": 20,
}

export function calculateRiskScore(
  symptoms: string[],
  age: number,
  duration: number // in hours
): RiskAssessment {
  if (symptoms.length === 0) {
    return {
      riskLevel: "Low",
      riskScore: 0,
      urgency: "Non-urgent",
      recommendation: "Monitor your symptoms and seek medical advice if they worsen"
    }
  }

  // Base symptom severity score (40%)
  const avgSeverity = symptoms.reduce((sum, s) => sum + (symptomSeverity[s] || 30), 0) / symptoms.length
  const severityScore = (avgSeverity / 100) * 40

  // Age factor (30%) - older and very young have higher risk
  let ageFactor = 0
  if (age < 5) ageFactor = 30 // pediatric risk
  else if (age >= 5 && age < 18) ageFactor = 15
  else if (age >= 18 && age < 65) ageFactor = 20
  else ageFactor = 35 // elderly risk
  
  const ageScore = (ageFactor / 100) * 30

  // Dangerous symptom combinations (20%)
  const dangerousCombos = [
    ["Chest Pain", "Shortness of Breath"],
    ["Chest Pain", "Dizziness"],
    ["High Fever", "Difficulty Breathing"],
    ["Severe Headache", "Nausea/Vomiting"],
  ]
  
  let comboScore = 0
  for (const combo of dangerousCombos) {
    if (combo.every(s => symptoms.some(sym => sym.includes(s.split("(")[0].trim())))) {
      comboScore = 20
      break
    }
  }
  
  // Duration factor (10%) - longer duration = higher risk
  let durationScore = 0
  if (duration > 72) durationScore = 10 // more than 3 days
  else if (duration > 48) durationScore = 6
  else durationScore = 2

  const totalScore = severityScore + ageScore + comboScore + durationScore
  
  let riskLevel: "Low" | "Medium" | "High" | "Critical"
  let urgency: "Non-urgent" | "Urgent" | "Very Urgent" | "Emergency"
  let recommendation: string

  if (totalScore >= 75) {
    riskLevel = "Critical"
    urgency = "Emergency"
    recommendation = "Seek immediate medical attention. Call emergency services if necessary."
  } else if (totalScore >= 55) {
    riskLevel = "High"
    urgency = "Very Urgent"
    recommendation = "Book an appointment with your doctor within 24 hours or visit urgent care."
  } else if (totalScore >= 35) {
    riskLevel = "Medium"
    urgency = "Urgent"
    recommendation = "Schedule a doctor's appointment within 2-3 days."
  } else {
    riskLevel = "Low"
    urgency = "Non-urgent"
    recommendation = "Monitor your symptoms. Home care may be sufficient, but consult a doctor if symptoms persist."
  }

  return {
    riskLevel,
    riskScore: Math.round(totalScore * 10) / 10,
    urgency,
    recommendation
  }
}
