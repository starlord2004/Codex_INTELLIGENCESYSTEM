/**
 * MACHINE LEARNING: Patient Health Profile Analysis
 * Algorithm: Data Aggregation + Pattern Recognition
 * 
 * How it works:
 * 1. Builds comprehensive patient health profile
 * 2. Analyzes health patterns over time
 * 3. Identifies risk factors and trends
 * 4. Predicts future health concerns
 */

export interface HealthMetric {
  name: string
  value: number
  status: "Healthy" | "Warning" | "Critical"
  trend: "Improving" | "Stable" | "Declining"
}

export interface PatientHealthProfile {
  patientId: string
  age: number
  commonSymptoms: string[]
  riskFactors: string[]
  healthScore: number // 0-100
  recommendations: string[]
  metrics: HealthMetric[]
}

export function buildHealthProfile(
  patientId: string,
  age: number,
  medicalHistory: string[],
  recentSymptoms: string[]
): PatientHealthProfile {
  // Analyze health patterns
  const commonSymptoms = getCommonSymptoms(recentSymptoms)
  const riskFactors = identifyRiskFactors(age, medicalHistory, commonSymptoms)
  
  // Calculate health score
  const healthScore = calculateHealthScore(age, riskFactors, medicalHistory)
  
  // Generate recommendations
  const recommendations = generateRecommendations(riskFactors, healthScore, age)
  
  // Create health metrics
  const metrics = createHealthMetrics(age, riskFactors, healthScore)
  
  return {
    patientId,
    age,
    commonSymptoms,
    riskFactors,
    healthScore,
    recommendations,
    metrics
  }
}

function getCommonSymptoms(symptoms: string[]): string[] {
  // Find most frequent symptoms
  const frequency: Record<string, number> = {}
  symptoms.forEach(s => {
    frequency[s] = (frequency[s] || 0) + 1
  })
  
  return Object.entries(frequency)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)
    .map(([symptom]) => symptom)
}

function identifyRiskFactors(age: number, medicalHistory: string[], symptoms: string[]): string[] {
  const factors: string[] = []
  
  // Age-based risks
  if (age < 5) factors.push("Pediatric immunocompromised")
  if (age > 65) factors.push("Age-related decline")
  
  // Medical history risks
  if (medicalHistory.some(h => h.toLowerCase().includes("heart"))) {
    factors.push("Cardiovascular concerns")
  }
  if (medicalHistory.some(h => h.toLowerCase().includes("diabetes"))) {
    factors.push("Diabetes management")
  }
  
  // Symptom-based risks
  if (symptoms.includes("Chest Pain")) factors.push("Cardiac risk")
  if (symptoms.includes("Shortness of Breath")) factors.push("Respiratory concern")
  if (symptoms.includes("Persistent Fever")) factors.push("Infection risk")
  
  return [...new Set(factors)] // Remove duplicates
}

function calculateHealthScore(age: number, riskFactors: string[], medicalHistory: string[]): number {
  let score = 100
  
  // Age penalty
  if (age < 5) score -= 10
  if (age > 65) score -= 15
  
  // Risk factor penalty
  score -= riskFactors.length * 10
  
  // Medical history penalty
  score -= Math.min(medicalHistory.length * 5, 30)
  
  return Math.max(score, 0)
}

function generateRecommendations(riskFactors: string[], healthScore: number, age: number): string[] {
  const recommendations: string[] = []
  
  if (healthScore < 50) {
    recommendations.push("Schedule a comprehensive health checkup immediately")
  } else if (healthScore < 70) {
    recommendations.push("Schedule a health checkup within the next month")
  }
  
  if (riskFactors.includes("Cardiovascular concerns")) {
    recommendations.push("Regular cardiac monitoring recommended")
  }
  
  if (riskFactors.includes("Diabetes management")) {
    recommendations.push("Regular glucose monitoring and specialist consultation")
  }
  
  if (age > 60) {
    recommendations.push("Annual comprehensive health screening recommended")
  }
  
  recommendations.push("Maintain regular exercise and balanced diet")
  
  return recommendations
}

function createHealthMetrics(age: number, riskFactors: string[], healthScore: number): HealthMetric[] {
  return [
    {
      name: "Overall Health Score",
      value: healthScore,
      status: healthScore > 70 ? "Healthy" : healthScore > 50 ? "Warning" : "Critical",
      trend: "Stable"
    },
    {
      name: "Risk Level",
      value: riskFactors.length * 20,
      status: riskFactors.length === 0 ? "Healthy" : riskFactors.length < 3 ? "Warning" : "Critical",
      trend: "Stable"
    },
    {
      name: "Age Health Index",
      value: Math.max(0, 100 - (age > 65 ? (age - 65) * 2 : age < 5 ? 15 : 0)),
      status: age > 75 ? "Critical" : age > 65 ? "Warning" : "Healthy",
      trend: "Declining"
    }
  ]
}
