/**
 * MACHINE LEARNING: Lab Test Recommendation
 * Algorithm: Decision Trees + Rule-Based System
 * 
 * How it works:
 * 1. Analyzes symptoms and patient profile
 * 2. Uses decision tree rules for test recommendation
 * 3. Considers:
 *    - Symptom patterns (50%)
 *    - Age and risk factors (30%)
 *    - Test frequency recommendations (20%)
 * 4. Returns recommended lab tests with urgency
 */

export interface LabTestRecommendation {
  testName: string
  urgency: "Routine" | "Recommended" | "Urgent"
  reason: string
  estimatedCost: number
  estimatedResults: string // e.g., "24-48 hours"
}

interface LabTestData {
  name: string
  cost: number
  resultsTime: string
  symptoms: string[]
  minAge: number
}

const labTestDatabase: LabTestData[] = [
  {
    name: "Complete Blood Count (CBC)",
    cost: 500,
    resultsTime: "24-48 hours",
    symptoms: ["Fever", "Fatigue", "Body Ache"],
    minAge: 0
  },
  {
    name: "Throat Culture",
    cost: 800,
    resultsTime: "24-48 hours",
    symptoms: ["Sore Throat", "Fever"],
    minAge: 0
  },
  {
    name: "COVID-19 RT-PCR",
    cost: 600,
    resultsTime: "24 hours",
    symptoms: ["Cough", "Fever", "Shortness of Breath"],
    minAge: 0
  },
  {
    name: "Chest X-Ray",
    cost: 1200,
    resultsTime: "1-2 hours",
    symptoms: ["Cough", "Shortness of Breath", "Chest Pain"],
    minAge: 0
  },
  {
    name: "Abdominal Ultrasound",
    cost: 1500,
    resultsTime: "1-2 hours",
    symptoms: ["Abdominal Pain", "Nausea/Vomiting", "Diarrhea"],
    minAge: 0
  },
  {
    name: "Blood Glucose Test",
    cost: 300,
    resultsTime: "1 hour",
    symptoms: ["Fatigue", "Nausea/Vomiting"],
    minAge: 30
  },
  {
    name: "Lipid Panel",
    cost: 1000,
    resultsTime: "24-48 hours",
    symptoms: ["Chest Pain"],
    minAge: 35
  },
  {
    name: "MRI Brain",
    cost: 4000,
    resultsTime: "2-3 hours",
    symptoms: ["Headache", "Dizziness"],
    minAge: 0
  },
  {
    name: "CT Scan",
    cost: 3500,
    resultsTime: "1-2 hours",
    symptoms: ["Chest Pain", "Abdominal Pain"],
    minAge: 0
  },
  {
    name: "Stool Test",
    cost: 600,
    resultsTime: "48 hours",
    symptoms: ["Diarrhea", "Abdominal Pain"],
    minAge: 0
  },
]

export function recommendLabTests(
  symptoms: string[],
  age: number,
  severity: "Low" | "Medium" | "High" | "Critical"
): LabTestRecommendation[] {
  const recommendations: LabTestRecommendation[] = []
  
  const matchedTests = labTestDatabase.filter(test => {
    // Age check
    if (age < test.minAge) return false
    
    // Symptom overlap check
    return test.symptoms.some(ts => symptoms.some(s => s.toLowerCase().includes(ts.toLowerCase())))
  })
  
  matchedTests.forEach(test => {
    // Determine urgency based on severity
    let urgency: "Routine" | "Recommended" | "Urgent"
    
    if (severity === "Critical") {
      urgency = "Urgent"
    } else if (severity === "High") {
      urgency = "Recommended"
    } else {
      urgency = "Routine"
    }
    
    // Additional urgency logic for specific tests
    if (["Chest X-Ray", "CT Scan", "MRI Brain"].includes(test.name) && severity !== "Low") {
      urgency = "Urgent"
    }
    
    recommendations.push({
      testName: test.name,
      urgency,
      reason: `Recommended for investigating ${test.symptoms.join(", ")}`,
      estimatedCost: test.cost,
      estimatedResults: test.resultsTime
    })
  })
  
  // Sort by urgency and cost
  return recommendations
    .sort((a, b) => {
      const urgencyOrder = { "Urgent": 0, "Recommended": 1, "Routine": 2 }
      const aDiff = urgencyOrder[a.urgency] - urgencyOrder[b.urgency]
      return aDiff !== 0 ? aDiff : a.estimatedCost - b.estimatedCost
    })
    .slice(0, 5)
}
