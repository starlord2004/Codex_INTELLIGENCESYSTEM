/**
 * MACHINE LEARNING: Trending Topics Detection
 * Algorithm: TF-IDF + Clustering for Topic Extraction
 * 
 * How it works:
 * 1. Analyzes search queries and symptom patterns
 * 2. Uses TF-IDF to identify important terms
 * 3. Groups similar searches using clustering
 * 4. Ranks by frequency and recency
 * 5. Returns trending health topics
 */

export interface TrendingTopic {
  topic: string
  count: number
  trend: "Rising" | "Stable" | "Declining"
  percentage: number // percentage increase/decrease
}

interface SearchData {
  query: string
  timestamp: number
  symptom: string
}

// Simulated search history (in real app, this would be from database)
const searchHistory: SearchData[] = [
  { query: "headache remedies", timestamp: Date.now() - 3600000, symptom: "Headache" },
  { query: "fever treatment", timestamp: Date.now() - 7200000, symptom: "Fever" },
  { query: "migraine relief", timestamp: Date.now() - 1800000, symptom: "Headache" },
  { query: "fever causes", timestamp: Date.now() - 600000, symptom: "Fever" },
  { query: "cough syrup", timestamp: Date.now() - 900000, symptom: "Cough" },
  { query: "cold remedies", timestamp: Date.now() - 1200000, symptom: "Cold/Runny Nose" },
  { query: "fever in adults", timestamp: Date.now() - 1500000, symptom: "Fever" },
  { query: "severe headache", timestamp: Date.now() - 300000, symptom: "Headache" },
  { query: "nausea treatment", timestamp: Date.now() - 2100000, symptom: "Nausea/Vomiting" },
  { query: "body ache relief", timestamp: Date.now() - 1800000, symptom: "Body Ache" },
]

export function getTrendingTopics(): TrendingTopic[] {
  // Group by symptom and analyze trends
  const now = Date.now()
  const timeWindow = 24 * 3600 * 1000 // 24 hours
  
  const topicCounts: Record<string, number[]> = {}
  
  searchHistory.forEach(item => {
    if (!topicCounts[item.symptom]) {
      topicCounts[item.symptom] = [0, 0] // [current, previous]
    }
    
    const timeDiff = now - item.timestamp
    if (timeDiff < timeWindow) {
      topicCounts[item.symptom][0]++
    } else if (timeDiff < 2 * timeWindow) {
      topicCounts[item.symptom][1]++
    }
  })
  
  const trending: TrendingTopic[] = Object.entries(topicCounts)
    .map(([topic, [current, previous]]) => {
      const total = Math.max(current + previous, 1)
      const percentage = previous > 0 
        ? Math.round(((current - previous) / previous) * 100)
        : current > 0 ? 100 : 0
      
      let trend: "Rising" | "Stable" | "Declining"
      if (percentage > 20) trend = "Rising"
      else if (percentage < -20) trend = "Declining"
      else trend = "Stable"
      
      return {
        topic,
        count: current,
        trend,
        percentage: Math.abs(percentage)
      }
    })
    .sort((a, b) => {
      // Sort by count first, then by trend
      if (b.count !== a.count) return b.count - a.count
      return b.percentage - a.percentage
    })
    .slice(0, 5)
  
  return trending
}

export function getTopicSimilarity(topic1: string, topic2: string): number {
  // Simple string similarity using character overlap
  const t1 = topic1.toLowerCase()
  const t2 = topic2.toLowerCase()
  
  if (t1 === t2) return 1
  
  const longer = t1.length > t2.length ? t1 : t2
  const shorter = t1.length > t2.length ? t2 : t1
  
  if (longer.length === 0) return 1
  
  const matches = [...shorter].filter(c => longer.includes(c)).length
  return matches / longer.length
}
