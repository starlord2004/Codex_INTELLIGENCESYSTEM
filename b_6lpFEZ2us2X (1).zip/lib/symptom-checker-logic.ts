"use client"

// Define question types for different symptom patterns
interface Question {
  id: string
  question: string
  options: string[]
  detail?: string
}

// Disease database with age-based severity adjustments
export const diseaseDatabase: Record<string, {
  name: string
  description: string
  medicines: Array<{ name: string; price: number }>
  severity: "mild" | "moderate" | "severe"
  consultDoctor: boolean
  recommendedSpecialties: string[]
  ageFactors?: {
    pediatric: number
    adult: number
    elderly: number
  }
}> = {
  common_cold: {
    name: "Common Cold",
    description: "A viral infection affecting the upper respiratory tract, usually self-limiting within 7-10 days.",
    medicines: [
      { name: "Paracetamol 500mg", price: 45 },
      { name: "Cough Syrup", price: 120 },
      { name: "Vitamin C Supplement", price: 85 },
      { name: "Honey-Lemon Drink", price: 60 }
    ],
    severity: "mild",
    consultDoctor: false,
    recommendedSpecialties: ["General Physician", "ENT Specialist"],
    ageFactors: { pediatric: 1.2, adult: 1.0, elderly: 1.3 }
  },
  flu: {
    name: "Influenza (Flu)",
    description: "A more severe viral infection that can cause systemic symptoms including fever, body aches, and fatigue.",
    medicines: [
      { name: "Oseltamivir (Tamiflu)", price: 280 },
      { name: "Ibuprofen 400mg", price: 65 },
      { name: "Antitussive", price: 140 },
      { name: "Electrolyte Drink", price: 80 }
    ],
    severity: "moderate",
    consultDoctor: true,
    recommendedSpecialties: ["General Physician", "Pulmonologist"],
    ageFactors: { pediatric: 1.3, adult: 1.0, elderly: 1.5 }
  },
  gastroenteritis: {
    name: "Gastroenteritis",
    description: "An inflammation of the stomach and intestines, commonly called stomach flu or food poisoning.",
    medicines: [
      { name: "Loperamide", price: 50 },
      { name: "Omeprazole", price: 95 },
      { name: "Electrolyte Solution", price: 75 },
      { name: "Ginger Tea", price: 40 },
      { name: "Probiotics", price: 150 }
    ],
    severity: "moderate",
    consultDoctor: true,
    recommendedSpecialties: ["General Physician"],
    ageFactors: { pediatric: 1.4, adult: 1.0, elderly: 1.3 }
  },
  migraine: {
    name: "Migraine",
    description: "A neurological condition characterized by intense, throbbing headaches often accompanied by nausea.",
    medicines: [
      { name: "Ibuprofen 400mg", price: 65 },
      { name: "Sumatriptan", price: 320 },
      { name: "Antimigraine Spray", price: 180 },
      { name: "Relaxation Aids", price: 200 }
    ],
    severity: "moderate",
    consultDoctor: true,
    recommendedSpecialties: ["Neurologist"],
    ageFactors: { pediatric: 0.8, adult: 1.0, elderly: 0.9 }
  },
  sinusitis: {
    name: "Sinusitis",
    description: "Inflammation of the sinuses causing nasal congestion, sore throat, and headache.",
    medicines: [
      { name: "Nasal Decongestant", price: 110 },
      { name: "Antibiotics (Amoxicillin)", price: 140 },
      { name: "Saline Rinse", price: 95 },
      { name: "Ibuprofen", price: 65 }
    ],
    severity: "mild",
    consultDoctor: false,
    recommendedSpecialties: ["ENT Specialist"],
    ageFactors: { pediatric: 1.1, adult: 1.0, elderly: 1.2 }
  },
  bronchitis: {
    name: "Bronchitis",
    description: "Inflammation of the bronchial tubes that carry air to the lungs, causing persistent cough.",
    medicines: [
      { name: "Cough Suppressant", price: 120 },
      { name: "Expectorant", price: 135 },
      { name: "Corticosteroid Inhaler", price: 450 },
      { name: "Antibiotics (if bacterial)", price: 160 }
    ],
    severity: "moderate",
    consultDoctor: true,
    recommendedSpecialties: ["Pulmonologist", "General Physician"],
    ageFactors: { pediatric: 1.2, adult: 1.0, elderly: 1.4 }
  },
  angina: {
    name: "Angina",
    description: "Chest pain caused by reduced blood flow to the heart. Requires immediate medical attention.",
    medicines: [
      { name: "Nitroglycerin", price: 250 },
      { name: "Beta-blockers", price: 180 },
      { name: "Aspirin", price: 55 }
    ],
    severity: "severe",
    consultDoctor: true,
    recommendedSpecialties: ["Cardiologist"],
    ageFactors: { pediatric: 0.1, adult: 1.0, elderly: 1.8 }
  },
  anxiety: {
    name: "Anxiety Disorder",
    description: "A mental health condition characterized by excessive worry, dizziness, and chest discomfort.",
    medicines: [
      { name: "SSRIs (Sertraline)", price: 120 },
      { name: "Anti-anxiety Medication", price: 95 },
      { name: "Valerian Root (Herbal)", price: 85 },
      { name: "Magnesium Supplement", price: 110 }
    ],
    severity: "moderate",
    consultDoctor: true,
    recommendedSpecialties: ["Psychiatry"],
    ageFactors: { pediatric: 0.9, adult: 1.0, elderly: 1.1 }
  },
}

// Generate context-specific follow-up questions
export function generateFollowUpQuestions(symptoms: string[]): Question[] {
  const symptomSet = new Set(symptoms)
  const questions: Question[] = []

  // Check for respiratory symptoms
  if (
    symptomSet.has("Cough") ||
    symptomSet.has("Cold/Runny Nose") ||
    symptomSet.has("Sore Throat")
  ) {
    questions.push({
      id: "cough_duration",
      question: "How long have you had this cough?",
      options: ["Less than 3 days", "3-7 days", "More than 7 days"],
      detail: "This helps us determine if it's acute or chronic."
    })

    questions.push({
      id: "cough_type",
      question: "What type of cough are you experiencing?",
      options: [
        "Dry cough (no mucus)",
        "Wet cough (with mucus)",
        "Severe/Persistent",
      ],
      detail: "The cough characteristics indicate different conditions."
    })
  }

  // Check for fever
  if (symptomSet.has("Fever")) {
    questions.push({
      id: "fever_severity",
      question: "How high is your fever?",
      options: [
        "Mild (99-100°F)",
        "Moderate (100-103°F)",
        "High (Above 103°F)",
      ],
      detail: "Temperature helps determine the severity of infection."
    })
  }

  // Check for gastrointestinal symptoms
  if (
    symptomSet.has("Nausea/Vomiting") ||
    symptomSet.has("Diarrhea") ||
    symptomSet.has("Abdominal Pain")
  ) {
    questions.push({
      id: "gi_onset",
      question: "Did these symptoms start suddenly or gradually?",
      options: ["Sudden onset", "Gradual onset", "On and off"],
      detail: "Sudden onset often indicates acute infection."
    })

    questions.push({
      id: "gi_associated",
      question: "Are these symptoms associated with anything?",
      options: [
        "Recent food consumption",
        "Travel or exposure to sick people",
        "No clear trigger",
      ],
      detail: "Understanding triggers helps narrow down causes."
    })
  }

  // Check for headache
  if (symptomSet.has("Headache")) {
    questions.push({
      id: "headache_intensity",
      question: "Rate the intensity of your headache",
      options: ["Mild (1-3/10)", "Moderate (4-6/10)", "Severe (7-10/10)"],
      detail: "Pain intensity indicates severity."
    })

    if (symptomSet.has("Nausea/Vomiting")) {
      questions.push({
        id: "headache_location",
        question: "Where is the pain concentrated?",
        options: [
          "One side of head",
          "Both sides/frontal",
          "Back of head/neck",
        ],
        detail: "Location helps identify specific headache types."
      })
    }
  }

  // Check for chest symptoms
  if (symptomSet.has("Chest Pain") || symptomSet.has("Shortness of Breath")) {
    questions.push({
      id: "chest_pain_character",
      question: "Describe the chest pain/discomfort",
      options: [
        "Sharp, stabbing pain",
        "Dull, aching pressure",
        "Tightness/heaviness",
      ],
      detail: "Pain characteristics indicate different heart conditions."
    })

    questions.push({
      id: "chest_triggers",
      question: "What makes it better or worse?",
      options: [
        "Worse with activity",
        "Better with rest",
        "No clear pattern",
      ],
      detail: "Triggers help differentiate conditions."
    })
  }

  // Check for dizziness
  if (symptomSet.has("Dizziness")) {
    questions.push({
      id: "dizziness_type",
      question: "What type of dizziness are you experiencing?",
      options: [
        "Room spinning sensation",
        "Lightheadedness/weakness",
        "Loss of balance",
      ],
      detail: "Different types indicate different causes."
    })
  }

  // Check for skin symptoms
  if (symptomSet.has("Skin Rash")) {
    questions.push({
      id: "rash_appearance",
      question: "Describe the rash appearance",
      options: [
        "Red bumps/spots",
        "Itchy/hives",
        "Painful/blistering",
      ],
      detail: "Appearance helps identify the cause."
    })
  }

  // Check for pain symptoms
  if (symptomSet.has("Body Ache") || symptomSet.has("Joint Pain")) {
    questions.push({
      id: "pain_severity",
      question: "How severe is the pain?",
      options: ["Mild discomfort", "Moderate pain", "Severe pain"],
      detail: "Severity helps assess the condition."
    })
  }

  // Check for sleep issues
  if (symptomSet.has("Insomnia")) {
    questions.push({
      id: "sleep_pattern",
      question: "What&apos;s affecting your sleep?",
      options: [
        "Difficulty falling asleep",
        "Frequent waking",
        "Early morning waking",
      ],
      detail: "Sleep pattern helps understand the underlying cause."
    })
  }

  return questions.slice(0, 5) // Limit to 5 questions max for UX
}

// Get age group for demographic weighting
export function getAgeGroup(age: number): "pediatric" | "adult" | "elderly" {
  if (age < 18) return "pediatric"
  if (age >= 65) return "elderly"
  return "adult"
}

// Predict disease based on symptoms and answers
export function predictDiseaseWithFollowUp(
  symptoms: string[],
  followUpAnswers: Record<string, string>,
  age: number
): keyof typeof diseaseDatabase {
  const symptomSet = new Set(symptoms)
  const ageGroup = getAgeGroup(age)
  let scores: Record<keyof typeof diseaseDatabase, number> = {
    common_cold: 0,
    flu: 0,
    gastroenteritis: 0,
    migraine: 0,
    sinusitis: 0,
    bronchitis: 0,
    angina: 0,
    anxiety: 0,
  }

  // Respiratory conditions scoring
  if (symptomSet.has("Cough") || symptomSet.has("Cold/Runny Nose")) {
    scores.common_cold += 2
    scores.sinusitis += 1.5
    scores.bronchitis += 2

    if (followUpAnswers["cough_duration"] === "More than 7 days") {
      scores.bronchitis += 2
      scores.common_cold -= 1
    }

    if (followUpAnswers["cough_type"] === "Wet cough (with mucus)") {
      scores.bronchitis += 1.5
      scores.common_cold += 1
    } else if (followUpAnswers["cough_type"] === "Dry cough (no mucus)") {
      scores.common_cold += 1.5
    }
  }

  if (symptomSet.has("Sore Throat")) {
    scores.common_cold += 1.5
    scores.sinusitis += 1
    scores.flu += 1
  }

  // Fever indicators
  if (symptomSet.has("Fever")) {
    scores.flu += 2
    scores.common_cold += 1

    if (followUpAnswers["fever_severity"] === "High (Above 103°F)") {
      scores.flu += 2
    }
  }

  // Gastrointestinal conditions
  if (symptomSet.has("Nausea/Vomiting") && symptomSet.has("Diarrhea")) {
    scores.gastroenteritis += 3
    scores.flu += 1

    if (followUpAnswers["gi_onset"] === "Sudden onset") {
      scores.gastroenteritis += 1
    }
  } else if (symptomSet.has("Abdominal Pain")) {
    scores.gastroenteritis += 1
  }

  // Headache and migraine indicators
  if (symptomSet.has("Headache")) {
    if (
      symptomSet.has("Nausea/Vomiting") ||
      symptomSet.has("Body Ache")
    ) {
      scores.migraine += 2
      scores.flu += 1
    } else {
      scores.migraine += 1.5
    }

    if (
      followUpAnswers["headache_intensity"] === "Severe (7-10/10)" &&
      symptomSet.has("Nausea/Vomiting")
    ) {
      scores.migraine += 1.5
    }

    if (
      followUpAnswers["headache_location"] === "One side of head" &&
      symptomSet.has("Nausea/Vomiting")
    ) {
      scores.migraine += 2
    }
  }

  // Body ache and fatigue
  if (symptomSet.has("Body Ache") || symptomSet.has("Fatigue")) {
    scores.flu += 1.5
    scores.common_cold += 0.5
  }

  // Chest and respiratory distress
  if (symptomSet.has("Chest Pain")) {
    scores.angina += 3
    scores.anxiety += 2

    if (followUpAnswers["chest_pain_character"] === "Dull, aching pressure") {
      scores.angina += 1.5
    }

    if (followUpAnswers["chest_triggers"] === "Worse with activity") {
      scores.angina += 2
    }
  }

  if (symptomSet.has("Shortness of Breath")) {
    scores.angina += 1
    scores.bronchitis += 2
  }

  // Dizziness indicators
  if (symptomSet.has("Dizziness")) {
    scores.anxiety += 2
    scores.angina += 1

    if (followUpAnswers["dizziness_type"] === "Lightheadedness/weakness") {
      scores.anxiety += 1
    }
  }

  // Skin rash
  if (symptomSet.has("Skin Rash")) {
    scores.flu += 1
  }

  // Joint pain
  if (symptomSet.has("Joint Pain")) {
    scores.flu += 1
  }

  // Insomnia
  if (symptomSet.has("Insomnia")) {
    scores.anxiety += 2
  }

  // Apply age-based weighting
  Object.keys(scores).forEach((disease) => {
    const d = disease as keyof typeof diseaseDatabase
    const disease_info = diseaseDatabase[d]
    if (disease_info.ageFactors) {
      const ageFactor = disease_info.ageFactors[ageGroup]
      scores[d] *= ageFactor
    }
  })

  // Find the disease with the highest score
  let maxScore = -Infinity
  let predictedDisease: keyof typeof diseaseDatabase = "common_cold"

  Object.entries(scores).forEach(([disease, score]) => {
    if (score > maxScore) {
      maxScore = score
      predictedDisease = disease as keyof typeof diseaseDatabase
    }
  })

  return predictedDisease
}
