"use client"

import Link from "next/link"
import { ArrowLeft, Video, MapPin, Star, Clock, DollarSign } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useState } from "react"
import { useLocation } from "@/contexts/location-context"

const specializations = [
  { id: "general", name: "General Practitioner", count: 245 },
  { id: "cardiology", name: "Cardiology", count: 89 },
  { id: "dermatology", name: "Dermatology", count: 156 },
  { id: "pediatrics", name: "Pediatrics", count: 112 },
  { id: "orthopedics", name: "Orthopedics", count: 78 },
  { id: "neurology", name: "Neurology", count: 64 },
  { id: "psychiatry", name: "Psychiatry", count: 52 },
  { id: "gastroenterology", name: "Gastroenterology", count: 43 },
]

const videoDoctors = [
  {
    id: "dr-rajesh-kumar",
    name: "Dr. Rajesh Kumar",
    specialty: "general",
    specialtyName: "General Practitioner",
    rating: 4.8,
    reviews: 324,
    experience: "12 years",
    consultationFee: 299,
    availability: "Today 2:00 PM",
    image: "👨‍⚕️",
  },
  {
    id: "dr-priya-patel",
    name: "Dr. Priya Patel",
    specialty: "general",
    specialtyName: "General Practitioner",
    rating: 4.9,
    reviews: 521,
    experience: "15 years",
    consultationFee: 499,
    availability: "Today 3:30 PM",
    image: "👩‍⚕️",
  },
  {
    id: "dr-priya-sharma",
    name: "Dr. Priya Sharma",
    specialty: "cardiology",
    specialtyName: "Cardiology",
    rating: 4.9,
    reviews: 521,
    experience: "15 years",
    consultationFee: 499,
    availability: "Today 3:30 PM",
    image: "👩‍⚕️",
  },
  {
    id: "dr-amit-patel",
    name: "Dr. Amit Patel",
    specialty: "dermatology",
    specialtyName: "Dermatology",
    rating: 4.7,
    reviews: 298,
    experience: "10 years",
    consultationFee: 399,
    availability: "Tomorrow 10:00 AM",
    image: "👨‍⚕️",
  },
  {
    id: "dr-meera-nair",
    name: "Dr. Meera Nair",
    specialty: "pediatrics",
    specialtyName: "Pediatrics",
    rating: 4.9,
    reviews: 412,
    experience: "11 years",
    consultationFee: 349,
    availability: "Today 4:00 PM",
    image: "👩‍⚕️",
  },
  {
    id: "dr-vikram-singh",
    name: "Dr. Vikram Singh",
    specialty: "orthopedics",
    specialtyName: "Orthopedics",
    rating: 4.8,
    reviews: 267,
    experience: "13 years",
    consultationFee: 449,
    availability: "Tomorrow 2:00 PM",
    image: "👨‍⚕️",
  },
  {
    id: "dr-sarah-johnson",
    name: "Dr. Sarah Johnson",
    specialty: "psychiatry",
    specialtyName: "Psychiatry",
    rating: 4.9,
    reviews: 389,
    experience: "14 years",
    consultationFee: 399,
    availability: "Today 5:00 PM",
    image: "👩‍⚕️",
  },
  {
    id: "dr-neha-gupta",
    name: "Dr. Neha Gupta",
    specialty: "neurology",
    specialtyName: "Neurology",
    rating: 4.8,
    reviews: 456,
    experience: "12 years",
    consultationFee: 499,
    availability: "Tomorrow 11:00 AM",
    image: "👩‍⚕️",
  },
  {
    id: "dr-rohan-desai",
    name: "Dr. Rohan Desai",
    specialty: "gastroenterology",
    specialtyName: "Gastroenterology",
    rating: 4.7,
    reviews: 234,
    experience: "10 years",
    consultationFee: 449,
    availability: "Today 6:00 PM",
    image: "👨‍⚕️",
  },
]

export default function VideoConsultationPage() {
  const { selectedArea } = useLocation()
  const [selectedSpecialty, setSelectedSpecialty] = useState("general")

  const filteredDoctors = videoDoctors.filter(
    doc => doc.specialty === selectedSpecialty
  )

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur">
        <div className="container px-4 flex h-16 items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold">Video Consultation</h1>
            <p className="text-sm text-muted-foreground">
              {selectedArea ? `${selectedArea.name}` : "Select your location"}
            </p>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8">
        {/* Hero Section */}
        <div className="mb-12 p-8 bg-gradient-to-r from-primary/10 to-primary/5 rounded-xl border border-primary/20">
          <div className="flex items-center gap-4 mb-4">
            <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center">
              <Video className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">Consult with Doctors Online</h2>
              <p className="text-muted-foreground break-words">Safe, convenient, and affordable video consultations</p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t">
            <div>
              <Clock className="h-5 w-5 text-primary mb-2" />
              <p className="font-semibold">Quick Response</p>
              <p className="text-sm text-muted-foreground">Most within 2 minutes</p>
            </div>
            <div>
              <DollarSign className="h-5 w-5 text-primary mb-2" />
              <p className="font-semibold">Affordable</p>
              <p className="text-sm text-muted-foreground break-words">₹299 - ₹499</p>
            </div>
            <div>
              <Video className="h-5 w-5 text-primary mb-2" />
              <p className="font-semibold">Secure & Private</p>
              <p className="text-sm text-muted-foreground">Encrypted calls</p>
            </div>
          </div>
        </div>

        {/* Specialization Filter */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4">Select Specialization</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {specializations.map((spec) => (
              <button
                key={spec.id}
                onClick={() => setSelectedSpecialty(spec.id)}
                className={`p-3 rounded-lg border-2 transition-colors font-medium break-words text-center ${
                  selectedSpecialty === spec.id
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border hover:border-primary/50"
                }`}
              >
                <p className="text-sm">{spec.name}</p>
                <p className="text-xs text-muted-foreground mt-1">{spec.count} doctors</p>
              </button>
            ))}
          </div>
        </div>

        {/* Doctors List */}
        <div>
          <h3 className="text-lg font-semibold mb-4">
            Available Doctors in {specializations.find(s => s.id === selectedSpecialty)?.name}
          </h3>
          <div className="space-y-4">
            {filteredDoctors.length > 0 ? (
              filteredDoctors.map((doctor) => (
                <Card key={doctor.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex flex-col md:flex-row md:items-start gap-4">
                      <div className="text-4xl flex-shrink-0">{doctor.image}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-bold text-lg break-words">{doctor.name}</h3>
                            <p className="text-sm text-muted-foreground">{doctor.specialtyName}</p>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-4 my-3 text-sm">
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                            <span className="font-semibold">{doctor.rating}</span>
                            <span className="text-muted-foreground">({doctor.reviews} reviews)</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>{doctor.experience}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <DollarSign className="h-4 w-4 text-muted-foreground" />
                            <span className="font-semibold">₹{doctor.consultationFee}</span>
                          </div>
                        </div>
                        <p className="text-sm text-primary font-semibold mb-4">Next: {doctor.availability}</p>
                        <Link href={`/doctors/${doctor.id}/book`}>
                          <Button className="w-full md:w-auto">Book Now</Button>
                        </Link>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground">No doctors available in this specialization</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
