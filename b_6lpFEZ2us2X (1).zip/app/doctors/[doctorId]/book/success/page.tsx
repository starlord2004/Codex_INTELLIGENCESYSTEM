"use client"

import { Suspense, use } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { 
  CheckCircle2,
  Calendar,
  Clock,
  MapPin,
  Download,
  Share2,
  Home,
  MessageCircle
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

// Mock doctor data - comprehensive list
const doctorsData: Record<string, {
  id: string
  name: string
  specialty: string
  clinic: string
  clinicAddress: string
}> = {
  // Bangalore - Indiranagar
  "dr-priya-patel": { id: "dr-priya-patel", name: "Dr. Priya Patel", specialty: "General Physician", clinic: "Wellness Care Center", clinicAddress: "78, Indiranagar Main Road, Bangalore - 560038" },
  "dr-priya-sharma": { id: "dr-priya-sharma", name: "Dr. Priya Sharma", specialty: "Cardiologist", clinic: "Apollo Heart Centre", clinicAddress: "45, Indiranagar, Bangalore - 560038" },
  "dr-mahesh-verma": { id: "dr-mahesh-verma", name: "Dr. Mahesh Verma", specialty: "Orthopedic", clinic: "Bone & Joint Care", clinicAddress: "67, Indiranagar, Bangalore - 560038" },
  "dr-vikram-reddy": { id: "dr-vikram-reddy", name: "Dr. Vikram Reddy", specialty: "Diabetologist", clinic: "Endocrine Clinic", clinicAddress: "45, Indiranagar, Bangalore - 560038" },
  "dr-priya-menon": { id: "dr-priya-menon", name: "Dr. Priya Menon", specialty: "General Physician", clinic: "Indiranagar Medical Center", clinicAddress: "89, Indiranagar, Bangalore - 560038" },
  "dr-pooja-desai": { id: "dr-pooja-desai", name: "Dr. Pooja Desai", specialty: "Gynecologist", clinic: "Women's Wellness Clinic", clinicAddress: "56, Indiranagar, Bangalore - 560038" },
  "dr-rajesh-nair": { id: "dr-rajesh-nair", name: "Dr. Rajesh Nair", specialty: "ENT Specialist", clinic: "ENT Care Clinic", clinicAddress: "34, Indiranagar, Bangalore - 560038" },
  // Bangalore - Koramangala
  "dr-sharma": { id: "dr-sharma", name: "Dr. Amit Sharma", specialty: "General Physician", clinic: "Sharma Health Clinic", clinicAddress: "45, Koramangala 4th Block, Bangalore - 560034" },
  "dr-sunita-reddy": { id: "dr-sunita-reddy", name: "Dr. Sunita Reddy", specialty: "Cardiologist", clinic: "City Heart Hospital", clinicAddress: "78, Koramangala, Bangalore - 560034" },
  "dr-ravi-sharma": { id: "dr-ravi-sharma", name: "Dr. Ravi Sharma", specialty: "Orthopedic", clinic: "Bone Care Center", clinicAddress: "23, Koramangala, Bangalore - 560034" },
  "dr-anjali-kapoor": { id: "dr-anjali-kapoor", name: "Dr. Anjali Kapoor", specialty: "Dermatologist", clinic: "Skin Care Specialists", clinicAddress: "45, Koramangala, Bangalore - 560034" },
  // Bangalore - HSR Layout
  "dr-rashmi-gupta": { id: "dr-rashmi-gupta", name: "Dr. Rashmi Gupta", specialty: "General Physician", clinic: "HSR Medical Center", clinicAddress: "67, HSR Layout, Bangalore - 560102" },
  "dr-kavya-sharma": { id: "dr-kavya-sharma", name: "Dr. Kavya Sharma", specialty: "Pediatrician", clinic: "Kids Health Clinic", clinicAddress: "89, HSR Layout, Bangalore - 560102" },
  // Bangalore - Whitefield
  "dr-anitha-kumar": { id: "dr-anitha-kumar", name: "Dr. Anitha Kumar", specialty: "ENT Specialist", clinic: "ENT Treatment Center", clinicAddress: "12, Whitefield, Bangalore - 560066" },
  "dr-suresh-nair": { id: "dr-suresh-nair", name: "Dr. Suresh Nair", specialty: "Pulmonologist", clinic: "Chest & Lung Clinic", clinicAddress: "23, Whitefield, Bangalore - 560066" },
  "dr-rekha-menon": { id: "dr-rekha-menon", name: "Dr. Rekha Menon", specialty: "Rheumatologist", clinic: "Joint & Rheumatic Care", clinicAddress: "45, Whitefield, Bangalore - 560066" },
  "dr-vikram-singh": { id: "dr-vikram-singh", name: "Dr. Vikram Singh", specialty: "Dermatologist", clinic: "SkinGlow Clinic", clinicAddress: "32, HSR Layout, Bangalore - 560102" },
  "dr-susan-desai": { id: "dr-susan-desai", name: "Dr. Susan Desai", specialty: "Urologist", clinic: "Advanced Urology Clinic", clinicAddress: "78, Whitefield, Bangalore - 560066" },
  "dr-meera-kapoor": { id: "dr-meera-kapoor", name: "Dr. Meera Kapoor", specialty: "Nephrologist", clinic: "Kidney Care Center", clinicAddress: "67, Whitefield, Bangalore - 560066" },
  // Bangalore - Jayanagar
  "dr-harsh-patel": { id: "dr-harsh-patel", name: "Dr. Harsh Patel", specialty: "General Physician", clinic: "Jayanagar Clinic", clinicAddress: "45, Jayanagar, Bangalore - 560041" },
  "dr-meera-nair": { id: "dr-meera-nair", name: "Dr. Meera Nair", specialty: "Neurologist", clinic: "NeuroLife Clinic", clinicAddress: "56, Jayanagar 4th Block, Bangalore - 560041" },
  "dr-kavitha-nair": { id: "dr-kavitha-nair", name: "Dr. Kavitha Nair", specialty: "Gynecologist", clinic: "Women's Wellness Center", clinicAddress: "78, Jayanagar, Bangalore - 560041" },
  "dr-deepak-patel": { id: "dr-deepak-patel", name: "Dr. Deepak Patel", specialty: "Cardiologist", clinic: "Cardiac Care Center", clinicAddress: "34, Jayanagar, Bangalore - 560041" },
  "dr-rohan-sinha": { id: "dr-rohan-sinha", name: "Dr. Rohan Sinha", specialty: "Rheumatologist", clinic: "Joint & Rheumatic Care", clinicAddress: "45, Whitefield, Bangalore - 560066" },
  "dr-sumit-singh": { id: "dr-sumit-singh", name: "Dr. Sumit Singh", specialty: "Urologist", clinic: "Advanced Urology Clinic", clinicAddress: "78, Whitefield, Bangalore - 560066" },
  "dr-arun-sharma": { id: "dr-arun-sharma", name: "Dr. Arun Sharma", specialty: "Nephrologist", clinic: "Kidney Care Center", clinicAddress: "67, Whitefield, Bangalore - 560066" },
  "dr-neha-gupta": { id: "dr-neha-gupta", name: "Dr. Neha Gupta", specialty: "Neurologist", clinic: "NeuroLife Clinic", clinicAddress: "56, Jayanagar 4th Block, Bangalore - 560041" },
  "dr-sandeep-gupta": { id: "dr-sandeep-gupta", name: "Dr. Sandeep Gupta", specialty: "Orthopedic", clinic: "Bone & Joint Care", clinicAddress: "67, Jayanagar, Bangalore - 560041" },
  "dr-anand-iyer": { id: "dr-anand-iyer", name: "Dr. Anand Iyer", specialty: "General Physician", clinic: "Jayanagar Health Center", clinicAddress: "23, Jayanagar, Bangalore - 560041" },
  // Mumbai - Andheri
  "dr-mumbai-sharma": { id: "dr-mumbai-sharma", name: "Dr. Raj Sharma", specialty: "General Physician", clinic: "Apollo Health Center", clinicAddress: "12, Andheri West, Mumbai - 400058" },
  "dr-mumbai-patel": { id: "dr-mumbai-patel", name: "Dr. Vikram Patel", specialty: "Cardiologist", clinic: "Cardiac Care Mumbai", clinicAddress: "34, Andheri East, Mumbai - 400069" },
  "dr-mumbai-sharma2": { id: "dr-mumbai-sharma2", name: "Dr. Priya Sharma", specialty: "Dentist", clinic: "Smile Dental Studio", clinicAddress: "89, Andheri West, Mumbai - 400058" },
  // Mumbai - Bandra
  "dr-mumbai-desai": { id: "dr-mumbai-desai", name: "Dr. Vikram Desai", specialty: "Cardiologist", clinic: "Cardiac Care Clinic", clinicAddress: "45, Bandra East, Mumbai - 400051" },
  "dr-mumbai-desai2": { id: "dr-mumbai-desai2", name: "Dr. Rohit Verma", specialty: "Neurologist", clinic: "Brain Health Center", clinicAddress: "78, Bandra East, Mumbai - 400051" },
  // Delhi - Saket
  "dr-delhi-gupta": { id: "dr-delhi-gupta", name: "Dr. Vikram Gupta", specialty: "Cardiologist", clinic: "Apollo Heart Center", clinicAddress: "123, Saket, New Delhi - 110017" },
  "dr-delhi-gupta2": { id: "dr-delhi-gupta2", name: "Dr. Neha Kapoor", specialty: "Gynecologist", clinic: "Women's Health Clinic", clinicAddress: "78, Saket, New Delhi - 110017" },
  // Delhi - Connaught Place
  "dr-delhi-sharma": { id: "dr-delhi-sharma", name: "Dr. Amit Sharma", specialty: "General Physician", clinic: "Central Delhi Medical Center", clinicAddress: "123, Connaught Place, New Delhi - 110001" },
  "dr-delhi-patel": { id: "dr-delhi-patel", name: "Dr. Rajesh Patel", specialty: "Cardiologist", clinic: "Premier Heart Care", clinicAddress: "45, Connaught Place, New Delhi - 110001" },
  // Hyderabad - HITEC City
  "dr-hyd-reddy": { id: "dr-hyd-reddy", name: "Dr. Suresh Reddy", specialty: "Cardiologist", clinic: "Heart Care Hospital", clinicAddress: "56, HITEC City, Hyderabad - 500081" },
  "dr-hyd-reddy2": { id: "dr-hyd-reddy2", name: "Dr. Sanjay Kumar", specialty: "Orthopedic", clinic: "Joint Care Clinic", clinicAddress: "89, HITEC City, Hyderabad - 500081" },
  // Hyderabad - Jubilee Hills
  "dr-hyd-rao": { id: "dr-hyd-rao", name: "Dr. Vikram Rao", specialty: "Dermatologist", clinic: "Skin Care Specialists", clinicAddress: "67, Jubilee Hills, Hyderabad - 500033" },
  "dr-hyd-sharma": { id: "dr-hyd-sharma", name: "Dr. Priya Srinivas", specialty: "General Physician", clinic: "Jubilee Health Center", clinicAddress: "34, Jubilee Hills, Hyderabad - 500033" },
  "dr-hyd-rao2": { id: "dr-hyd-rao2", name: "Dr. Vikram Rao", specialty: "Dermatologist", clinic: "Skin Care Specialists", clinicAddress: "67, Jubilee Hills, Hyderabad - 500033" },
  // Chennai - T. Nagar
  "dr-chennai-kumar": { id: "dr-chennai-kumar", name: "Dr. Suresh Kumar", specialty: "General Physician", clinic: "Chennai Health Center", clinicAddress: "78, T. Nagar, Chennai - 600017" },
  "dr-chennai-iyer": { id: "dr-chennai-iyer", name: "Dr. Vikram Iyer", specialty: "Cardiologist", clinic: "Heart Care Hospital", clinicAddress: "45, T. Nagar, Chennai - 600017" },
  // Chennai - Anna Nagar
  "dr-chennai-murugan": { id: "dr-chennai-murugan", name: "Dr. Murugan Pillai", specialty: "General Physician", clinic: "Anna Nagar Clinic", clinicAddress: "123, Anna Nagar, Chennai - 600040" },
  "dr-chennai-priya": { id: "dr-chennai-priya", name: "Dr. Priya Krishnan", specialty: "Orthopedic", clinic: "Orthopedic Care Center", clinicAddress: "56, Anna Nagar, Chennai - 600040" },
  // For backward compatibility
  "dr-rajesh-kumar": { id: "dr-rajesh-kumar", name: "Dr. Rajesh Kumar", specialty: "Cardiologist", clinic: "HeartCare Clinic", clinicAddress: "123, MG Road, Bangalore - 560001" },
  "dr-anil-mehta": { id: "dr-anil-mehta", name: "Dr. Anil Mehta", specialty: "Cardiologist", clinic: "Fortis Hospital", clinicAddress: "154, Bannerghatta Road, Bangalore - 560076" },
  "dr-vikram-nair": { id: "dr-vikram-nair", name: "Dr. Vikram Nair", specialty: "ENT Specialist", clinic: "Ear, Nose & Throat Center", clinicAddress: "45, MG Road, Bangalore - 560001" },
  "dr-swati-joshi": { id: "dr-swati-joshi", name: "Dr. Swati Joshi", specialty: "Dietitian", clinic: "Nutrition & Wellness", clinicAddress: "78, HSR Layout, Bangalore - 560102" },
  "dr-ajay-mishra": { id: "dr-ajay-mishra", name: "Dr. Ajay Mishra", specialty: "General Physician", clinic: "Jayanagar Wellness", clinicAddress: "56, Jayanagar, Bangalore - 560041" },
  "dr-arjun-verma": { id: "dr-arjun-verma", name: "Dr. Arjun Verma", specialty: "Physiotherapist", clinic: "Physio Care Center", clinicAddress: "34, Whitefield, Bangalore - 560066" },
  "dr-sanjay-mishra": { id: "dr-sanjay-mishra", name: "Dr. Sanjay Mishra", specialty: "Psychiatrist", clinic: "Mental Health Center", clinicAddress: "45, Koramangala, Bangalore - 560034" },
}

function SuccessContent({ doctorId }: { doctorId: string }) {
  const searchParams = useSearchParams()
  const dateStr = searchParams.get("date")
  const slot = searchParams.get("slot")
  
  const doctor = doctorsData[doctorId]
  const bookingDate = dateStr ? new Date(dateStr) : new Date()
  
  const formatDate = (date: Date) => {
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    return `${days[date.getDay()]}, ${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`
  }

  const bookingId = `CV${Date.now().toString().slice(-8)}`

  if (!doctor) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Redirecting...</p>
          <Link href="/">
            <Button>Go to Home</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-border bg-card">
        <div className="container flex h-16 items-center justify-center px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8 max-w-lg mx-auto">
        {/* Success Icon */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-emerald-100 mb-4">
            <CheckCircle2 className="h-12 w-12 text-emerald-500" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">Booking Confirmed!</h1>
          <p className="text-muted-foreground">Your appointment has been successfully booked</p>
        </div>

        {/* Booking Details Card */}
        <Card className="mb-6">
          <CardContent className="p-6 space-y-4">
            <div className="flex justify-between items-center pb-4 border-b border-border">
              <span className="text-sm text-muted-foreground">Booking ID</span>
              <span className="font-mono font-medium text-foreground">{bookingId}</span>
            </div>

            {/* Doctor Info */}
            <div className="flex gap-4 pb-4 border-b border-border">
              <div className="flex-shrink-0">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                  <span className="text-lg font-bold text-primary">
                    {doctor.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                  </span>
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{doctor.name}</h3>
                <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
              </div>
            </div>

            {/* Date & Time */}
            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5 text-primary" />
              <div>
                <p className="font-medium text-foreground">{formatDate(bookingDate)}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Clock className="h-5 w-5 text-primary" />
              <div>
                <p className="font-medium text-foreground">{slot || "10:00 AM"}</p>
              </div>
            </div>

            {/* Clinic Address */}
            <div className="flex items-start gap-3 pt-4 border-t border-border">
              <MapPin className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <p className="font-medium text-foreground">{doctor.clinic}</p>
                <p className="text-sm text-muted-foreground">{doctor.clinicAddress}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* WhatsApp Notification */}
        <div className="flex items-center gap-3 p-4 mb-6 bg-emerald-50 rounded-xl border border-emerald-200">
          <MessageCircle className="h-5 w-5 text-emerald-600" />
          <p className="text-sm text-emerald-800">
            Booking confirmation sent to your WhatsApp
          </p>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Download
          </Button>
          <Button variant="outline" className="gap-2">
            <Share2 className="h-4 w-4" />
            Share
          </Button>
        </div>

        {/* Go Home Button */}
        <Link href="/" className="block">
          <Button className="w-full gap-2" size="lg">
            <Home className="h-5 w-5" />
            Back to Home
          </Button>
        </Link>
      </main>
    </div>
  )
}

export default function BookingSuccessPage({ params }: { params: Promise<{ doctorId: string }> }) {
  const resolvedParams = use(params)
  
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    }>
      <SuccessContent doctorId={resolvedParams.doctorId} />
    </Suspense>
  )
}
