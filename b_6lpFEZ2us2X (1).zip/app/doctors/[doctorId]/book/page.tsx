"use client"

import { useState, use } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { 
  ArrowLeft,
  Star,
  ThumbsUp,
  MapPin,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Sun,
  Sunset,
  Moon,
  Verified,
  Check,
  Shield,
  Clock,
  RefreshCcw,
  MessageCircle,
  Mail
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { AlertDialog, AlertDialogAction, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { useUser } from "@/contexts/user-context"
import { useToast } from "@/hooks/use-toast"

// Comprehensive doctor data - All doctors from the platform
const doctorsData: Record<string, {
  id: string
  name: string
  specialty: string
  experience: number
  rating: number
  totalRatings: number
  recommendation: number
  consultationFee: number
  serviceFee: number
  tax: number
  clinic: string
  clinicAddress: string
  image: string
  verified: boolean
  languages: string[]
}> = {
  // Bangalore - Indiranagar
  "dr-priya-patel": { id: "dr-priya-patel", name: "Dr. Priya Patel", specialty: "General Physician", experience: 12, rating: 4.8, totalRatings: 1890, recommendation: 97, consultationFee: 450, serviceFee: 50, tax: 25, clinic: "Wellness Care Center", clinicAddress: "78, Indiranagar Main Road, Bangalore - 560038", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-priya-sharma": { id: "dr-priya-sharma", name: "Dr. Priya Sharma", specialty: "Cardiologist", experience: 12, rating: 4.9, totalRatings: 980, recommendation: 99, consultationFee: 600, serviceFee: 60, tax: 33, clinic: "Apollo Heart Centre", clinicAddress: "45, Indiranagar, Bangalore - 560038", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Kannada"] },
  "dr-mahesh-verma": { id: "dr-mahesh-verma", name: "Dr. Mahesh Verma", specialty: "Orthopedic", experience: 16, rating: 4.9, totalRatings: 1680, recommendation: 98, consultationFee: 600, serviceFee: 60, tax: 33, clinic: "Bone & Joint Care", clinicAddress: "67, Indiranagar, Bangalore - 560038", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-vikram-reddy": { id: "dr-vikram-reddy", name: "Dr. Vikram Reddy", specialty: "Diabetologist", experience: 11, rating: 4.7, totalRatings: 890, recommendation: 96, consultationFee: 500, serviceFee: 50, tax: 27, clinic: "Endocrine Clinic", clinicAddress: "45, Indiranagar, Bangalore - 560038", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-priya-menon": { id: "dr-priya-menon", name: "Dr. Priya Menon", specialty: "General Physician", experience: 8, rating: 4.6, totalRatings: 650, recommendation: 94, consultationFee: 400, serviceFee: 40, tax: 22, clinic: "Indiranagar Medical Center", clinicAddress: "89, Indiranagar, Bangalore - 560038", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Tamil"] },
  "dr-pooja-desai": { id: "dr-pooja-desai", name: "Dr. Pooja Desai", specialty: "Gynecologist", experience: 13, rating: 4.8, totalRatings: 1200, recommendation: 97, consultationFee: 600, serviceFee: 60, tax: 33, clinic: "Women's Wellness Clinic", clinicAddress: "56, Indiranagar, Bangalore - 560038", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-rajesh-nair": { id: "dr-rajesh-nair", name: "Dr. Rajesh Nair", specialty: "ENT Specialist", experience: 15, rating: 4.8, totalRatings: 1050, recommendation: 97, consultationFee: 550, serviceFee: 55, tax: 30, clinic: "ENT Care Clinic", clinicAddress: "34, Indiranagar, Bangalore - 560038", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Malayalam"] },
  
  // Bangalore - Koramangala
  "dr-sharma": { id: "dr-sharma", name: "Dr. Amit Sharma", specialty: "General Physician", experience: 18, rating: 4.9, totalRatings: 2450, recommendation: 98, consultationFee: 500, serviceFee: 50, tax: 27, clinic: "Sharma Health Clinic", clinicAddress: "45, Koramangala 4th Block, Bangalore - 560034", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Kannada"] },
  "dr-sunita-reddy": { id: "dr-sunita-reddy", name: "Dr. Sunita Reddy", specialty: "Cardiologist", experience: 14, rating: 4.9, totalRatings: 1600, recommendation: 98, consultationFee: 600, serviceFee: 60, tax: 33, clinic: "City Heart Hospital", clinicAddress: "78, Koramangala, Bangalore - 560034", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Kannada"] },
  "dr-ravi-sharma": { id: "dr-ravi-sharma", name: "Dr. Ravi Sharma", specialty: "Orthopedic", experience: 10, rating: 4.7, totalRatings: 920, recommendation: 96, consultationFee: 550, serviceFee: 55, tax: 30, clinic: "Bone Care Center", clinicAddress: "23, Koramangala, Bangalore - 560034", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-anjali-kapoor": { id: "dr-anjali-kapoor", name: "Dr. Anjali Kapoor", specialty: "Dermatologist", experience: 11, rating: 4.7, totalRatings: 1100, recommendation: 96, consultationFee: 550, serviceFee: 55, tax: 30, clinic: "Skin Care Specialists", clinicAddress: "45, Koramangala, Bangalore - 560034", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  
  // Bangalore - HSR Layout
  "dr-rashmi-gupta": { id: "dr-rashmi-gupta", name: "Dr. Rashmi Gupta", specialty: "General Physician", experience: 9, rating: 4.7, totalRatings: 780, recommendation: 95, consultationFee: 450, serviceFee: 45, tax: 25, clinic: "HSR Medical Center", clinicAddress: "67, HSR Layout, Bangalore - 560102", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-kavya-sharma": { id: "dr-kavya-sharma", name: "Dr. Kavya Sharma", specialty: "Pediatrician", experience: 12, rating: 4.8, totalRatings: 950, recommendation: 97, consultationFee: 500, serviceFee: 50, tax: 27, clinic: "Kids Health Clinic", clinicAddress: "89, HSR Layout, Bangalore - 560102", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Kannada"] },
  
  // Bangalore - Whitefield
  "dr-anitha-kumar": { id: "dr-anitha-kumar", name: "Dr. Anitha Kumar", specialty: "ENT Specialist", experience: 11, rating: 4.7, totalRatings: 850, recommendation: 96, consultationFee: 500, serviceFee: 50, tax: 27, clinic: "ENT Treatment Center", clinicAddress: "12, Whitefield, Bangalore - 560066", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Tamil", "Kannada"] },
  "dr-suresh-nair": { id: "dr-suresh-nair", name: "Dr. Suresh Nair", specialty: "Pulmonologist", experience: 15, rating: 4.8, totalRatings: 1100, recommendation: 97, consultationFee: 550, serviceFee: 55, tax: 30, clinic: "Chest & Lung Clinic", clinicAddress: "23, Whitefield, Bangalore - 560066", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Malayalam"] },
  "dr-rekha-menon": { id: "dr-rekha-menon", name: "Dr. Rekha Menon", specialty: "Rheumatologist", experience: 12, rating: 4.8, totalRatings: 1100, recommendation: 97, consultationFee: 600, serviceFee: 60, tax: 33, clinic: "Joint & Rheumatic Care", clinicAddress: "45, Whitefield, Bangalore - 560066", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Malayalam"] },
  "dr-vikram-singh": { id: "dr-vikram-singh", name: "Dr. Vikram Singh", specialty: "Dermatologist", experience: 11, rating: 4.7, totalRatings: 890, recommendation: 96, consultationFee: 500, serviceFee: 50, tax: 27, clinic: "SkinGlow Clinic", clinicAddress: "32, HSR Layout, Bangalore - 560102", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Kannada"] },
  "dr-susan-desai": { id: "dr-susan-desai", name: "Dr. Susan Desai", specialty: "Urologist", experience: 9, rating: 4.6, totalRatings: 750, recommendation: 94, consultationFee: 650, serviceFee: 65, tax: 36, clinic: "Advanced Urology Clinic", clinicAddress: "78, Whitefield, Bangalore - 560066", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-meera-kapoor": { id: "dr-meera-kapoor", name: "Dr. Meera Kapoor", specialty: "Nephrologist", experience: 14, rating: 4.8, totalRatings: 840, recommendation: 97, consultationFee: 700, serviceFee: 70, tax: 39, clinic: "Kidney Care Center", clinicAddress: "67, Whitefield, Bangalore - 560066", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  
  // Bangalore - Jayanagar
  "dr-harsh-patel": { id: "dr-harsh-patel", name: "Dr. Harsh Patel", specialty: "General Physician", experience: 7, rating: 4.5, totalRatings: 500, recommendation: 92, consultationFee: 400, serviceFee: 40, tax: 22, clinic: "Jayanagar Clinic", clinicAddress: "45, Jayanagar, Bangalore - 560041", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-meera-nair": { id: "dr-meera-nair", name: "Dr. Meera Nair", specialty: "Neurologist", experience: 14, rating: 4.8, totalRatings: 980, recommendation: 97, consultationFee: 700, serviceFee: 70, tax: 39, clinic: "NeuroLife Clinic", clinicAddress: "56, Jayanagar 4th Block, Bangalore - 560041", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Malayalam"] },
  "dr-kavitha-nair": { id: "dr-kavitha-nair", name: "Dr. Kavitha Nair", specialty: "Gynecologist", experience: 16, rating: 4.9, totalRatings: 1400, recommendation: 98, consultationFee: 700, serviceFee: 70, tax: 39, clinic: "Women's Wellness Center", clinicAddress: "78, Jayanagar, Bangalore - 560041", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Malayalam"] },
  "dr-deepak-patel": { id: "dr-deepak-patel", name: "Dr. Deepak Patel", specialty: "Cardiologist", experience: 13, rating: 4.8, totalRatings: 1150, recommendation: 97, consultationFee: 650, serviceFee: 65, tax: 36, clinic: "Cardiac Care Center", clinicAddress: "34, Jayanagar, Bangalore - 560041", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-rohan-sinha": { id: "dr-rohan-sinha", name: "Dr. Rohan Sinha", specialty: "Rheumatologist", experience: 12, rating: 4.8, totalRatings: 1100, recommendation: 97, consultationFee: 600, serviceFee: 60, tax: 33, clinic: "Joint & Rheumatic Care", clinicAddress: "45, Whitefield, Bangalore - 560066", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-sumit-singh": { id: "dr-sumit-singh", name: "Dr. Sumit Singh", specialty: "Urologist", experience: 9, rating: 4.6, totalRatings: 750, recommendation: 94, consultationFee: 650, serviceFee: 65, tax: 36, clinic: "Advanced Urology Clinic", clinicAddress: "78, Whitefield, Bangalore - 560066", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Punjabi"] },
  "dr-arun-sharma": { id: "dr-arun-sharma", name: "Dr. Arun Sharma", specialty: "Nephrologist", experience: 14, rating: 4.8, totalRatings: 840, recommendation: 97, consultationFee: 700, serviceFee: 70, tax: 39, clinic: "Kidney Care Center", clinicAddress: "67, Whitefield, Bangalore - 560066", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-neha-gupta": { id: "dr-neha-gupta", name: "Dr. Neha Gupta", specialty: "Neurologist", experience: 14, rating: 4.8, totalRatings: 980, recommendation: 97, consultationFee: 700, serviceFee: 70, tax: 39, clinic: "NeuroLife Clinic", clinicAddress: "56, Jayanagar 4th Block, Bangalore - 560041", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-sandeep-gupta": { id: "dr-sandeep-gupta", name: "Dr. Sandeep Gupta", specialty: "Orthopedic", experience: 15, rating: 4.8, totalRatings: 1200, recommendation: 97, consultationFee: 600, serviceFee: 60, tax: 33, clinic: "Bone & Joint Care", clinicAddress: "67, Jayanagar, Bangalore - 560041", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-anand-iyer": { id: "dr-anand-iyer", name: "Dr. Anand Iyer", specialty: "General Physician", experience: 10, rating: 4.7, totalRatings: 900, recommendation: 96, consultationFee: 500, serviceFee: 50, tax: 27, clinic: "Jayanagar Health Center", clinicAddress: "23, Jayanagar, Bangalore - 560041", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Tamil"] },
  
  // Mumbai - Andheri
  "dr-mumbai-sharma": { id: "dr-mumbai-sharma", name: "Dr. Raj Sharma", specialty: "General Physician", experience: 14, rating: 4.8, totalRatings: 1200, recommendation: 97, consultationFee: 500, serviceFee: 50, tax: 27, clinic: "Apollo Health Center", clinicAddress: "12, Andheri West, Mumbai - 400058", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Marathi"] },
  "dr-mumbai-patel": { id: "dr-mumbai-patel", name: "Dr. Vikram Patel", specialty: "Cardiologist", experience: 16, rating: 4.8, totalRatings: 1100, recommendation: 98, consultationFee: 700, serviceFee: 70, tax: 39, clinic: "Cardiac Care Mumbai", clinicAddress: "34, Andheri East, Mumbai - 400069", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-mumbai-sharma2": { id: "dr-mumbai-sharma2", name: "Dr. Priya Sharma", specialty: "Dentist", experience: 11, rating: 4.8, totalRatings: 1400, recommendation: 96, consultationFee: 500, serviceFee: 50, tax: 27, clinic: "Smile Dental Studio", clinicAddress: "89, Andheri West, Mumbai - 400058", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Marathi"] },
  
  // Mumbai - Bandra
  "dr-mumbai-desai": { id: "dr-mumbai-desai", name: "Dr. Vikram Desai", specialty: "Cardiologist", experience: 16, rating: 4.8, totalRatings: 1100, recommendation: 98, consultationFee: 700, serviceFee: 70, tax: 39, clinic: "Cardiac Care Clinic", clinicAddress: "45, Bandra East, Mumbai - 400051", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Marathi"] },
  "dr-mumbai-desai2": { id: "dr-mumbai-desai2", name: "Dr. Rohit Verma", specialty: "Neurologist", experience: 13, rating: 4.7, totalRatings: 980, recommendation: 95, consultationFee: 650, serviceFee: 65, tax: 36, clinic: "Brain Health Center", clinicAddress: "78, Bandra East, Mumbai - 400051", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Marathi"] },
  
  // Delhi - Saket
  "dr-delhi-gupta": { id: "dr-delhi-gupta", name: "Dr. Vikram Gupta", specialty: "Cardiologist", experience: 17, rating: 4.9, totalRatings: 2100, recommendation: 98, consultationFee: 700, serviceFee: 70, tax: 39, clinic: "Apollo Heart Center", clinicAddress: "123, Saket, New Delhi - 110017", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-delhi-gupta2": { id: "dr-delhi-gupta2", name: "Dr. Neha Kapoor", specialty: "Gynecologist", experience: 15, rating: 4.9, totalRatings: 1600, recommendation: 97, consultationFee: 600, serviceFee: 60, tax: 33, clinic: "Women's Health Clinic", clinicAddress: "78, Saket, New Delhi - 110017", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  
  // Delhi - Connaught Place
  "dr-delhi-sharma": { id: "dr-delhi-sharma", name: "Dr. Amit Sharma", specialty: "General Physician", experience: 17, rating: 4.8, totalRatings: 2200, recommendation: 97, consultationFee: 650, serviceFee: 65, tax: 36, clinic: "Central Delhi Medical Center", clinicAddress: "123, Connaught Place, New Delhi - 110001", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Punjabi"] },
  "dr-delhi-patel": { id: "dr-delhi-patel", name: "Dr. Rajesh Patel", specialty: "Cardiologist", experience: 19, rating: 4.9, totalRatings: 2100, recommendation: 98, consultationFee: 800, serviceFee: 80, tax: 44, clinic: "Premier Heart Care", clinicAddress: "45, Connaught Place, New Delhi - 110001", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  
  // Hyderabad - HITEC City
  "dr-hyd-reddy": { id: "dr-hyd-reddy", name: "Dr. Suresh Reddy", specialty: "Cardiologist", experience: 16, rating: 4.8, totalRatings: 1400, recommendation: 97, consultationFee: 600, serviceFee: 60, tax: 33, clinic: "Heart Care Hospital", clinicAddress: "56, HITEC City, Hyderabad - 500081", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Telugu", "Hindi"] },
  "dr-hyd-reddy2": { id: "dr-hyd-reddy2", name: "Dr. Sanjay Kumar", specialty: "Orthopedic", experience: 15, rating: 4.7, totalRatings: 1300, recommendation: 95, consultationFee: 550, serviceFee: 55, tax: 30, clinic: "Joint Care Clinic", clinicAddress: "89, HITEC City, Hyderabad - 500081", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Telugu", "Hindi"] },
  
  // Hyderabad - Jubilee Hills
  "dr-hyd-rao": { id: "dr-hyd-rao", name: "Dr. Vikram Rao", specialty: "Dermatologist", experience: 12, rating: 4.7, totalRatings: 1100, recommendation: 95, consultationFee: 550, serviceFee: 55, tax: 30, clinic: "Skin Care Specialists", clinicAddress: "67, Jubilee Hills, Hyderabad - 500033", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Telugu", "Hindi", "Urdu"] },
  "dr-hyd-sharma": { id: "dr-hyd-sharma", name: "Dr. Priya Srinivas", specialty: "General Physician", experience: 13, rating: 4.8, totalRatings: 1400, recommendation: 96, consultationFee: 500, serviceFee: 50, tax: 27, clinic: "Jubilee Health Center", clinicAddress: "34, Jubilee Hills, Hyderabad - 500033", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Telugu", "Hindi"] },
  "dr-hyd-rao2": { id: "dr-hyd-rao2", name: "Dr. Vikram Rao", specialty: "Dermatologist", experience: 12, rating: 4.7, totalRatings: 1100, recommendation: 95, consultationFee: 550, serviceFee: 55, tax: 30, clinic: "Skin Care Specialists", clinicAddress: "67, Jubilee Hills, Hyderabad - 500033", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Telugu", "Hindi", "Urdu"] },
  
  // Chennai - T. Nagar
  "dr-chennai-kumar": { id: "dr-chennai-kumar", name: "Dr. Suresh Kumar", specialty: "General Physician", experience: 18, rating: 4.8, totalRatings: 2000, recommendation: 97, consultationFee: 500, serviceFee: 50, tax: 27, clinic: "Chennai Health Center", clinicAddress: "78, T. Nagar, Chennai - 600017", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Tamil", "Hindi"] },
  "dr-chennai-iyer": { id: "dr-chennai-iyer", name: "Dr. Vikram Iyer", specialty: "Cardiologist", experience: 16, rating: 4.9, totalRatings: 1500, recommendation: 98, consultationFee: 750, serviceFee: 75, tax: 41, clinic: "Heart Care Hospital", clinicAddress: "45, T. Nagar, Chennai - 600017", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Tamil", "Hindi"] },
  
  // Chennai - Anna Nagar
  "dr-chennai-murugan": { id: "dr-chennai-murugan", name: "Dr. Murugan Pillai", specialty: "General Physician", experience: 12, rating: 4.7, totalRatings: 1200, recommendation: 95, consultationFee: 450, serviceFee: 45, tax: 25, clinic: "Anna Nagar Clinic", clinicAddress: "123, Anna Nagar, Chennai - 600040", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Tamil", "Telugu"] },
  "dr-chennai-priya": { id: "dr-chennai-priya", name: "Dr. Priya Krishnan", specialty: "Orthopedic", experience: 14, rating: 4.8, totalRatings: 1100, recommendation: 96, consultationFee: 600, serviceFee: 60, tax: 33, clinic: "Orthopedic Care Center", clinicAddress: "56, Anna Nagar, Chennai - 600040", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Tamil", "Hindi"] },
  
  // For backward compatibility - older doctor IDs
  "dr-rajesh-kumar": { id: "dr-rajesh-kumar", name: "Dr. Rajesh Kumar", specialty: "Cardiologist", experience: 15, rating: 4.8, totalRatings: 1250, recommendation: 98, consultationFee: 500, serviceFee: 50, tax: 27, clinic: "HeartCare Clinic", clinicAddress: "123, MG Road, Bangalore - 560001", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Kannada"] },
  "dr-anil-mehta": { id: "dr-anil-mehta", name: "Dr. Anil Mehta", specialty: "Cardiologist", experience: 16, rating: 4.8, totalRatings: 1150, recommendation: 98, consultationFee: 650, serviceFee: 65, tax: 36, clinic: "Fortis Hospital", clinicAddress: "154, Bannerghatta Road, Bangalore - 560076", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-vikram-nair": { id: "dr-vikram-nair", name: "Dr. Vikram Nair", specialty: "ENT Specialist", experience: 14, rating: 4.8, totalRatings: 1000, recommendation: 97, consultationFee: 550, serviceFee: 55, tax: 30, clinic: "Ear, Nose & Throat Center", clinicAddress: "45, MG Road, Bangalore - 560001", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Malayalam"] },
  "dr-swati-joshi": { id: "dr-swati-joshi", name: "Dr. Swati Joshi", specialty: "Dietitian", experience: 10, rating: 4.7, totalRatings: 800, recommendation: 96, consultationFee: 400, serviceFee: 40, tax: 22, clinic: "Nutrition & Wellness", clinicAddress: "78, HSR Layout, Bangalore - 560102", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Marathi"] },
  "dr-ajay-mishra": { id: "dr-ajay-mishra", name: "Dr. Ajay Mishra", specialty: "General Physician", experience: 11, rating: 4.6, totalRatings: 900, recommendation: 94, consultationFee: 450, serviceFee: 45, tax: 25, clinic: "Jayanagar Wellness", clinicAddress: "56, Jayanagar, Bangalore - 560041", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Marathi"] },
  "dr-arjun-verma": { id: "dr-arjun-verma", name: "Dr. Arjun Verma", specialty: "Physiotherapist", experience: 9, rating: 4.6, totalRatings: 700, recommendation: 93, consultationFee: 400, serviceFee: 40, tax: 22, clinic: "Physio Care Center", clinicAddress: "34, Whitefield, Bangalore - 560066", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi"] },
  "dr-sanjay-mishra": { id: "dr-sanjay-mishra", name: "Dr. Sanjay Mishra", specialty: "Psychiatrist", experience: 13, rating: 4.8, totalRatings: 1000, recommendation: 96, consultationFee: 700, serviceFee: 70, tax: 39, clinic: "Mental Health Center", clinicAddress: "45, Koramangala, Bangalore - 560034", image: "/placeholder.svg?height=120&width=120", verified: true, languages: ["English", "Hindi", "Marathi"] },
}

// Generate available dates (next 7 days)
function generateDates() {
  const dates = []
  const today = new Date()
  for (let i = 0; i < 7; i++) {
    const date = new Date(today)
    date.setDate(today.getDate() + i)
    dates.push(date)
  }
  return dates
}

// Generate time slots
const morningSlots = ["9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM"]
const eveningSlots = ["2:00 PM", "2:30 PM", "3:00 PM", "3:30 PM", "4:00 PM", "4:30 PM", "5:00 PM"]
const nightSlots = ["6:00 PM", "6:30 PM", "7:00 PM", "7:30 PM", "8:00 PM"]

type BookingStep = "slots" | "confirm"

export default function BookDoctorPage({ params }: { params: Promise<{ doctorId: string }> }) {
  const resolvedParams = use(params)
  const router = useRouter()
  const { user } = useUser()
  const doctor = doctorsData[resolvedParams.doctorId]
  
  const [step, setStep] = useState<BookingStep>("slots")
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null)
  const [whatsappNotify, setWhatsappNotify] = useState(true)
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const [isConfirming, setIsConfirming] = useState(false)
  
  const dates = generateDates()

  if (!doctor) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Doctor not found</p>
          <Button onClick={() => router.push("/doctors")}>View all doctors</Button>
        </div>
      </div>
    )
  }

  const totalAmount = doctor.consultationFee + doctor.serviceFee + doctor.tax

  const formatDate = (date: Date) => {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return {
      day: days[date.getDay()],
      date: date.getDate(),
      month: months[date.getMonth()],
      isToday: date.toDateString() === new Date().toDateString()
    }
  }

  const handleSlotSelect = (slot: string) => {
    setSelectedSlot(slot)
    setStep("confirm")
  }

  const handleConfirmBooking = () => {
    setShowConfirmDialog(true)
  }

  const handleConfirmDialogAction = () => {
    setIsConfirming(true)
    const { addAppointment } = useUser()
    const { toast } = useToast()
    
    if (user) {
      addAppointment({
        doctorName: doctor.name,
        doctorSpecialty: doctor.specialty,
        clinicName: doctor.clinic,
        clinicAddress: doctor.clinicAddress,
        appointmentDate: selectedDate.toISOString(),
        appointmentTime: selectedSlot,
        reason: "Consultation",
        status: "upcoming"
      })
    }
    
    // Show confirmation notification
    toast({
      title: "Appointment Confirmed! ✓",
      description: `Your appointment with ${doctor.name} has been confirmed for ${selectedDate.toDateString()} at ${selectedSlot}.`,
      duration: 5000,
    })
    
    // Show email notification
    toast({
      title: "Confirmation Email Sent",
      description: `A confirmation email has been sent to your registered email address with all appointment details.`,
      duration: 5000,
    })
    
    setShowConfirmDialog(false)
    setIsConfirming(false)
    
    // Navigate to success page
    router.push(`/doctors/${resolvedParams.doctorId}/book/success?date=${selectedDate.toISOString()}&slot=${selectedSlot}`)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center gap-4 px-4">
          <button 
            onClick={() => step === "confirm" ? setStep("slots") : router.back()}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back</span>
          </button>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <main className="container px-4 py-6 max-w-3xl mx-auto">
        {step === "slots" && (
          <>
            {/* Doctor Card */}
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 rounded-xl bg-secondary flex items-center justify-center overflow-hidden">
                      <div className="w-full h-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                        <span className="text-xl font-bold text-primary">
                          {doctor.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h2 className="font-semibold text-foreground">{doctor.name}</h2>
                      {doctor.verified && <Verified className="h-4 w-4 text-primary" />}
                    </div>
                    <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <div className="flex items-center gap-1">
                        <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                        <span className="text-sm">{doctor.rating}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <ThumbsUp className="h-3.5 w-3.5 text-emerald-500" />
                        <span className="text-sm text-emerald-600">{doctor.recommendation}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Date Selection */}
            <div className="mb-6">
              <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                Select Date
              </h3>
              <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4">
                {dates.map((date) => {
                  const formatted = formatDate(date)
                  const isSelected = date.toDateString() === selectedDate.toDateString()
                  return (
                    <button
                      key={date.toISOString()}
                      onClick={() => setSelectedDate(date)}
                      className={`flex flex-col items-center min-w-[60px] p-3 rounded-xl border-2 transition-all ${
                        isSelected 
                          ? "border-primary bg-primary/10" 
                          : "border-border bg-card hover:border-primary/50"
                      }`}
                    >
                      <span className="text-xs text-muted-foreground">{formatted.day}</span>
                      <span className={`text-lg font-bold ${isSelected ? "text-primary" : "text-foreground"}`}>
                        {formatted.date}
                      </span>
                      <span className="text-xs text-muted-foreground">{formatted.month}</span>
                      {formatted.isToday && (
                        <Badge variant="secondary" className="mt-1 text-[10px] px-1.5 py-0">Today</Badge>
                      )}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Time Slots */}
            <div className="space-y-6">
              {/* Morning Slots */}
              <div>
                <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                  <Sun className="h-4 w-4 text-amber-500" />
                  Morning Slots
                </h4>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {morningSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => handleSlotSelect(slot)}
                      className="px-3 py-2 text-sm border border-border rounded-lg bg-card hover:border-primary hover:bg-primary/5 transition-colors"
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Evening Slots */}
              <div>
                <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                  <Sunset className="h-4 w-4 text-orange-500" />
                  Evening Slots
                </h4>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {eveningSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => handleSlotSelect(slot)}
                      className="px-3 py-2 text-sm border border-border rounded-lg bg-card hover:border-primary hover:bg-primary/5 transition-colors"
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Night Slots */}
              <div>
                <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                  <Moon className="h-4 w-4 text-indigo-500" />
                  Night Slots
                </h4>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {nightSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => handleSlotSelect(slot)}
                      className="px-3 py-2 text-sm border border-border rounded-lg bg-card hover:border-primary hover:bg-primary/5 transition-colors"
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}

        {step === "confirm" && (
          <>
            {/* Booking Summary */}
            <Card className="mb-6">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Booking Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Doctor Profile */}
                <div className="flex gap-4 pb-4 border-b border-border">
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 rounded-xl bg-secondary flex items-center justify-center overflow-hidden">
                      <div className="w-full h-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                        <span className="text-xl font-bold text-primary">
                          {doctor.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-foreground">{doctor.name}</h3>
                      {doctor.verified && <Verified className="h-4 w-4 text-primary" />}
                    </div>
                    <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
                    <p className="text-sm text-muted-foreground">{doctor.experience} years experience</p>
                  </div>
                </div>

                {/* Date & Time */}
                <div className="flex items-center gap-3 py-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium text-foreground">
                      {formatDate(selectedDate).day}, {formatDate(selectedDate).date} {formatDate(selectedDate).month}
                    </p>
                    <p className="text-sm text-muted-foreground">{selectedSlot}</p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="ml-auto text-primary"
                    onClick={() => setStep("slots")}
                  >
                    Change
                  </Button>
                </div>

                {/* Clinic Address */}
                <div className="flex items-start gap-3 py-2 border-t border-border">
                  <MapPin className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <p className="font-medium text-foreground">{doctor.clinic}</p>
                    <p className="text-sm text-muted-foreground">{doctor.clinicAddress}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Bill Details */}
            <Card className="mb-6">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Bill Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Consultation Fee</span>
                  <span className="font-medium">Rs. {doctor.consultationFee}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Service Fee</span>
                  <span className="font-medium">Rs. {doctor.serviceFee}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tax</span>
                  <span className="font-medium">Rs. {doctor.tax}</span>
                </div>
                <div className="flex justify-between pt-3 border-t border-border">
                  <span className="font-semibold text-foreground">Total Amount</span>
                  <span className="font-bold text-lg text-primary">Rs. {totalAmount}</span>
                </div>
              </CardContent>
            </Card>

            {/* CareVia Promises */}
            <Card className="mb-6 bg-primary/5 border-primary/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  CareVia Promises
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Confirmed Instantly</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>100% Refund if cancelled 2 hours before appointment</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Free follow-up consultation within 7 days</span>
                </div>
              </CardContent>
            </Card>

            {/* WhatsApp Notification */}
            <div className="flex items-center gap-3 p-4 mb-6 bg-card rounded-xl border border-border">
              <Checkbox 
                id="whatsapp" 
                checked={whatsappNotify}
                onCheckedChange={(checked) => setWhatsappNotify(!!checked)}
              />
              <Label htmlFor="whatsapp" className="flex items-center gap-2 cursor-pointer">
                <MessageCircle className="h-5 w-5 text-emerald-500" />
                <span className="text-sm">Get notifications on WhatsApp</span>
              </Label>
              <span className="text-xs text-muted-foreground ml-auto">Sent to registered number</span>
            </div>

            {/* Confirm Button */}
            <Button 
              onClick={handleConfirmBooking}
              className="w-full h-14 text-lg font-semibold"
              size="lg"
            >
              <Check className="h-5 w-5 mr-2" />
              Confirm Clinic Visit - Rs. {totalAmount}
            </Button>
            
            {/* Email Confirmation Info */}
            <div className="flex items-center gap-2 mt-4 p-3 bg-primary/10 rounded-lg border border-primary/20">
              <Mail className="h-5 w-5 text-primary flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                A confirmation email with appointment details will be sent to your registered email address
              </p>
            </div>
          </>
        )}
      </main>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-2xl">Confirm Your Appointment</AlertDialogTitle>
            <AlertDialogDescription className="pt-4 space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <span className="text-lg font-bold text-primary">
                      {doctor.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                    </span>
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{doctor.name}</p>
                    <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
                  </div>
                </div>
                <div className="bg-secondary/50 p-3 rounded-lg space-y-2">
                  <p className="text-sm"><span className="font-semibold">Date:</span> {selectedDate.toDateString()}</p>
                  <p className="text-sm"><span className="font-semibold">Time:</span> {selectedSlot}</p>
                  <p className="text-sm"><span className="font-semibold">Clinic:</span> {doctor.clinic}</p>
                </div>
                <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg">
                  <p className="text-sm text-blue-900">
                    <span className="font-semibold">Total Amount:</span> ₹{totalAmount}
                  </p>
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex gap-3 justify-end">
            <button 
              onClick={() => setShowConfirmDialog(false)}
              className="px-4 py-2 rounded-lg border border-border hover:bg-secondary transition-colors text-foreground font-medium"
            >
              Cancel
            </button>
            <AlertDialogAction 
              onClick={handleConfirmDialogAction}
              disabled={isConfirming}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              {isConfirming ? "Confirmed ✓" : "Confirm Appointment"}
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
