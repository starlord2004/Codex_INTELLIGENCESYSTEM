"use client"

import { useState, useEffect, Suspense } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { 
  ArrowLeft,
  Star,
  ThumbsUp,
  MapPin,
  Clock,
  Building2,
  Verified,
  ChevronRight,
  AlertCircle
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useLocation } from "@/contexts/location-context"

// Mock doctor data with location info
const doctorsData = [
  // Bangalore - Indiranagar
  {
    id: "dr-priya-patel",
    name: "Dr. Priya Patel",
    specialty: "General Physician",
    specialtySlug: "general-physician",
    conditions: ["fever", "cold", "cough", "allergy"],
    experience: 12,
    rating: 4.8,
    totalRatings: 1890,
    recommendation: 97,
    consultationFee: 450,
    clinic: "Wellness Care Center",
    clinicAddress: "78, Indiranagar Main Road, Bangalore - 560038",
    cityId: "bangalore",
    areaId: "indiranagar",
    availableToday: true,
    nextSlot: "2:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },
  {
    id: "dr-priya-sharma",
    name: "Dr. Priya Sharma",
    specialty: "Cardiologist",
    specialtySlug: "cardiologist",
    conditions: [],
    experience: 12,
    rating: 4.9,
    totalRatings: 980,
    recommendation: 99,
    consultationFee: 600,
    clinic: "Apollo Heart Centre",
    clinicAddress: "45, Indiranagar, Bangalore - 560038",
    cityId: "bangalore",
    areaId: "indiranagar",
    availableToday: true,
    nextSlot: "11:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },
  {
    id: "dr-mahesh-verma",
    name: "Dr. Mahesh Verma",
    specialty: "Orthopedic",
    specialtySlug: "orthopedic",
    conditions: ["joint-pain"],
    experience: 16,
    rating: 4.9,
    totalRatings: 1680,
    recommendation: 98,
    consultationFee: 600,
    clinic: "Bone & Joint Care",
    clinicAddress: "67, Indiranagar, Bangalore - 560038",
    cityId: "bangalore",
    areaId: "indiranagar",
    availableToday: true,
    nextSlot: "9:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },
  {
    id: "dr-vikram-reddy",
    name: "Dr. Vikram Reddy",
    specialty: "Diabetologist",
    specialtySlug: "diabetologist",
    conditions: [],
    experience: 11,
    rating: 4.7,
    totalRatings: 890,
    recommendation: 96,
    consultationFee: 500,
    clinic: "Endocrine Clinic",
    clinicAddress: "45, Indiranagar, Bangalore - 560038",
    cityId: "bangalore",
    areaId: "indiranagar",
    availableToday: true,
    nextSlot: "2:30 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Telugu", "Hindi"],
  },
  {
    id: "dr-priya-menon",
    name: "Dr. Priya Menon",
    specialty: "Psychiatrist",
    specialtySlug: "psychiatrist",
    conditions: [],
    experience: 10,
    rating: 4.8,
    totalRatings: 850,
    recommendation: 96,
    consultationFee: 800,
    clinic: "Mental Health Clinic",
    clinicAddress: "56, Indiranagar, Bangalore - 560038",
    cityId: "bangalore",
    areaId: "indiranagar",
    availableToday: true,
    nextSlot: "1:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Malayalam"],
  },
  {
    id: "dr-pooja-desai",
    name: "Dr. Pooja Desai",
    specialty: "ENT Specialist",
    specialtySlug: "ent-specialist",
    conditions: [],
    experience: 10,
    rating: 4.8,
    totalRatings: 920,
    recommendation: 96,
    consultationFee: 500,
    clinic: "ENT Solutions Clinic",
    clinicAddress: "56, Indiranagar, Bangalore - 560038",
    cityId: "bangalore",
    areaId: "indiranagar",
    availableToday: true,
    nextSlot: "11:30 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
  },
  {
    id: "dr-rajesh-nair",
    name: "Dr. Rajesh Nair",
    specialty: "Oncologist",
    specialtySlug: "oncologist",
    conditions: [],
    experience: 18,
    rating: 4.9,
    totalRatings: 680,
    recommendation: 98,
    consultationFee: 1000,
    clinic: "Cancer Care Institute",
    clinicAddress: "123, Indiranagar, Bangalore - 560038",
    cityId: "bangalore",
    areaId: "indiranagar",
    availableToday: true,
    nextSlot: "10:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },

  // Bangalore - Koramangala
  {
    id: "dr-sharma",
    name: "Dr. Amit Sharma",
    specialty: "General Physician",
    specialtySlug: "general-physician",
    conditions: ["fever", "cold", "cough"],
    experience: 18,
    rating: 4.9,
    totalRatings: 2450,
    recommendation: 98,
    consultationFee: 500,
    clinic: "Sharma Health Clinic",
    clinicAddress: "45, Koramangala 4th Block, Bangalore - 560034",
    cityId: "bangalore",
    areaId: "koramangala",
    availableToday: true,
    nextSlot: "9:30 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada", "Telugu"],
  },
  {
    id: "dr-sunita-reddy",
    name: "Dr. Sunita Reddy",
    specialty: "Cardiologist",
    specialtySlug: "cardiologist",
    conditions: [],
    experience: 8,
    rating: 4.6,
    totalRatings: 650,
    recommendation: 94,
    consultationFee: 400,
    clinic: "City Heart Hospital",
    clinicAddress: "78, Koramangala, Bangalore - 560034",
    cityId: "bangalore",
    areaId: "koramangala",
    availableToday: true,
    nextSlot: "2:30 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Telugu", "Kannada"],
  },
  {
    id: "dr-ravi-sharma",
    name: "Dr. Ravi Sharma",
    specialty: "Neurologist",
    specialtySlug: "neurologist",
    conditions: ["headache", "migraine"],
    experience: 16,
    rating: 4.8,
    totalRatings: 1100,
    recommendation: 96,
    consultationFee: 650,
    clinic: "Brain & Mind Centre",
    clinicAddress: "123, Koramangala, Bangalore - 560034",
    cityId: "bangalore",
    areaId: "koramangala",
    availableToday: true,
    nextSlot: "4:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
  },
  {
    id: "dr-anjali-kapoor",
    name: "Dr. Anjali Kapoor",
    specialty: "Orthopedic",
    specialtySlug: "orthopedic",
    conditions: ["joint-pain"],
    experience: 9,
    rating: 4.7,
    totalRatings: 650,
    recommendation: 94,
    consultationFee: 500,
    clinic: "Sports Medicine Clinic",
    clinicAddress: "45, Koramangala, Bangalore - 560034",
    cityId: "bangalore",
    areaId: "koramangala",
    availableToday: true,
    nextSlot: "3:30 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Punjabi"],
  },
  {
    id: "dr-rashmi-gupta",
    name: "Dr. Rashmi Gupta",
    specialty: "Gastroenterologist",
    specialtySlug: "gastroenterologist",
    conditions: [],
    experience: 9,
    rating: 4.6,
    totalRatings: 720,
    recommendation: 94,
    consultationFee: 600,
    clinic: "Digestive Health Center",
    clinicAddress: "34, Koramangala, Bangalore - 560034",
    cityId: "bangalore",
    areaId: "koramangala",
    availableToday: true,
    nextSlot: "3:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },
  {
    id: "dr-kavya-sharma",
    name: "Dr. Kavya Sharma",
    specialty: "Dentist",
    specialtySlug: "dentist",
    conditions: [],
    experience: 8,
    rating: 4.8,
    totalRatings: 1620,
    recommendation: 96,
    consultationFee: 400,
    clinic: "Smile Dental Clinic",
    clinicAddress: "23, Koramangala, Bangalore - 560034",
    cityId: "bangalore",
    areaId: "koramangala",
    availableToday: true,
    nextSlot: "9:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
  },

  // Bangalore - Domlur (nearby Indiranagar)
  {
    id: "dr-anitha-kumar",
    name: "Dr. Anitha Kumar",
    specialty: "General Physician",
    specialtySlug: "general-physician",
    conditions: ["fever", "cold", "cough"],
    experience: 14,
    rating: 4.7,
    totalRatings: 1250,
    recommendation: 95,
    consultationFee: 400,
    clinic: "Domlur Health Center",
    clinicAddress: "12, Domlur Layout, Bangalore - 560071",
    cityId: "bangalore",
    areaId: "domlur",
    availableToday: true,
    nextSlot: "10:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Kannada", "Tamil"],
  },
  {
    id: "dr-suresh-nair",
    name: "Dr. Suresh Nair",
    specialty: "Cardiologist",
    specialtySlug: "cardiologist",
    conditions: [],
    experience: 20,
    rating: 4.9,
    totalRatings: 2100,
    recommendation: 98,
    consultationFee: 700,
    clinic: "Heart & Vascular Clinic",
    clinicAddress: "45, Domlur, Bangalore - 560071",
    cityId: "bangalore",
    areaId: "domlur",
    availableToday: true,
    nextSlot: "11:30 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Malayalam"],
  },

  // Bangalore - Ulsoor (nearby Indiranagar)
  {
    id: "dr-rekha-menon",
    name: "Dr. Rekha Menon",
    specialty: "Dermatologist",
    specialtySlug: "dermatologist",
    conditions: ["acne", "eczema"],
    experience: 11,
    rating: 4.8,
    totalRatings: 980,
    recommendation: 97,
    consultationFee: 500,
    clinic: "Skin Care Clinic",
    clinicAddress: "67, Ulsoor Road, Bangalore - 560008",
    cityId: "bangalore",
    areaId: "ulsoor",
    availableToday: true,
    nextSlot: "2:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Malayalam"],
  },

  // Bangalore - HSR Layout
  {
    id: "dr-vikram-singh",
    name: "Dr. Vikram Singh",
    specialty: "Dermatologist",
    specialtySlug: "dermatologist",
    conditions: ["acne", "eczema", "psoriasis"],
    experience: 10,
    rating: 4.8,
    totalRatings: 890,
    recommendation: 97,
    consultationFee: 450,
    clinic: "SkinGlow Clinic",
    clinicAddress: "32, HSR Layout, Bangalore - 560102",
    cityId: "bangalore",
    areaId: "hsr-layout",
    availableToday: true,
    nextSlot: "12:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Punjabi"],
  },
  {
    id: "dr-susan-desai",
    name: "Dr. Susan Desai",
    specialty: "Eye Specialist",
    specialtySlug: "eye-specialist",
    conditions: [],
    experience: 11,
    rating: 4.9,
    totalRatings: 1350,
    recommendation: 98,
    consultationFee: 500,
    clinic: "Clear Vision Clinic",
    clinicAddress: "78, HSR Layout, Bangalore - 560102",
    cityId: "bangalore",
    areaId: "hsr-layout",
    availableToday: true,
    nextSlot: "10:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },
  {
    id: "dr-meera-kapoor",
    name: "Dr. Meera Kapoor",
    specialty: "Rheumatologist",
    specialtySlug: "rheumatologist",
    conditions: [],
    experience: 14,
    rating: 4.7,
    totalRatings: 980,
    recommendation: 95,
    consultationFee: 650,
    clinic: "Rheumatic Diseases Clinic",
    clinicAddress: "78, HSR Layout, Bangalore - 560102",
    cityId: "bangalore",
    areaId: "hsr-layout",
    availableToday: true,
    nextSlot: "10:30 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },
  {
    id: "dr-harsh-patel",
    name: "Dr. Harsh Patel",
    specialty: "Dentist",
    specialtySlug: "dentist",
    conditions: [],
    experience: 11,
    rating: 4.7,
    totalRatings: 1450,
    recommendation: 95,
    consultationFee: 450,
    clinic: "Advanced Dental Care",
    clinicAddress: "67, HSR Layout, Bangalore - 560102",
    cityId: "bangalore",
    areaId: "hsr-layout",
    availableToday: true,
    nextSlot: "12:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Tamil"],
  },

  // Bangalore - Whitefield
  {
    id: "dr-meera-nair",
    name: "Dr. Meera Nair",
    specialty: "Dermatologist",
    specialtySlug: "dermatologist",
    conditions: ["acne", "eczema", "allergy"],
    experience: 8,
    rating: 4.7,
    totalRatings: 720,
    recommendation: 96,
    consultationFee: 400,
    clinic: "Skin Expert Clinic",
    clinicAddress: "56, Whitefield, Bangalore - 560066",
    cityId: "bangalore",
    areaId: "whitefield",
    availableToday: true,
    nextSlot: "3:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Tamil", "Hindi"],
  },
  {
    id: "dr-kavitha-nair",
    name: "Dr. Kavitha Nair",
    specialty: "Pediatrician",
    specialtySlug: "pediatrician",
    conditions: ["fever", "cold", "cough"],
    experience: 12,
    rating: 4.8,
    totalRatings: 1560,
    recommendation: 96,
    consultationFee: 450,
    clinic: "Kids Care Clinic",
    clinicAddress: "88, Whitefield Main Road, Bangalore - 560066",
    cityId: "bangalore",
    areaId: "whitefield",
    availableToday: true,
    nextSlot: "11:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Malayalam"],
  },
  {
    id: "dr-deepak-patel",
    name: "Dr. Deepak Patel",
    specialty: "Pulmonologist",
    specialtySlug: "pulmonologist",
    conditions: ["cough"],
    experience: 15,
    rating: 4.8,
    totalRatings: 1100,
    recommendation: 97,
    consultationFee: 550,
    clinic: "Chest & Lung Clinic",
    clinicAddress: "23, Whitefield, Bangalore - 560066",
    cityId: "bangalore",
    areaId: "whitefield",
    availableToday: true,
    nextSlot: "10:15 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Gujarati"],
  },
  {
    id: "dr-rohan-sinha",
    name: "Dr. Rohan Sinha",
    specialty: "Rheumatologist",
    specialtySlug: "rheumatologist",
    conditions: [],
    experience: 12,
    rating: 4.8,
    totalRatings: 1100,
    recommendation: 97,
    consultationFee: 600,
    clinic: "Joint & Rheumatic Care",
    clinicAddress: "45, Whitefield, Bangalore - 560066",
    cityId: "bangalore",
    areaId: "whitefield",
    availableToday: false,
    nextSlot: "Tomorrow 9:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Punjabi"],
  },
  {
    id: "dr-sumit-singh",
    name: "Dr. Sumit Singh",
    specialty: "Urologist",
    specialtySlug: "urologist",
    conditions: [],
    experience: 9,
    rating: 4.6,
    totalRatings: 750,
    recommendation: 94,
    consultationFee: 650,
    clinic: "Advanced Urology Clinic",
    clinicAddress: "78, Whitefield, Bangalore - 560066",
    cityId: "bangalore",
    areaId: "whitefield",
    availableToday: false,
    nextSlot: "Tomorrow 10:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Punjabi"],
  },
  {
    id: "dr-arun-sharma",
    name: "Dr. Arun Sharma",
    specialty: "Nephrologist",
    specialtySlug: "nephrologist",
    conditions: [],
    experience: 14,
    rating: 4.8,
    totalRatings: 840,
    recommendation: 97,
    consultationFee: 700,
    clinic: "Kidney Care Center",
    clinicAddress: "67, Whitefield, Bangalore - 560066",
    cityId: "bangalore",
    areaId: "whitefield",
    availableToday: true,
    nextSlot: "3:30 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },

  // Bangalore - Jayanagar
  {
    id: "dr-neha-gupta",
    name: "Dr. Neha Gupta",
    specialty: "Neurologist",
    specialtySlug: "neurologist",
    conditions: ["headache", "migraine"],
    experience: 14,
    rating: 4.8,
    totalRatings: 980,
    recommendation: 97,
    consultationFee: 700,
    clinic: "NeuroLife Clinic",
    clinicAddress: "56, Jayanagar 4th Block, Bangalore - 560041",
    cityId: "bangalore",
    areaId: "jayanagar",
    availableToday: true,
    nextSlot: "2:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },
  {
    id: "dr-sandeep-gupta",
    name: "Dr. Sandeep Gupta",
    specialty: "Pediatrician",
    specialtySlug: "pediatrician",
    conditions: ["fever", "cough", "allergy"],
    experience: 10,
    rating: 4.7,
    totalRatings: 945,
    recommendation: 95,
    consultationFee: 400,
    clinic: "Little Stars Pediatric",
    clinicAddress: "45, Jayanagar, Bangalore - 560041",
    cityId: "bangalore",
    areaId: "jayanagar",
    availableToday: true,
    nextSlot: "1:30 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
  },
  {
    id: "dr-anand-iyer",
    name: "Dr. Anand Iyer",
    specialty: "Gastroenterologist",
    specialtySlug: "gastroenterologist",
    conditions: [],
    experience: 17,
    rating: 4.8,
    totalRatings: 1320,
    recommendation: 97,
    consultationFee: 700,
    clinic: "GI Care Clinic",
    clinicAddress: "67, Jayanagar, Bangalore - 560041",
    cityId: "bangalore",
    areaId: "jayanagar",
    availableToday: true,
    nextSlot: "11:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Tamil"],
  },
  {
    id: "dr-vikram-nair",
    name: "Dr. Vikram Nair",
    specialty: "Urologist",
    specialtySlug: "urologist",
    conditions: [],
    experience: 16,
    rating: 4.8,
    totalRatings: 1100,
    recommendation: 97,
    consultationFee: 750,
    clinic: "Urology Care Center",
    clinicAddress: "45, Jayanagar, Bangalore - 560041",
    cityId: "bangalore",
    areaId: "jayanagar",
    availableToday: true,
    nextSlot: "2:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Malayalam"],
  },

  // Bangalore - MG Road area
  {
    id: "dr-rajesh-kumar",
    name: "Dr. Rajesh Kumar",
    specialty: "Cardiologist",
    specialtySlug: "cardiologist",
    conditions: [],
    experience: 15,
    rating: 4.8,
    totalRatings: 1250,
    recommendation: 98,
    consultationFee: 500,
    clinic: "HeartCare Clinic",
    clinicAddress: "123, MG Road, Bangalore - 560001",
    cityId: "bangalore",
    areaId: "ulsoor", // Near MG Road
    availableToday: true,
    nextSlot: "10:30 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
  },
  {
    id: "dr-rohit-kapoor",
    name: "Dr. Rohit Kapoor",
    specialty: "Dermatologist",
    specialtySlug: "dermatologist",
    conditions: ["acne", "psoriasis"],
    experience: 14,
    rating: 4.9,
    totalRatings: 1240,
    recommendation: 98,
    consultationFee: 550,
    clinic: "Derma Plus Clinic",
    clinicAddress: "89, MG Road, Bangalore - 560001",
    cityId: "bangalore",
    areaId: "ulsoor",
    availableToday: false,
    nextSlot: "Tomorrow 10:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },
  {
    id: "dr-ajay-mishra",
    name: "Dr. Ajay Mishra",
    specialty: "ENT Specialist",
    specialtySlug: "ent-specialist",
    conditions: [],
    experience: 13,
    rating: 4.7,
    totalRatings: 820,
    recommendation: 95,
    consultationFee: 450,
    clinic: "ENT Care Center",
    clinicAddress: "34, MG Road, Bangalore - 560001",
    cityId: "bangalore",
    areaId: "ulsoor",
    availableToday: true,
    nextSlot: "11:30 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
  },
  {
    id: "dr-swati-joshi",
    name: "Dr. Swati Joshi",
    specialty: "Diabetologist",
    specialtySlug: "diabetologist",
    conditions: [],
    experience: 13,
    rating: 4.9,
    totalRatings: 1450,
    recommendation: 98,
    consultationFee: 600,
    clinic: "Diabetes Care Center",
    clinicAddress: "92, MG Road, Bangalore - 560001",
    cityId: "bangalore",
    areaId: "ulsoor",
    availableToday: true,
    nextSlot: "9:30 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
  },
  {
    id: "dr-arjun-verma",
    name: "Dr. Arjun Verma",
    specialty: "Psychiatrist",
    specialtySlug: "psychiatrist",
    conditions: [],
    experience: 15,
    rating: 4.9,
    totalRatings: 1250,
    recommendation: 98,
    consultationFee: 850,
    clinic: "Behavioral Health Center",
    clinicAddress: "89, MG Road, Bangalore - 560001",
    cityId: "bangalore",
    areaId: "ulsoor",
    availableToday: true,
    nextSlot: "4:30 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },
  {
    id: "dr-sanjay-mishra",
    name: "Dr. Sanjay Mishra",
    specialty: "Vascular Surgeon",
    specialtySlug: "vascular-surgeon",
    conditions: [],
    experience: 17,
    rating: 4.7,
    totalRatings: 620,
    recommendation: 96,
    consultationFee: 900,
    clinic: "Vascular Surgery Center",
    clinicAddress: "89, MG Road, Bangalore - 560001",
    cityId: "bangalore",
    areaId: "ulsoor",
    availableToday: true,
    nextSlot: "2:30 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },

  // Bangalore - Bannerghatta Road area
  {
    id: "dr-anil-mehta",
    name: "Dr. Anil Mehta",
    specialty: "Cardiologist",
    specialtySlug: "cardiologist",
    conditions: [],
    experience: 20,
    rating: 4.7,
    totalRatings: 2100,
    recommendation: 96,
    consultationFee: 800,
    clinic: "Fortis Hospital",
    clinicAddress: "154, Bannerghatta Road, Bangalore - 560076",
    cityId: "bangalore",
    areaId: "jp-nagar",
    availableToday: false,
    nextSlot: "Tomorrow 9:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Tamil"],
  },

  // Mumbai - Andheri
  {
    id: "dr-mumbai-sharma",
    name: "Dr. Ramesh Sharma",
    specialty: "General Physician",
    specialtySlug: "general-physician",
    conditions: ["fever", "cold", "cough"],
    experience: 15,
    rating: 4.8,
    totalRatings: 1800,
    recommendation: 97,
    consultationFee: 600,
    clinic: "City Health Clinic",
    clinicAddress: "45, Andheri West, Mumbai - 400058",
    cityId: "mumbai",
    areaId: "andheri",
    availableToday: true,
    nextSlot: "10:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Marathi"],
  },
  {
    id: "dr-mumbai-patel",
    name: "Dr. Sneha Patel",
    specialty: "Cardiologist",
    specialtySlug: "cardiologist",
    conditions: [],
    experience: 12,
    rating: 4.9,
    totalRatings: 1200,
    recommendation: 98,
    consultationFee: 800,
    clinic: "Heart Care Hospital",
    clinicAddress: "78, Andheri East, Mumbai - 400059",
    cityId: "mumbai",
    areaId: "andheri",
    availableToday: true,
    nextSlot: "11:30 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Gujarati"],
  },

  // Mumbai - Bandra
  {
    id: "dr-mumbai-desai",
    name: "Dr. Kiran Desai",
    specialty: "Dermatologist",
    specialtySlug: "dermatologist",
    conditions: ["acne", "eczema"],
    experience: 10,
    rating: 4.7,
    totalRatings: 950,
    recommendation: 96,
    consultationFee: 700,
    clinic: "Skin Solutions",
    clinicAddress: "23, Bandra West, Mumbai - 400050",
    cityId: "mumbai",
    areaId: "bandra",
    availableToday: true,
    nextSlot: "2:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Marathi"],
  },

  // Delhi - South Delhi
  {
    id: "dr-delhi-gupta",
    name: "Dr. Anil Gupta",
    specialty: "General Physician",
    specialtySlug: "general-physician",
    conditions: ["fever", "cold", "cough"],
    experience: 20,
    rating: 4.9,
    totalRatings: 2500,
    recommendation: 98,
    consultationFee: 700,
    clinic: "Max Healthcare",
    clinicAddress: "45, Saket, New Delhi - 110017",
    cityId: "delhi",
    areaId: "saket",
    availableToday: true,
    nextSlot: "9:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },

  // Hyderabad - HITEC City
  {
    id: "dr-hyd-reddy",
    name: "Dr. Venkat Reddy",
    specialty: "General Physician",
    specialtySlug: "general-physician",
    conditions: ["fever", "cold", "cough"],
    experience: 14,
    rating: 4.8,
    totalRatings: 1600,
    recommendation: 97,
    consultationFee: 500,
    clinic: "Apollo Clinic",
    clinicAddress: "123, HITEC City, Hyderabad - 500081",
    cityId: "hyderabad",
    areaId: "hitech-city",
    availableToday: true,
    nextSlot: "10:30 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Telugu"],
  },
  {
    id: "dr-hyd-rao",
    name: "Dr. Lakshmi Rao",
    specialty: "Cardiologist",
    specialtySlug: "cardiologist",
    conditions: [],
    experience: 16,
    rating: 4.9,
    totalRatings: 1100,
    recommendation: 98,
    consultationFee: 700,
    clinic: "Care Hospital",
    clinicAddress: "45, HITEC City, Hyderabad - 500081",
    cityId: "hyderabad",
    areaId: "hitech-city",
    availableToday: true,
    nextSlot: "11:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Telugu", "Hindi"],
  },

  // Chennai - T. Nagar
  {
    id: "dr-chennai-kumar",
    name: "Dr. Suresh Kumar",
    specialty: "General Physician",
    specialtySlug: "general-physician",
    conditions: ["fever", "cold", "cough"],
    experience: 18,
    rating: 4.8,
    totalRatings: 2000,
    recommendation: 97,
    consultationFee: 500,
    clinic: "Chennai Health Center",
    clinicAddress: "78, T. Nagar, Chennai - 600017",
    cityId: "chennai",
    areaId: "t-nagar",
    availableToday: true,
    nextSlot: "9:30 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Tamil", "Hindi"],
  },
  {
    id: "dr-chennai-iyer",
    name: "Dr. Vikram Iyer",
    specialty: "Cardiologist",
    specialtySlug: "cardiologist",
    conditions: [],
    experience: 16,
    rating: 4.9,
    totalRatings: 1500,
    recommendation: 98,
    consultationFee: 750,
    clinic: "Heart Care Hospital",
    clinicAddress: "45, T. Nagar, Chennai - 600017",
    cityId: "chennai",
    areaId: "t-nagar",
    availableToday: true,
    nextSlot: "2:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Tamil", "Hindi"],
  },

  // Chennai - Anna Nagar
  {
    id: "dr-chennai-murugan",
    name: "Dr. Murugan Pillai",
    specialty: "General Physician",
    specialtySlug: "general-physician",
    conditions: ["fever", "cold", "cough"],
    experience: 12,
    rating: 4.7,
    totalRatings: 1200,
    recommendation: 95,
    consultationFee: 450,
    clinic: "Anna Nagar Clinic",
    clinicAddress: "123, Anna Nagar, Chennai - 600040",
    cityId: "chennai",
    areaId: "anna-nagar",
    availableToday: true,
    nextSlot: "10:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Tamil", "Telugu"],
  },
  {
    id: "dr-chennai-priya",
    name: "Dr. Priya Krishnan",
    specialty: "Orthopedic",
    specialtySlug: "orthopedic",
    conditions: ["joint-pain"],
    experience: 14,
    rating: 4.8,
    totalRatings: 1100,
    recommendation: 96,
    consultationFee: 600,
    clinic: "Orthopedic Care Center",
    clinicAddress: "56, Anna Nagar, Chennai - 600040",
    cityId: "chennai",
    areaId: "anna-nagar",
    availableToday: true,
    nextSlot: "3:30 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Tamil", "Hindi"],
  },

  // Mumbai - Andheri (Second doctor)
  {
    id: "dr-mumbai-sharma2",
    name: "Dr. Priya Sharma",
    specialty: "Dentist",
    specialtySlug: "dentist",
    conditions: [],
    experience: 11,
    rating: 4.8,
    totalRatings: 1400,
    recommendation: 96,
    consultationFee: 500,
    clinic: "Smile Dental Studio",
    clinicAddress: "89, Andheri West, Mumbai - 400058",
    cityId: "mumbai",
    areaId: "andheri",
    availableToday: true,
    nextSlot: "11:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Marathi"],
  },

  // Mumbai - Bandra (Second doctor)
  {
    id: "dr-mumbai-desai2",
    name: "Dr. Rohit Verma",
    specialty: "Neurologist",
    specialtySlug: "neurologist",
    conditions: ["headache", "migraine"],
    experience: 13,
    rating: 4.7,
    totalRatings: 980,
    recommendation: 95,
    consultationFee: 650,
    clinic: "Brain Health Center",
    clinicAddress: "78, Bandra East, Mumbai - 400051",
    cityId: "mumbai",
    areaId: "bandra",
    availableToday: true,
    nextSlot: "4:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Marathi"],
  },

  // Delhi - South Delhi (Second doctor)
  {
    id: "dr-delhi-gupta2",
    name: "Dr. Neha Kapoor",
    specialty: "Gynecologist",
    specialtySlug: "gynecologist",
    conditions: [],
    experience: 15,
    rating: 4.9,
    totalRatings: 1600,
    recommendation: 97,
    consultationFee: 600,
    clinic: "Women's Health Clinic",
    clinicAddress: "78, Saket, New Delhi - 110017",
    cityId: "delhi",
    areaId: "saket",
    availableToday: true,
    nextSlot: "2:30 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },

  // Delhi - Connaught Place
  {
    id: "dr-delhi-sharma",
    name: "Dr. Amit Sharma",
    specialty: "General Physician",
    specialtySlug: "general-physician",
    conditions: ["fever", "cold", "cough"],
    experience: 17,
    rating: 4.8,
    totalRatings: 2200,
    recommendation: 97,
    consultationFee: 650,
    clinic: "Central Delhi Medical Center",
    clinicAddress: "123, Connaught Place, New Delhi - 110001",
    cityId: "delhi",
    areaId: "cp",
    availableToday: true,
    nextSlot: "11:30 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Punjabi"],
  },
  {
    id: "dr-delhi-patel",
    name: "Dr. Rajesh Patel",
    specialty: "Cardiologist",
    specialtySlug: "cardiologist",
    conditions: [],
    experience: 19,
    rating: 4.9,
    totalRatings: 2100,
    recommendation: 98,
    consultationFee: 800,
    clinic: "Premier Heart Care",
    clinicAddress: "45, Connaught Place, New Delhi - 110001",
    cityId: "delhi",
    areaId: "cp",
    availableToday: true,
    nextSlot: "3:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
  },

  // Hyderabad - HITEC City (Second doctor)
  {
    id: "dr-hyd-reddy2",
    name: "Dr. Sanjay Kumar",
    specialty: "Orthopedic",
    specialtySlug: "orthopedic",
    conditions: ["joint-pain"],
    experience: 15,
    rating: 4.7,
    totalRatings: 1300,
    recommendation: 95,
    consultationFee: 550,
    clinic: "Joint Care Clinic",
    clinicAddress: "89, HITEC City, Hyderabad - 500081",
    cityId: "hyderabad",
    areaId: "hitech-city",
    availableToday: true,
    nextSlot: "1:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Telugu", "Hindi"],
  },

  // Hyderabad - Jubilee Hills
  {
    id: "dr-hyd-sharma",
    name: "Dr. Priya Srinivas",
    specialty: "General Physician",
    specialtySlug: "general-physician",
    conditions: ["fever", "cold", "cough"],
    experience: 13,
    rating: 4.8,
    totalRatings: 1400,
    recommendation: 96,
    consultationFee: 500,
    clinic: "Jubilee Health Center",
    clinicAddress: "34, Jubilee Hills, Hyderabad - 500033",
    cityId: "hyderabad",
    areaId: "jubilee-hills",
    availableToday: true,
    nextSlot: "10:00 AM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Telugu", "Hindi"],
  },
  {
    id: "dr-hyd-rao2",
    name: "Dr. Vikram Rao",
    specialty: "Dermatologist",
    specialtySlug: "dermatologist",
    conditions: ["acne", "eczema"],
    experience: 12,
    rating: 4.7,
    totalRatings: 1100,
    recommendation: 95,
    consultationFee: 550,
    clinic: "Skin Care Specialists",
    clinicAddress: "67, Jubilee Hills, Hyderabad - 500033",
    cityId: "hyderabad",
    areaId: "jubilee-hills",
    availableToday: true,
    nextSlot: "2:00 PM",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Telugu", "Hindi", "Urdu"],
  },
]

function DoctorsContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { selectedCity, selectedArea, getNearbyAreas } = useLocation()
  
  const specialty = searchParams.get("specialty")
  const condition = searchParams.get("condition")
  const search = searchParams.get("search")
  
  const [filteredDoctors, setFilteredDoctors] = useState<typeof doctorsData>([])
  const [nearbyDoctors, setNearbyDoctors] = useState<typeof doctorsData>([])
  const [showNearby, setShowNearby] = useState(false)

  useEffect(() => {
    if (!selectedCity || !selectedArea) return

    // Filter by specialty/condition/search first
    let baseFiltered = doctorsData
    if (specialty) {
      baseFiltered = doctorsData.filter(d => d.specialtySlug === specialty)
    }
    if (condition) {
      baseFiltered = doctorsData.filter(d => 
        d.conditions.includes(condition.toLowerCase())
      )
    }
    if (search) {
      baseFiltered = doctorsData.filter(d => 
        d.name.toLowerCase().includes(search.toLowerCase()) ||
        d.specialty.toLowerCase().includes(search.toLowerCase()) ||
        d.clinic.toLowerCase().includes(search.toLowerCase())
      )
    }

    // Filter by selected area
    const inSelectedArea = baseFiltered.filter(d => 
      d.cityId === selectedCity.id && d.areaId === selectedArea.id
    )

    // Get nearby areas
    const nearbyAreaIds = getNearbyAreas().map(a => a.id)
    const inNearbyAreas = baseFiltered.filter(d => 
      d.cityId === selectedCity.id && 
      nearbyAreaIds.includes(d.areaId) &&
      d.areaId !== selectedArea.id
    )

    setFilteredDoctors(inSelectedArea)
    setNearbyDoctors(inNearbyAreas)
    setShowNearby(inSelectedArea.length === 0 && inNearbyAreas.length > 0)
  }, [selectedCity, selectedArea, specialty, condition, search, getNearbyAreas])

  const getPageTitle = () => {
    if (condition) {
      const title = condition.charAt(0).toUpperCase() + condition.slice(1).replace("-", " ")
      return `Doctors for ${title}`
    }
    if (specialty) {
      const title = specialty.charAt(0).toUpperCase() + specialty.slice(1).replace("-", " ")
      return title + "s"
    }
    return "All Doctors"
  }

  const specialtyTitle = getPageTitle()
  const locationDisplay = selectedCity && selectedArea 
    ? `${selectedArea.name}, ${selectedCity.name}` 
    : "your area"

  const DoctorCard = ({ doctor, isNearby = false }: { doctor: typeof doctorsData[0], isNearby?: boolean }) => (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex gap-4">
          {/* Doctor Image */}
          <div className="flex-shrink-0">
            <div className="w-20 h-20 md:w-24 md:h-24 rounded-xl bg-secondary flex items-center justify-center overflow-hidden">
              <div className="w-full h-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                <span className="text-2xl font-bold text-primary">
                  {doctor.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                </span>
              </div>
            </div>
          </div>

          {/* Doctor Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-foreground text-lg">{doctor.name}</h3>
                  {doctor.verified && (
                    <Verified className="h-4 w-4 text-primary flex-shrink-0" />
                  )}
                </div>
                <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
              </div>
              {isNearby && (
                <Badge variant="outline" className="text-xs">Nearby</Badge>
              )}
            </div>

            <p className="text-sm text-muted-foreground mt-1">
              {doctor.experience} years experience
            </p>

            {/* Rating & Recommendation */}
            <div className="flex flex-wrap items-center gap-3 mt-2">
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                <span className="text-sm font-medium">{doctor.rating}</span>
                <span className="text-xs text-muted-foreground">({doctor.totalRatings})</span>
              </div>
              <div className="flex items-center gap-1">
                <ThumbsUp className="h-4 w-4 text-emerald-500" />
                <span className="text-sm font-medium text-emerald-600">{doctor.recommendation}%</span>
                <span className="text-xs text-muted-foreground">recommended</span>
              </div>
            </div>

            {/* Clinic Info */}
            <div className="flex items-start gap-2 mt-3">
              <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-foreground">{doctor.clinic}</p>
                <p className="text-xs text-muted-foreground">{doctor.clinicAddress}</p>
              </div>
            </div>

            {/* Availability & Fee */}
            <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-3 border-t border-border">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  {doctor.availableToday ? (
                    <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
                      Available Today
                    </Badge>
                  ) : (
                    <span className="text-sm text-muted-foreground">{doctor.nextSlot}</span>
                  )}
                </div>
                <div className="text-sm">
                  <span className="font-semibold text-foreground">Rs. {doctor.consultationFee}</span>
                  <span className="text-muted-foreground"> fee</span>
                </div>
              </div>

              <Button 
                onClick={() => router.push(`/doctors/${doctor.id}/book`)}
                className="gap-1"
              >
                Book Clinic Visit
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center gap-4 px-4">
          <Link href="/" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back to Home</span>
          </Link>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <main className="container px-4 py-6">
        {/* Page Title */}
        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
            {specialtyTitle} in {locationDisplay}
          </h1>
          <p className="text-muted-foreground">
            {filteredDoctors.length} doctor{filteredDoctors.length !== 1 ? "s" : ""} available in your area
            {nearbyDoctors.length > 0 && !showNearby && (
              <span> ({nearbyDoctors.length} more in nearby areas)</span>
            )}
          </p>
        </div>

        {/* Book Clinic Consultation CTA */}
        <Card className="mb-6 bg-primary/5 border-primary/20">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-foreground">Book In-Clinic Consultation</h3>
              <p className="text-sm text-muted-foreground">Visit doctor at their clinic</p>
            </div>
            <Building2 className="h-10 w-10 text-primary" />
          </CardContent>
        </Card>

        {/* Doctors in Selected Area */}
        {filteredDoctors.length > 0 && (
          <div className="flex flex-col gap-4 mb-6">
            {filteredDoctors.map((doctor) => (
              <DoctorCard key={doctor.id} doctor={doctor} />
            ))}
          </div>
        )}

        {/* No doctors in area message */}
        {filteredDoctors.length === 0 && nearbyDoctors.length > 0 && (
          <Card className="mb-6 border-amber-200 bg-amber-50">
            <CardContent className="p-4 flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5" />
              <div>
                <p className="font-medium text-amber-800">
                  No doctors found in {locationDisplay}
                </p>
                <p className="text-sm text-amber-700 mt-1">
                  Showing doctors from nearby areas instead.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Nearby Doctors */}
        {nearbyDoctors.length > 0 && (showNearby || filteredDoctors.length === 0) && (
          <div className="mb-6">
            {filteredDoctors.length > 0 && (
              <h2 className="text-lg font-semibold text-foreground mb-4">
                Doctors in Nearby Areas
              </h2>
            )}
            <div className="flex flex-col gap-4">
              {nearbyDoctors.map((doctor) => (
                <DoctorCard key={doctor.id} doctor={doctor} isNearby />
              ))}
            </div>
          </div>
        )}

        {/* Show nearby toggle when there are doctors in both areas */}
        {filteredDoctors.length > 0 && nearbyDoctors.length > 0 && !showNearby && (
          <div className="text-center">
            <Button 
              variant="outline" 
              onClick={() => setShowNearby(true)}
              className="gap-2"
            >
              Show {nearbyDoctors.length} more doctors from nearby areas
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        )}

        {/* No doctors found at all */}
        {filteredDoctors.length === 0 && nearbyDoctors.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No doctors found in {locationDisplay} or nearby areas</p>
            <Button variant="link" onClick={() => router.push("/doctors")} className="mt-2">
              View all doctors
            </Button>
          </div>
        )}
      </main>
    </div>
  )
}

export default function DoctorsPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    }>
      <DoctorsContent />
    </Suspense>
  )
}
