"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronDown, Search, Filter, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"

interface Question {
  id: string
  category: string
  question: string
  answer: string
  views: number
  helpful: number
}

const allQuestions: Question[] = [
  {
    id: "1",
    category: "Headache",
    question: "What causes recurring headaches and when should I see a doctor?",
    answer: "Recurring headaches can be caused by stress, tension, migraines, dehydration, or underlying health conditions. You should consult a doctor if: headaches are severe, occur more than 15 days a month, change in pattern, or are accompanied by other symptoms like vision changes or weakness.",
    views: 2543,
    helpful: 1892,
  },
  {
    id: "2",
    category: "Fever",
    question: "How to manage fever at home safely?",
    answer: "To manage fever safely at home: Stay hydrated by drinking water, herbal teas, and warm broths. Use over-the-counter fever reducers like paracetamol or ibuprofen as directed. Rest adequately, avoid strenuous activities. Take lukewarm baths. If fever persists beyond 3 days or exceeds 103°F, consult a doctor.",
    views: 3124,
    helpful: 2756,
  },
  {
    id: "3",
    category: "Cough",
    question: "What's the difference between dry cough and productive cough?",
    answer: "A dry cough produces no phlegm and often results from viral infections, allergies, or irritation. A productive cough brings up mucus or phlegm, often from bacterial infections, bronchitis, or pneumonia. A productive cough lasting more than a week requires medical attention, while dry coughs usually resolve within 2-3 weeks.",
    views: 2891,
    helpful: 2105,
  },
  {
    id: "4",
    category: "Body Ache",
    question: "How long does body ache usually last and what helps?",
    answer: "Body aches typically last 3-7 days depending on the cause. Relief methods include rest, staying hydrated, over-the-counter pain relievers, warm compresses, and light stretching. If body aches persist beyond a week, are severe, or accompanied by fever and fatigue, consult a healthcare provider.",
    views: 2156,
    helpful: 1743,
  },
  {
    id: "5",
    category: "Sore Throat",
    question: "When is a sore throat serious and what's the best treatment?",
    answer: "Most sore throats are viral and self-limiting. Seek medical attention if you have: difficulty swallowing or breathing, high fever, swollen lymph nodes, or rash. Treatments include throat lozenges, warm salt water gargles, honey, fluids, and rest. Antibiotics are only needed for bacterial infections like strep throat.",
    views: 3456,
    helpful: 2945,
  },
  {
    id: "6",
    category: "Nausea",
    question: "What are common causes of nausea and how to relieve it?",
    answer: "Common causes include food poisoning, viral infections, medication side effects, motion sickness, or anxiety. Relief methods: eat small frequent meals, stay hydrated with ginger tea, avoid strong odors, get fresh air, and try over-the-counter anti-nausea medications. Persistent nausea warrants a doctor's visit.",
    views: 2678,
    helpful: 2234,
  },
  {
    id: "7",
    category: "Fatigue",
    question: "Why do I feel constantly tired and how can I improve energy levels?",
    answer: "Constant fatigue can stem from insufficient sleep, poor diet, stress, anemia, thyroid issues, or infections. Improvements: ensure 7-9 hours of sleep, exercise regularly, maintain balanced nutrition, manage stress, and limit caffeine before bedtime. If fatigue persists for more than 2 weeks, consult a doctor for evaluation.",
    views: 3789,
    helpful: 3156,
  },
  {
    id: "8",
    category: "Diarrhea",
    question: "How long does diarrhea last and when should I seek help?",
    answer: "Most diarrhea lasts 2-3 days and is self-limiting. Stay hydrated with oral rehydration solutions, eat bland foods, and avoid dairy and high-fiber foods. Seek medical help if diarrhea lasts more than 3 days, you have signs of dehydration, blood in stool, or severe abdominal pain.",
    views: 2923,
    helpful: 2478,
  },
]

const categories = [
  "All",
  "Headache",
  "Fever",
  "Cough",
  "Body Ache",
  "Sore Throat",
  "Nausea",
  "Fatigue",
  "Diarrhea",
]

export default function TrendingQuestionsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [sortBy, setSortBy] = useState("mostViewed")

  let filteredQuestions = allQuestions

  if (selectedCategory !== "All") {
    filteredQuestions = filteredQuestions.filter(
      (q) => q.category === selectedCategory
    )
  }

  if (searchTerm) {
    filteredQuestions = filteredQuestions.filter(
      (q) =>
        q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
        q.answer.toLowerCase().includes(searchTerm.toLowerCase())
    )
  }

  if (sortBy === "mostViewed") {
    filteredQuestions.sort((a, b) => b.views - a.views)
  } else if (sortBy === "mostHelpful") {
    filteredQuestions.sort((a, b) => b.helpful - a.helpful)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur">
        <div className="container px-4 flex h-16 items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold">Trending Health Questions</h1>
            <p className="text-sm text-muted-foreground">
              Find answers to common health concerns
            </p>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8">
        {/* Search and Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-lg">Search & Filter</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Search Input */}
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search health questions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Filters and Sort */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Category
                </label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Sort By</label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mostViewed">Most Viewed</SelectItem>
                    <SelectItem value="mostHelpful">Most Helpful</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Questions List */}
        <div className="space-y-4">
          {filteredQuestions.length > 0 ? (
            filteredQuestions.map((question) => (
              <Collapsible key={question.id} className="border rounded-lg">
                <CollapsibleTrigger className="w-full px-6 py-4 flex items-start justify-between hover:bg-secondary/50 transition-colors">
                  <div className="flex-1 text-left">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="inline-block px-3 py-1 bg-primary/10 text-primary text-xs font-semibold rounded-full">
                        {question.category}
                      </span>
                    </div>
                    <h3 className="font-semibold text-foreground text-base">
                      {question.question}
                    </h3>
                  </div>
                  <ChevronDown className="h-5 w-5 text-muted-foreground ml-4 flex-shrink-0" />
                </CollapsibleTrigger>

                <CollapsibleContent className="border-t px-6 py-4 bg-secondary/30">
                  <div className="space-y-4">
                    <p className="text-muted-foreground leading-relaxed">
                      {question.answer}
                    </p>
                    <div className="flex items-center justify-between text-sm text-muted-foreground pt-4 border-t">
                      <div className="flex items-center gap-4">
                        <span>👁 {question.views.toLocaleString()} views</span>
                        <span>👍 {question.helpful.toLocaleString()} found helpful</span>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-xs"
                        onClick={() => {
                          const medicalDisclaimer = "This information is for educational purposes. Always consult a healthcare professional for medical advice."
                          alert(medicalDisclaimer)
                        }}
                      >
                        Report Issue
                      </Button>
                    </div>
                  </div>
                </CollapsibleContent>
              </Collapsible>
            ))
          ) : (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground mb-4">No questions found matching your search.</p>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("")
                  setSelectedCategory("All")
                }}
              >
                Clear Filters
              </Button>
            </Card>
          )}
        </div>

        {/* Medical Disclaimer */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <p className="text-sm text-blue-900">
              <span className="font-semibold">Disclaimer:</span> The information provided on this page is for educational purposes only and should not be considered as medical advice. Always consult with a qualified healthcare professional before making any health-related decisions.
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
