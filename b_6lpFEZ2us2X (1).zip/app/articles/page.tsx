"use client"

import Link from "next/link"
import { ArrowLeft, Heart, Brain, Zap, X, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useState } from "react"

const articles = [
  {
    id: 1,
    title: "Understanding Blood Pressure: Normal, High, and Low",
    category: "Cardiovascular Health",
    icon: Heart,
    description: "Learn about blood pressure readings, what they mean, and how to maintain healthy levels.",
    readTime: "5 min read",
    fullContent: `Blood pressure is the force exerted by blood on the walls of your arteries. It's measured in two numbers: systolic (the pressure when your heart beats) and diastolic (the pressure when your heart rests). 

Normal blood pressure is less than 120/80 mmHg. High blood pressure (hypertension) is 130/80 mmHg or higher. Low blood pressure (hypotension) is less than 90/60 mmHg.

High blood pressure can damage your arteries and lead to serious health conditions like heart disease, stroke, and kidney disease. Low blood pressure can cause dizziness, fainting, and in severe cases, organ damage.

To maintain healthy blood pressure:
- Exercise regularly (at least 150 minutes per week)
- Eat a healthy diet low in salt and saturated fats
- Maintain a healthy weight
- Limit alcohol consumption
- Manage stress through meditation or yoga
- Get enough sleep (7-9 hours per night)

Monitor your blood pressure regularly, especially if you have risk factors like family history of hypertension, obesity, or diabetes.`,
  },
  {
    id: 2,
    title: "Complete Guide to Mental Wellness",
    category: "Mental Health",
    icon: Brain,
    description: "Tips and strategies for maintaining good mental health and managing stress.",
    readTime: "8 min read",
    fullContent: `Mental wellness is just as important as physical health. It involves emotional, psychological, and social well-being. Mental health affects how we think, feel, and act, and helps determine how we handle stress, relate to others, and make choices.

Key components of mental wellness:
- Emotional intelligence: Understanding and managing your emotions
- Positive relationships: Building and maintaining strong social connections
- Self-care practices: Regular exercise, adequate sleep, and nutrition
- Mindfulness: Being present and aware of your thoughts and feelings
- Purpose and meaning: Having goals and a sense of direction

Strategies for maintaining mental wellness:
1. Practice mindfulness and meditation daily
2. Exercise regularly to boost endorphins
3. Maintain a consistent sleep schedule
4. Connect with friends and family regularly
5. Engage in activities you enjoy
6. Seek professional help when needed
7. Limit social media usage
8. Practice gratitude and positive thinking

Remember, taking care of your mental health is not selfish—it's essential for your overall well-being and ability to care for others. Don't hesitate to reach out to mental health professionals if you're struggling.`,
  },
  {
    id: 3,
    title: "Boosting Your Immune System Naturally",
    category: "Wellness",
    icon: Zap,
    description: "Natural ways to strengthen your immune system and prevent common illnesses.",
    readTime: "6 min read",
    fullContent: `Your immune system is your body's defense against infections and diseases. A strong immune system can help prevent colds, flu, and other illnesses. Here are natural ways to boost your immunity:

Foods that boost immunity:
- Citrus fruits: Rich in vitamin C to fight infections
- Garlic: Contains allicin, a powerful antimicrobial compound
- Ginger: Anti-inflammatory and aids digestion
- Turmeric: Contains curcumin, a powerful antioxidant
- Yogurt: Probiotics support gut health
- Almonds: Vitamin E supports immune function
- Sunflower seeds: Selenium and vitamin E
- Green tea: Antioxidants called catechins

Lifestyle habits for a strong immune system:
- Sleep 7-9 hours every night
- Exercise regularly (30 minutes most days)
- Manage stress through meditation or yoga
- Stay hydrated by drinking plenty of water
- Avoid smoking and limit alcohol
- Maintain good hygiene
- Get vaccinated as recommended
- Spend time in sunlight for vitamin D

By incorporating these natural ways into your daily routine, you can significantly boost your immune system and improve your overall health.`,
  },
  {
    id: 4,
    title: "Diabetes Management: Foods to Eat and Avoid",
    category: "Nutrition",
    icon: Heart,
    description: "Dietary guidelines for effective diabetes management and control.",
    readTime: "7 min read",
    fullContent: `Managing diabetes through diet is crucial for maintaining healthy blood sugar levels and preventing complications. Here's a comprehensive guide to eating with diabetes.

Foods to include:
- Vegetables: Broccoli, spinach, carrots, peppers (non-starchy)
- Whole grains: Brown rice, whole wheat bread, oats
- Lean proteins: Chicken, fish, tofu, beans
- Healthy fats: Olive oil, nuts, avocados
- Fruits: Berries, apples, oranges (in moderation)
- Low-fat dairy: Yogurt, milk, cheese

Foods to limit or avoid:
- Sugary drinks: Regular soda, juice, energy drinks
- Processed foods: Fast food, packaged snacks
- Refined carbohydrates: White bread, pastries
- High-fat meats: Bacon, sausage, fatty cuts
- Sugary desserts: Candy, cookies, ice cream
- Full-fat dairy: Whole milk, full-fat cheese

Meal planning tips:
- Eat at consistent times each day
- Control portion sizes
- Balance carbohydrates, proteins, and fats
- Monitor blood sugar levels regularly
- Stay hydrated with water
- Limit sodium intake

Working with a registered dietitian can help you create a personalized meal plan that fits your lifestyle and preferences while managing your diabetes effectively.`,
  },
  {
    id: 5,
    title: "Sleep Disorders and Sleep Hygiene",
    category: "Sleep Health",
    icon: Brain,
    description: "Understanding common sleep disorders and practices for better sleep quality.",
    readTime: "6 min read",
    fullContent: `Quality sleep is essential for physical health, mental well-being, and overall productivity. Unfortunately, many people struggle with sleep disorders. Let's explore common disorders and how to improve sleep quality.

Common sleep disorders:
- Insomnia: Difficulty falling asleep or staying asleep
- Sleep apnea: Breathing interruptions during sleep
- Restless leg syndrome: Uncomfortable sensations in legs
- Narcolepsy: Sudden, uncontrollable sleep episodes
- Circadian rhythm disorders: Sleep-wake schedule misalignment

Sleep hygiene practices:
- Keep a consistent sleep schedule
- Create a dark, quiet, cool bedroom (65-68°F is ideal)
- Avoid screens 1 hour before bed
- Limit caffeine after 2 PM
- Exercise regularly but not close to bedtime
- Avoid large meals close to bedtime
- Practice relaxation techniques like deep breathing
- Keep your bed for sleep only

When to seek help:
If you experience persistent sleep problems affecting your daily life, consult a sleep specialist. They can perform a sleep study to diagnose disorders and recommend appropriate treatment options including lifestyle changes, therapy, or medication.`,
  },
  {
    id: 6,
    title: "Exercise Benefits for Senior Citizens",
    category: "Fitness",
    icon: Zap,
    description: "Safe and effective exercise routines for older adults.",
    readTime: "5 min read",
    fullContent: `Regular exercise is vital for seniors to maintain health, independence, and quality of life. Exercise can prevent age-related decline and manage chronic conditions.

Benefits of exercise for seniors:
- Maintains muscle mass and bone density
- Improves balance and reduces fall risk
- Enhances cardiovascular health
- Supports mental health and cognitive function
- Helps manage chronic diseases like diabetes
- Improves flexibility and mobility
- Promotes better sleep quality
- Increases energy levels

Safe exercise options for seniors:
- Walking: Easy to start, no equipment needed
- Swimming: Low-impact, builds strength and endurance
- Tai Chi: Improves balance and flexibility
- Yoga: Enhances flexibility and reduces stress
- Strength training: Maintains muscle with light weights
- Dancing: Fun and improves coordination
- Gardening: Combines activity with enjoyment

Guidelines:
- Start slowly and gradually increase intensity
- Include balance exercises to prevent falls
- Do strength training 2-3 times per week
- Aim for at least 150 minutes of moderate activity weekly
- Always warm up and cool down
- Stay hydrated
- Consult your doctor before starting any new exercise program

Consistency is more important than intensity. Regular moderate exercise is better than occasional intense workouts.`,
  },
]

export default function ArticlesPage() {
  const [selectedArticle, setSelectedArticle] = useState<typeof articles[0] | null>(null)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center px-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
        </div>
      </header>

      <main className="container max-w-6xl px-4 py-12">
        {/* Hero Section */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">Health Articles</h1>
          <p className="text-lg text-muted-foreground max-w-2xl break-words text-pretty">
            Comprehensive health articles written by medical professionals. Learn about various health conditions, treatments, and wellness practices.
          </p>
        </div>

        {/* Featured Article */}
        <div className="mb-12 p-8 bg-gradient-to-r from-primary/10 to-primary/5 rounded-xl border border-primary/20">
          <div className="max-w-3xl">
            <div className="inline-block px-3 py-1 bg-primary/20 text-primary rounded-full text-sm font-medium mb-4">
              Featured Article
            </div>
            <h2 className="text-3xl font-bold mb-4 break-words text-pretty">Understanding Blood Pressure: Normal, High, and Low</h2>
            <p className="text-muted-foreground mb-6 break-words text-pretty">
              Blood pressure is one of the most important vital signs. Learn what your blood pressure readings mean and how to maintain healthy levels through lifestyle changes and when to seek medical help.
            </p>
            <Button onClick={() => setSelectedArticle(articles[0])}>Read Full Article</Button>
          </div>
        </div>

        {/* Articles Grid */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Browse Articles</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {articles.slice(1).map((article) => {
              const IconComponent = article.icon
              return (
                <Card key={article.id} className="hover:shadow-lg transition-shadow cursor-pointer overflow-hidden">
                  <CardHeader>
                    <div className="flex items-start gap-3 mb-3">
                      <div className="p-2 bg-primary/10 rounded-lg flex-shrink-0">
                        <IconComponent className="h-5 w-5 text-primary" />
                      </div>
                      <div className="px-2 py-1 bg-secondary text-secondary-foreground rounded text-xs font-medium h-fit flex-shrink-0">
                        {article.category}
                      </div>
                    </div>
                    <CardTitle className="text-lg break-words text-pretty">{article.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground text-sm break-words text-pretty">{article.description}</p>
                    <div className="flex items-center justify-between pt-4 border-t">
                      <span className="text-xs text-muted-foreground">{article.readTime}</span>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setSelectedArticle(article)}
                      >
                        Read
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </main>

      {/* Article Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <Card className="max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <CardHeader className="sticky top-0 bg-card border-b flex items-center justify-between">
              <CardTitle className="break-words text-pretty">{selectedArticle.title}</CardTitle>
              <button 
                onClick={() => setSelectedArticle(null)}
                className="p-1 hover:bg-secondary rounded flex-shrink-0"
              >
                <X className="h-5 w-5" />
              </button>
            </CardHeader>
            <CardContent className="py-6 space-y-4">
              <div className="flex items-center gap-4 text-sm text-muted-foreground pb-4 border-b">
                <span className="px-3 py-1 bg-secondary rounded">{selectedArticle.category}</span>
                <span>{selectedArticle.readTime}</span>
              </div>
              <div className="space-y-4">
                {selectedArticle.fullContent.split('\n\n').map((paragraph, idx) => (
                  <p key={idx} className="text-foreground leading-relaxed break-words text-pretty whitespace-pre-wrap">
                    {paragraph}
                  </p>
                ))}
              </div>
              <div className="pt-6 border-t">
                <p className="text-sm text-muted-foreground mb-4">
                  For personalized medical advice, consult with a healthcare professional.
                </p>
                <Link href="/doctors">
                  <Button className="w-full">Consult a Doctor</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
