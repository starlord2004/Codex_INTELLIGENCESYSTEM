"use client"

import Link from "next/link"
import { ArrowLeft, ChevronLeft, ChevronRight, Calendar, User, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useState } from "react"

const blogPosts = [
  {
    id: 1,
    title: "5 Tips for Maintaining a Healthy Lifestyle",
    author: "Dr. Sarah Johnson",
    date: "March 15, 2024",
    category: "Wellness",
    excerpt: "Learn practical tips to maintain a healthy lifestyle in today's busy world.",
    content: `Maintaining a healthy lifestyle is one of the best investments you can make in yourself. In today's fast-paced world, it's easy to neglect our health, but with these five practical tips, you can make lasting positive changes.

1. **Prioritize Sleep**
Sleep is not a luxury; it's a necessity. Aim for 7-9 hours of quality sleep each night. Poor sleep can lead to increased stress, weakened immunity, and weight gain. Establish a consistent sleep schedule and create a relaxing bedtime routine.

2. **Move Your Body Daily**
You don't need to spend hours at the gym. Aim for at least 30 minutes of moderate activity most days of the week. This could be walking, swimming, cycling, or any activity you enjoy. Regular movement improves cardiovascular health, mood, and energy levels.

3. **Eat Whole Foods**
Focus on eating whole, unprocessed foods like fruits, vegetables, whole grains, and lean proteins. These foods are nutrient-dense and keep you satisfied longer than processed alternatives. Try to cook at home more often to control the ingredients and portions.

4. **Manage Your Stress**
Chronic stress can negatively impact your health. Find stress management techniques that work for you, such as meditation, yoga, journaling, or spending time in nature. Even 10-15 minutes of daily relaxation can make a significant difference.

5. **Stay Hydrated**
Drinking enough water is crucial for every bodily function. Aim for at least 8 glasses a day, or more if you exercise regularly. Proper hydration improves energy, aids digestion, and supports cognitive function.

By implementing these five tips, you're taking control of your health and setting yourself up for a happier, healthier future. Remember, small changes lead to big results over time.`,
  },
  {
    id: 2,
    title: "Understanding Common Allergies and Treatments",
    author: "Dr. Michael Chen",
    date: "March 12, 2024",
    category: "Medical",
    excerpt: "A comprehensive guide to common allergies, their symptoms, and effective treatments.",
    content: `Allergies affect millions of people worldwide. Understanding your allergies and knowing how to manage them can significantly improve your quality of life.

**What is an Allergy?**
An allergy is an abnormal immune response to a substance that's usually harmless to most people. When you have an allergy, your immune system treats that substance (allergen) as a threat and produces antibodies to fight it.

**Common Types of Allergies:**

1. **Seasonal Allergies (Hay Fever)**
These are caused by pollen from trees, grasses, and weeds. Symptoms include sneezing, nasal congestion, and itchy eyes. They typically occur during spring, summer, or fall depending on your location.

2. **Food Allergies**
Common food allergies include peanuts, tree nuts, shellfish, dairy, eggs, and soy. Reactions can range from mild (itching in the mouth) to severe (anaphylaxis).

3. **Pet Allergies**
Many people are allergic to pet dander, saliva, or urine. If you're allergic but love pets, consider hypoallergenic breeds and regular cleaning.

4. **Drug Allergies**
Some people have allergic reactions to medications. Always inform your doctor about any previous drug allergies.

5. **Dust Mite Allergies**
These microscopic creatures live in bedding and can trigger allergies in sensitive individuals.

**Treatment Options:**

- **Antihistamines**: Block the effect of histamine, reducing symptoms
- **Decongestants**: Help relieve nasal congestion
- **Corticosteroids**: Reduce inflammation and immune response
- **Immunotherapy**: Gradually expose your body to allergens to build tolerance
- **Avoidance**: The most effective strategy is to avoid your known allergens

**When to See a Doctor:**
If your allergies are severe, frequent, or affecting your daily life, consult a doctor or allergist. They can perform tests to identify your specific allergens and recommend appropriate treatment.`,
  },
  {
    id: 3,
    title: "Nutrition Tips for Athletes",
    author: "Dr. Emily Rodriguez",
    date: "March 10, 2024",
    category: "Nutrition",
    excerpt: "How to fuel your body correctly for optimal athletic performance.",
    content: `Proper nutrition is as important as training for athletic performance. Here's what athletes need to know about fueling their bodies.

**Macronutrient Balance**

1. **Carbohydrates (45-65% of calories)**
Carbs are your body's primary fuel source, especially during high-intensity activities. Choose complex carbs like whole grains, oats, and sweet potatoes for sustained energy.

2. **Protein (1.2-2.0g per kg of body weight)**
Protein is essential for muscle repair and recovery. Include lean meats, fish, eggs, legumes, and dairy in your diet.

3. **Fats (20-35% of calories)**
Healthy fats support hormone production and nutrient absorption. Include sources like nuts, avocados, olive oil, and fatty fish.

**Timing Matters**

Pre-workout (2-3 hours before):
- Eat a meal with carbs and protein
- Example: Chicken with brown rice and vegetables

Post-workout (within 30-60 minutes):
- Consume carbs and protein to aid recovery
- Example: Protein smoothie with banana and yogurt

**Hydration**

Drink water consistently throughout the day, not just during workouts. During intense training lasting over 60 minutes, consider sports drinks with electrolytes.

**Micronutrients**

Don't neglect vitamins and minerals. Iron, calcium, magnesium, and antioxidants are particularly important for athletes.

**Avoid**

- Excessive sugar and processed foods
- High-fat foods before workouts
- Overeating, which can cause discomfort during exercise

**Individual Needs**

Every athlete is different. Consider consulting a sports nutritionist to create a personalized nutrition plan based on your sport, training intensity, and body composition goals.`,
  },
  {
    id: 4,
    title: "Mental Health Awareness in the Workplace",
    author: "Dr. James Wilson",
    date: "March 8, 2024",
    category: "Mental Health",
    excerpt: "Creating a supportive workplace environment for mental health.",
    content: `Mental health is an integral part of overall well-being, yet many workplaces fail to adequately address it. Here's how to create a mentally healthy workplace.

**The Impact of Work on Mental Health**

Work stress, long hours, and lack of support can lead to anxiety, depression, and burnout. A mentally healthy workplace benefits both employees and employers through increased productivity and reduced absenteeism.

**Signs of Mental Health Issues at Work**

- Decreased productivity and motivation
- Frequent absences
- Difficulty concentrating
- Increased irritability
- Social withdrawal
- Changes in work quality

**Creating a Supportive Environment**

1. **Open Communication**: Encourage employees to discuss mental health without stigma
2. **Flexible Work Arrangements**: Allow work-from-home options and flexible hours when possible
3. **Mental Health Resources**: Provide access to counseling and Employee Assistance Programs
4. **Stress Management Programs**: Offer yoga, meditation, or fitness classes
5. **Workload Management**: Ensure realistic workloads and deadlines
6. **Recognition and Support**: Acknowledge achievements and provide support during challenges

**For Employees**

- Take regular breaks
- Practice self-care
- Set boundaries between work and personal life
- Seek help when needed
- Connect with colleagues
- Engage in activities you enjoy outside of work

**Role of Leadership**

Managers should lead by example, practice self-care, and check in with team members. Creating a culture where mental health is prioritized makes a significant difference.

By addressing mental health in the workplace, we create a more productive, supportive, and healthier environment for everyone.`,
  },
  {
    id: 5,
    title: "Preventive Healthcare: Why It Matters",
    author: "Dr. Patricia Lee",
    date: "March 5, 2024",
    category: "Healthcare",
    excerpt: "Why regular check-ups and preventive measures are essential.",
    content: `Preventive healthcare is about taking proactive steps to maintain health and prevent diseases before they develop. It's often more effective and cost-efficient than treating diseases after they occur.

**The Three Levels of Prevention**

1. **Primary Prevention**: Preventing disease from occurring
   - Vaccinations
   - Healthy lifestyle choices
   - Safe practices

2. **Secondary Prevention**: Early detection and treatment
   - Regular screenings (cancer, cholesterol, blood pressure)
   - Health check-ups
   - Diagnostic tests

3. **Tertiary Prevention**: Managing existing conditions
   - Treatment and medication
   - Lifestyle modifications
   - Rehabilitation

**Why Regular Check-ups Matter**

Regular health check-ups can:
- Detect diseases early when treatment is most effective
- Monitor chronic conditions
- Identify risk factors
- Provide health education
- Establish a relationship with your healthcare provider

**Key Preventive Screenings**

- Blood pressure monitoring
- Cholesterol tests
- Diabetes screening
- Cancer screenings (mammography, colonoscopy, etc.)
- Bone density tests for older adults
- Mental health assessments

**Lifestyle Modifications**

The best prevention starts with lifestyle:
- Maintain a healthy weight
- Exercise regularly
- Eat nutritious foods
- Avoid smoking and excessive alcohol
- Manage stress
- Get adequate sleep

**Cost Benefits**

Investing in preventive healthcare can save significant money in the long run by avoiding expensive treatments for advanced diseases.

Take charge of your health today through preventive healthcare. Your future self will thank you.`,
  },
]

export default function BlogPage() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedPost, setSelectedPost] = useState<typeof blogPosts[0] | null>(null)

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev === 0 ? blogPosts.length - 1 : prev - 1))
  }

  const goToNext = () => {
    setCurrentIndex((prev) => (prev === blogPosts.length - 1 ? 0 : prev + 1))
  }

  const currentPost = blogPosts[currentIndex]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center px-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
        </div>
      </header>

      <main className="container max-w-4xl px-4 py-12">
        {/* Hero Section */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">Healthcare Blog</h1>
          <p className="text-lg text-muted-foreground max-w-2xl break-words text-pretty">
            Stay informed with the latest insights, tips, and advice on health and wellness from healthcare professionals.
          </p>
        </div>

        {/* Featured Blog Post Carousel */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Featured Posts</h2>
          
          <Card className="overflow-hidden">
            <CardContent className="p-0">
              <div className="grid md:grid-cols-3 min-h-[400px]">
                {/* Left Arrow */}
                <div className="flex items-center justify-center md:col-span-1 bg-muted/50 hover:bg-muted transition-colors cursor-pointer group" onClick={goToPrevious}>
                  <Button variant="ghost" size="lg" className="rounded-full">
                    <ChevronLeft className="h-8 w-8 group-hover:scale-110 transition-transform" />
                  </Button>
                </div>

                {/* Content */}
                <div className="md:col-span-1 p-8 flex flex-col justify-between bg-card">
                  <div>
                    <div className="inline-block px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium mb-4">
                      {currentPost.category}
                    </div>
                    <h3 className="text-2xl font-bold mb-4 break-words text-pretty">{currentPost.title}</h3>
                    <p className="text-muted-foreground mb-6 break-words text-pretty">{currentPost.excerpt}</p>
                    <div className="space-y-2 text-sm text-muted-foreground mb-6">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4" />
                        <span>{currentPost.author}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        <span>{currentPost.date}</span>
                      </div>
                    </div>
                  </div>
                  <Button 
                    onClick={() => setSelectedPost(currentPost)}
                    className="w-full"
                  >
                    Read Full Article
                  </Button>
                </div>

                {/* Right Arrow */}
                <div className="flex items-center justify-center md:col-span-1 bg-muted/50 hover:bg-muted transition-colors cursor-pointer group" onClick={goToNext}>
                  <Button variant="ghost" size="lg" className="rounded-full">
                    <ChevronRight className="h-8 w-8 group-hover:scale-110 transition-transform" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Carousel Indicators */}
          <div className="flex justify-center gap-2 mt-6">
            {blogPosts.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`h-2 rounded-full transition-all ${
                  index === currentIndex 
                    ? 'bg-primary w-8' 
                    : 'bg-muted-foreground/30 w-2 hover:bg-muted-foreground/50'
                }`}
                aria-label={`Go to post ${index + 1}`}
              />
            ))}
          </div>
        </div>

        {/* All Posts */}
        <div>
          <h2 className="text-2xl font-bold mb-6">All Posts</h2>
          <div className="space-y-6">
            {blogPosts.map((post) => (
              <Card key={post.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="inline-block px-3 py-1 bg-secondary text-secondary-foreground rounded text-xs font-medium mb-3">
                        {post.category}
                      </div>
                      <CardTitle className="text-xl break-words text-pretty">{post.title}</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground break-words text-pretty">{post.excerpt}</p>
                  <div className="flex items-center justify-between pt-4 border-t flex-wrap gap-4">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4" />
                        <span>{post.author}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        <span>{post.date}</span>
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setSelectedPost(post)}
                    >
                      Read More
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>

      {/* Blog Post Modal */}
      {selectedPost && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <Card className="max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <CardHeader className="sticky top-0 bg-card border-b flex items-center justify-between">
              <CardTitle className="break-words text-pretty">{selectedPost.title}</CardTitle>
              <button 
                onClick={() => setSelectedPost(null)}
                className="p-1 hover:bg-secondary rounded flex-shrink-0"
              >
                <X className="h-5 w-5" />
              </button>
            </CardHeader>
            <CardContent className="py-6 space-y-4">
              <div className="flex items-center gap-4 text-sm text-muted-foreground pb-4 border-b flex-wrap">
                <span className="px-3 py-1 bg-secondary rounded">{selectedPost.category}</span>
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  <span>{selectedPost.author}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <span>{selectedPost.date}</span>
                </div>
              </div>
              <div className="space-y-4">
                {selectedPost.content.split('\n\n').map((paragraph, idx) => (
                  <p key={idx} className="text-foreground leading-relaxed break-words text-pretty whitespace-pre-wrap">
                    {paragraph}
                  </p>
                ))}
              </div>
              <div className="pt-6 border-t">
                <p className="text-sm text-muted-foreground mb-4">
                  Have questions? Consult with a healthcare professional.
                </p>
                <Link href="/doctors">
                  <Button className="w-full">Book a Consultation</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
