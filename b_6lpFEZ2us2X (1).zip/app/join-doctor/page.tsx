import Link from "next/link"
import { ArrowLeft, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata = {
  title: "Join CAREVIA as a Doctor - CAREVIA",
  description: "Register and join CAREVIA as a healthcare professional",
}

export default function JoinDoctorPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center px-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
        </div>
      </header>

      <main className="container max-w-4xl py-12">
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">Join CAREVIA as a Doctor</h1>
          <p className="text-lg text-muted-foreground">
            Expand your practice and reach more patients through our platform
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 mb-12">
          {/* Benefits */}
          <div className="space-y-6">
            <h2 className="text-2xl font-semibold">Why Join CAREVIA?</h2>
            <div className="space-y-4">
              {[
                "Expand your patient base and reach across India",
                "Manage appointments and consultations seamlessly",
                "Receive secure payments directly to your account",
                "Access patient health records and medical history",
                "Build your professional profile and reputation",
                "Zero commission platform with transparent pricing",
              ].map((benefit, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                  <span>{benefit}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Registration Card */}
          <Card>
            <CardHeader>
              <CardTitle>Register Today</CardTitle>
              <CardDescription>
                Complete the registration to join our network
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-medium">Full Name</label>
                  <input
                    type="text"
                    placeholder="Dr. Name"
                    className="w-full mt-1 px-3 py-2 border border-border rounded-lg bg-background"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Specialty</label>
                  <select className="w-full mt-1 px-3 py-2 border border-border rounded-lg bg-background">
                    <option>Select Specialty</option>
                    <option>General Physician</option>
                    <option>Cardiologist</option>
                    <option>Dermatologist</option>
                    <option>Orthopedic</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium">Email</label>
                  <input
                    type="email"
                    placeholder="doctor@email.com"
                    className="w-full mt-1 px-3 py-2 border border-border rounded-lg bg-background"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Phone Number</label>
                  <input
                    type="tel"
                    placeholder="9876543210"
                    className="w-full mt-1 px-3 py-2 border border-border rounded-lg bg-background"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Medical License Number</label>
                  <input
                    type="text"
                    placeholder="License Number"
                    className="w-full mt-1 px-3 py-2 border border-border rounded-lg bg-background"
                  />
                </div>
              </div>
              <Button className="w-full">Register as Doctor</Button>
              <div className="text-center text-sm text-muted-foreground">
                Already have an account?{" "}
                <Link href="/doctor-login" className="text-primary hover:underline">
                  Sign In
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Support */}
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-3">Questions about registration?</h3>
            <p className="text-muted-foreground mb-4">
              Our onboarding team is ready to help. Contact us for assistance with the registration process.
            </p>
            <Link href="/contact">
              <Button variant="outline">Contact Support</Button>
            </Link>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
