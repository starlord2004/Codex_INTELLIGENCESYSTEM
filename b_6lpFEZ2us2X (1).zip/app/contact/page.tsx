import Link from "next/link"
import { ArrowLeft, Heart, Mail, Phone, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"

export const metadata = {
  title: "Contact Us - CAREVIA",
  description: "Get in touch with CAREVIA support team",
}

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center px-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
        </div>
      </header>

      <main className="container max-w-4xl py-12">
        <h1 className="text-4xl font-bold mb-8">Contact Us</h1>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-semibold mb-4">Get in Touch</h2>
              <p className="text-muted-foreground mb-6">
                Have questions about our services? We're here to help! Reach out to us through any of these channels.
              </p>
            </div>

            <div className="space-y-4">
              <a href="tel:+911800123456" className="flex items-start gap-4 p-4 rounded-lg border border-border hover:bg-secondary/30 transition">
                <Phone className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Call Us</p>
                  <p className="text-muted-foreground">1800-123-4567 (Toll Free)</p>
                  <p className="text-sm text-muted-foreground">Available 24/7</p>
                </div>
              </a>

              <a href="mailto:support@carevia.com" className="flex items-start gap-4 p-4 rounded-lg border border-border hover:bg-secondary/30 transition">
                <Mail className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Email Us</p>
                  <p className="text-muted-foreground">support@carevia.com</p>
                  <p className="text-sm text-muted-foreground">Response within 24 hours</p>
                </div>
              </a>

              <div className="flex items-start gap-4 p-4 rounded-lg border border-border">
                <MapPin className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Visit Us</p>
                  <p className="text-muted-foreground">123 Healthcare Street</p>
                  <p className="text-muted-foreground">Mumbai, Maharashtra 400001</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
