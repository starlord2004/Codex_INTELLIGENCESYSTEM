import Link from "next/link"
import { ArrowLeft, Briefcase, Users, MapPin, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata = {
  title: "Careers - CAREVIA",
  description: "Join our team and help transform healthcare in India",
}

const jobOpenings = [
  {
    id: 1,
    title: "Senior Full Stack Developer",
    department: "Engineering",
    location: "Bangalore",
    type: "Full-time",
    description: "Build scalable healthcare solutions using Next.js and modern web technologies.",
  },
  {
    id: 2,
    title: "Healthcare Content Writer",
    department: "Content",
    location: "Mumbai",
    type: "Full-time",
    description: "Create engaging health and wellness content for our blog and patient education.",
  },
  {
    id: 3,
    title: "Product Manager",
    department: "Product",
    location: "Delhi",
    type: "Full-time",
    description: "Lead product strategy and development for our healthcare platform.",
  },
  {
    id: 4,
    title: "Mobile App Developer",
    department: "Engineering",
    location: "Bangalore",
    type: "Full-time",
    description: "Develop mobile applications for iOS and Android platforms.",
  },
  {
    id: 5,
    title: "Data Analyst",
    department: "Data & Analytics",
    location: "Hyderabad",
    type: "Full-time",
    description: "Analyze healthcare data and provide insights to drive business decisions.",
  },
  {
    id: 6,
    title: "Customer Support Manager",
    department: "Support",
    location: "Chennai",
    type: "Full-time",
    description: "Lead and manage our customer support team to ensure excellent service.",
  },
]

export default function CareersPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center px-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
        </div>
      </header>

      <main className="container max-w-6xl py-12">
        {/* Hero Section */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">Join Our Team</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-8">
            We're hiring talented individuals who are passionate about transforming healthcare in India. Explore our current openings and be part of the CAREVIA mission.
          </p>
        </div>

        {/* About Section */}
        <div className="mb-12 p-8 bg-secondary/30 rounded-xl">
          <h2 className="text-2xl font-bold mb-4">Why Join CAREVIA?</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-semibold mb-2">Making an Impact</h3>
              <p className="text-muted-foreground">
                Work on a platform that's transforming healthcare access for millions of Indians.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Growth Opportunities</h3>
              <p className="text-muted-foreground">
                Join a fast-growing startup with unlimited learning and career advancement opportunities.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Great Culture</h3>
              <p className="text-muted-foreground">
                Experience a collaborative work environment where innovation and excellence are celebrated.
              </p>
            </div>
          </div>
        </div>

        {/* Open Positions */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Open Positions</h2>
          <div className="space-y-4">
            {jobOpenings.map((job) => (
              <Card key={job.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{job.title}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-2">{job.department}</p>
                    </div>
                    <div className="px-3 py-1 bg-primary/10 text-primary rounded text-xs font-medium">
                      {job.type}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">{job.description}</p>
                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      {job.location}
                    </div>
                    <Button variant="outline" size="sm">
                      Apply Now
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Contact Section */}
        <div className="mt-12 p-8 bg-gradient-to-r from-primary/5 to-primary/10 rounded-xl border border-primary/20 text-center">
          <h2 className="text-2xl font-bold mb-4">Don't see your role?</h2>
          <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
            We're always looking for talented individuals. Feel free to reach out with your profile and we'll connect if there's a fit.
          </p>
          <Link href="/contact">
            <Button>Contact HR</Button>
          </Link>
        </div>
      </main>
    </div>
  )
}
