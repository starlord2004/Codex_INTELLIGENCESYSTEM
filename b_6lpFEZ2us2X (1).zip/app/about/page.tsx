import Link from "next/link"
import { ArrowLeft, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"

export const metadata = {
  title: "About Us - CAREVIA",
  description: "Learn more about CAREVIA and our mission to revolutionize healthcare",
}

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center px-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
        </div>
      </header>

      <main className="container max-w-4xl py-12">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
              <Heart className="h-6 w-6 text-primary-foreground" fill="currentColor" />
            </div>
            <h1 className="text-4xl font-bold">About CAREVIA</h1>
          </div>
          <p className="text-lg text-muted-foreground">
            Your complete healthcare companion revolutionizing how you access medical services.
          </p>
        </div>

        <div className="space-y-8 text-foreground">
          <section>
            <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
            <p className="text-muted-foreground leading-relaxed">
              At CAREVIA, we believe that everyone deserves access to quality healthcare. Our mission is to make 
              healthcare more accessible, affordable, and convenient by connecting patients with qualified doctors, 
              providing medicines, conducting lab tests, and offering comprehensive health management solutions - 
              all from the comfort of your home.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">What We Offer</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold mt-1">•</span>
                <div>
                  <strong className="text-foreground">Find & Book Doctors</strong>
                  <p>Access a network of verified doctors across multiple specialties</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold mt-1">•</span>
                <div>
                  <strong className="text-foreground">Order Medicines</strong>
                  <p>Convenient online medicine ordering with fast delivery</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold mt-1">•</span>
                <div>
                  <strong className="text-foreground">Lab Tests</strong>
                  <p>Home sample collection and quick diagnostic reports</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold mt-1">•</span>
                <div>
                  <strong className="text-foreground">Health Management</strong>
                  <p>Track your health records and manage appointments in one place</p>
                </div>
              </li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">Why Choose CAREVIA?</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li>✓ Verified and experienced healthcare professionals</li>
              <li>✓ Competitive pricing and transparent billing</li>
              <li>✓ 100% Secure and confidential</li>
              <li>✓ Available 24/7 for your healthcare needs</li>
              <li>✓ Quick response and appointment confirmation</li>
            </ul>
          </section>
        </div>

        <div className="mt-12 p-8 bg-primary/5 rounded-xl border border-primary/20">
          <h3 className="text-xl font-semibold mb-3">Have Questions?</h3>
          <p className="text-muted-foreground mb-4">
            Reach out to our support team for any inquiries about CAREVIA services.
          </p>
          <Link href="/contact">
            <Button>Contact Us</Button>
          </Link>
        </div>
      </main>
    </div>
  )
}
