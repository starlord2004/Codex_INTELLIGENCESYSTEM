"use client"

import Link from "next/link"
import { ArrowLeft, Check, AlertCircle, ShoppingCart, Pill, PhoneCall } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { AgeInputStage } from "@/components/symptom-checker/age-input-stage"
import { FollowUpQuestionsStage } from "@/components/symptom-checker/follow-up-questions"
import {
  diseaseDatabase,
  generateFollowUpQuestions,
  predictDiseaseWithFollowUp,
} from "@/lib/symptom-checker-logic"

const commonSymptoms = [
  { id: "Fever", label: "Fever" },
  { id: "Cough", label: "Cough" },
  { id: "Cold/Runny Nose", label: "Cold/Runny Nose" },
  { id: "Sore Throat", label: "Sore Throat" },
  { id: "Headache", label: "Headache" },
  { id: "Body Ache", label: "Body Ache" },
  { id: "Fatigue", label: "Fatigue" },
  { id: "Nausea/Vomiting", label: "Nausea/Vomiting" },
  { id: "Diarrhea", label: "Diarrhea" },
  { id: "Abdominal Pain", label: "Abdominal Pain" },
  { id: "Chest Pain", label: "Chest Pain" },
  { id: "Shortness of Breath", label: "Shortness of Breath" },
  { id: "Dizziness", label: "Dizziness" },
  { id: "Skin Rash", label: "Skin Rash" },
  { id: "Joint Pain", label: "Joint Pain" },
  { id: "Insomnia", label: "Insomnia" },
]

// All doctors with their specialties
const allDoctors = [
  { id: "dr-priya-patel", name: "Dr. Priya Patel", specialty: "General Physician", rating: 4.8, fee: 450 },
  { id: "dr-priya-sharma", name: "Dr. Priya Sharma", specialty: "Cardiologist", rating: 4.9, fee: 600 },
  { id: "dr-mahesh-verma", name: "Dr. Mahesh Verma", specialty: "Orthopedic", rating: 4.9, fee: 600 },
  { id: "dr-rajesh-nair", name: "Dr. Rajesh Nair", specialty: "ENT Specialist", rating: 4.8, fee: 550 },
  { id: "dr-suresh-nair", name: "Dr. Suresh Nair", specialty: "Pulmonologist", rating: 4.8, fee: 550 },
  { id: "dr-meera-nair", name: "Dr. Meera Nair", specialty: "Neurologist", rating: 4.8, fee: 700 },
  { id: "dr-deepak-patel", name: "Dr. Deepak Patel", specialty: "Cardiologist", rating: 4.8, fee: 650 },
  { id: "dr-sharma", name: "Dr. Amit Sharma", specialty: "General Physician", rating: 4.9, fee: 500 },
  { id: "dr-arun-sharma", name: "Dr. Arun Sharma", specialty: "Psychiatry", rating: 4.7, fee: 600 },
  { id: "dr-neha-gupta", name: "Dr. Neha Gupta", specialty: "Neurologist", rating: 4.8, fee: 700 },
]

type Stage = "age" | "symptoms" | "followup" | "results"

export default function SymptomCheckerPage() {
  const router = useRouter()
  const [stage, setStage] = useState<Stage>("age")
  const [userAge, setUserAge] = useState<number | null>(null)
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([])
  const [diagnosis, setDiagnosis] = useState<keyof typeof diseaseDatabase | null>(null)
  const [selectedMedicines, setSelectedMedicines] = useState<string[]>([])
  const [followUpAnswers, setFollowUpAnswers] = useState<Record<string, string>>({})

  const handleAgeSubmit = (age: number) => {
    setUserAge(age)
    setStage("symptoms")
  }

  const handleSymptomChange = (symptomId: string) => {
    setSelectedSymptoms((prev) =>
      prev.includes(symptomId)
        ? prev.filter((s) => s !== symptomId)
        : [...prev, symptomId]
    )
  }

  const handleSymptomsContinue = () => {
    if (selectedSymptoms.length === 0) {
      alert("Please select at least one symptom")
      return
    }

    const questions = generateFollowUpQuestions(selectedSymptoms)
    if (questions.length > 0) {
      setStage("followup")
    } else {
      // No follow-up questions needed, go directly to results
      const predicted = predictDiseaseWithFollowUp(
        selectedSymptoms,
        {},
        userAge!
      )
      setDiagnosis(predicted)
      setStage("results")
    }
  }

  const handleFollowUpSubmit = (answers: Record<string, string>) => {
    setFollowUpAnswers(answers)
    const predicted = predictDiseaseWithFollowUp(
      selectedSymptoms,
      answers,
      userAge!
    )
    setDiagnosis(predicted)
    setStage("results")
  }

  const getRecommendedDoctors = () => {
    if (!diagnosis) return []
    const disease = diseaseDatabase[diagnosis]
    return allDoctors.filter(doc =>
      disease.recommendedSpecialties.includes(doc.specialty)
    )
  }

  const handleOrderMedicines = () => {
    if (selectedMedicines.length === 0) {
      alert("Please select at least one medicine")
      return
    }
    const medicineNames = selectedMedicines
      .map(m => diseaseDatabase[diagnosis!].medicines[parseInt(m)].name)
      .join(",")
    router.push(`/medicines?search=${encodeURIComponent(medicineNames)}`)
  }

  const handleBookAppointment = (doctorId: string) => {
    router.push(`/doctors/${doctorId}/book`)
  }

  const handleReset = () => {
    setStage("age")
    setUserAge(null)
    setSelectedSymptoms([])
    setDiagnosis(null)
    setSelectedMedicines([])
    setFollowUpAnswers({})
  }

  // Stage: Age Input
  if (stage === "age") {
    return <AgeInputStage onAgeSubmit={handleAgeSubmit} />
  }

  // Stage: Symptom Selection
  if (stage === "symptoms") {
    return (
      <div className="min-h-screen bg-background">
        <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur">
          <div className="container px-4 flex h-16 items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              className="gap-2"
              onClick={() => setStage("age")}
            >
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
            <div className="flex-1">
              <h1 className="text-xl font-bold">Select Symptoms</h1>
              <p className="text-sm text-muted-foreground">Age: {userAge} years</p>
            </div>
          </div>
        </header>

        <main className="container px-4 py-8">
          <div className="mb-12 p-8 bg-gradient-to-r from-primary/10 to-primary/5 rounded-xl border border-primary/20">
            <h2 className="text-2xl font-bold mb-2">Select Your Symptoms</h2>
            <p className="text-muted-foreground break-words">
              Choose all symptoms you&apos;re experiencing. We&apos;ll ask follow-up questions to refine our diagnosis.
            </p>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Your Symptoms</CardTitle>
              <p className="text-sm text-muted-foreground mt-2">Select all that apply</p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {commonSymptoms.map((symptom) => (
                  <label
                    key={symptom.id}
                    className="flex items-center gap-3 p-3 border rounded-lg hover:bg-secondary/50 cursor-pointer transition"
                  >
                    <Checkbox
                      checked={selectedSymptoms.includes(symptom.id)}
                      onCheckedChange={() => handleSymptomChange(symptom.id)}
                    />
                    <span className="font-medium break-words">{symptom.label}</span>
                  </label>
                ))}
              </div>

              {selectedSymptoms.length > 0 && (
                <div className="mt-6 pt-6 border-t">
                  <p className="text-sm text-muted-foreground mb-4">
                    Selected symptoms: {selectedSymptoms.length}
                  </p>
                  <Button
                    className="w-full"
                    size="lg"
                    onClick={handleSymptomsContinue}
                  >
                    <Check className="h-5 w-5 mr-2" />
                    Continue
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="pt-6">
              <div className="flex gap-3">
                <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-blue-900 mb-1">Information</p>
                  <p className="text-sm text-blue-800 break-words">
                    Your age group helps us provide more accurate recommendations.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  // Stage: Follow-up Questions
  if (stage === "followup") {
    const questions = generateFollowUpQuestions(selectedSymptoms)
    return (
      <FollowUpQuestionsStage
        questions={questions}
        selectedSymptoms={selectedSymptoms}
        onBack={() => setStage("symptoms")}
        onSubmit={handleFollowUpSubmit}
      />
    )
  }

  // Stage: Results
  if (stage === "results" && diagnosis) {
    const disease = diseaseDatabase[diagnosis]
    const recommendedDoctors = getRecommendedDoctors()

    return (
      <div className="min-h-screen bg-background">
        <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur">
          <div className="container px-4 flex h-16 items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              className="gap-2"
              onClick={handleReset}
            >
              <ArrowLeft className="h-4 w-4" />
              New Check
            </Button>
            <div className="flex-1">
              <h1 className="text-xl font-bold">Diagnosis Results</h1>
              <p className="text-sm text-muted-foreground">Based on your symptoms and answers</p>
            </div>
          </div>
        </header>

        <main className="container px-4 py-8">
          <Card className="mb-8 border-2 border-primary/30 bg-gradient-to-br from-primary/5 to-primary/0">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-2xl mb-2">{disease.name}</CardTitle>
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        disease.severity === "mild"
                          ? "bg-green-100 text-green-800"
                          : disease.severity === "moderate"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-red-100 text-red-800"
                      }`}
                    >
                      {disease.severity.charAt(0).toUpperCase() +
                        disease.severity.slice(1)}{" "}
                      Severity
                    </span>
                  </div>
                </div>
                <AlertCircle
                  className={`h-8 w-8 ${
                    disease.severity === "mild"
                      ? "text-green-600"
                      : disease.severity === "moderate"
                        ? "text-yellow-600"
                        : "text-red-600"
                  }`}
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground break-words">{disease.description}</p>
              {disease.severity === "severe" && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-sm font-semibold text-red-900">
                    ⚠️ Important: This condition requires immediate medical
                    attention. Please consult a doctor immediately.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="mb-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Pill className="h-5 w-5" />
                  Recommended Medicines
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {disease.medicines.map((medicine, idx) => (
                    <label
                      key={idx}
                      className="flex items-center gap-3 p-3 border rounded-lg hover:bg-secondary/50 cursor-pointer"
                    >
                      <Checkbox
                        checked={selectedMedicines.includes(idx.toString())}
                        onCheckedChange={() => {
                          setSelectedMedicines((prev) =>
                            prev.includes(idx.toString())
                              ? prev.filter((m) => m !== idx.toString())
                              : [...prev, idx.toString()]
                          )
                        }}
                      />
                      <div className="flex-1">
                        <p className="font-medium">{medicine.name}</p>
                      </div>
                      <span className="text-primary font-semibold">
                        ₹{medicine.price}
                      </span>
                    </label>
                  ))}
                </div>
                <Button
                  className="w-full mt-4"
                  onClick={handleOrderMedicines}
                  disabled={selectedMedicines.length === 0}
                >
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Order Selected Medicines ({selectedMedicines.length})
                </Button>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PhoneCall className="h-5 w-5" />
                  Recommended Doctors
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recommendedDoctors.length > 0 ? (
                    recommendedDoctors.map((doctor) => (
                      <div
                        key={doctor.id}
                        className="p-4 border rounded-lg hover:border-primary/50 transition"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <p className="font-semibold">{doctor.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {doctor.specialty}
                            </p>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center gap-1 text-sm font-semibold text-amber-500">
                              ⭐ {doctor.rating}
                            </div>
                            <p className="text-sm text-muted-foreground">
                              ₹{doctor.fee} consultation
                            </p>
                          </div>
                        </div>
                        <Button
                          className="w-full"
                          onClick={() => handleBookAppointment(doctor.id)}
                        >
                          Book Appointment
                        </Button>
                      </div>
                    ))
                  ) : (
                    <p className="text-muted-foreground text-center py-8">
                      No doctors available for this condition
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }
}
