"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { 
  ArrowLeft,
  Search,
  FlaskConical,
  Clock,
  Home,
  FileText,
  Shield,
  ChevronRight,
  Star,
  MapPin,
  Check,
  Calendar,
  Sun,
  Sunset
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"

// Mock lab tests data
const labTestsData = [
  {
    id: "test-1",
    name: "Complete Blood Count (CBC)",
    description: "Measures different components of blood including RBC, WBC, Hemoglobin, Platelets",
    parameters: 24,
    mrp: 450,
    discount: 40,
    price: 270,
    reportTime: "6 hours",
    fasting: false,
    homeCollection: true,
    popular: true
  },
  {
    id: "test-2",
    name: "Lipid Profile",
    description: "Complete cholesterol test including Total Cholesterol, HDL, LDL, Triglycerides",
    parameters: 8,
    mrp: 700,
    discount: 35,
    price: 455,
    reportTime: "12 hours",
    fasting: true,
    homeCollection: true,
    popular: true
  },
  {
    id: "test-3",
    name: "Thyroid Profile (T3, T4, TSH)",
    description: "Complete thyroid function test to check thyroid hormone levels",
    parameters: 3,
    mrp: 850,
    discount: 45,
    price: 467.50,
    reportTime: "24 hours",
    fasting: false,
    homeCollection: true,
    popular: true
  },
  {
    id: "test-4",
    name: "Liver Function Test (LFT)",
    description: "Measures enzymes, proteins, and bilirubin to assess liver health",
    parameters: 11,
    mrp: 650,
    discount: 30,
    price: 455,
    reportTime: "12 hours",
    fasting: true,
    homeCollection: true,
    popular: false
  },
  {
    id: "test-5",
    name: "Kidney Function Test (KFT)",
    description: "Measures creatinine, urea, uric acid to assess kidney health",
    parameters: 7,
    mrp: 550,
    discount: 35,
    price: 357.50,
    reportTime: "12 hours",
    fasting: false,
    homeCollection: true,
    popular: false
  },
  {
    id: "test-6",
    name: "HbA1c (Glycated Hemoglobin)",
    description: "3-month average blood sugar level test for diabetes monitoring",
    parameters: 1,
    mrp: 600,
    discount: 40,
    price: 360,
    reportTime: "24 hours",
    fasting: false,
    homeCollection: true,
    popular: true
  },
  {
    id: "test-7",
    name: "Vitamin D (25-OH)",
    description: "Measures Vitamin D levels in blood to check for deficiency",
    parameters: 1,
    mrp: 1200,
    discount: 50,
    price: 600,
    reportTime: "24 hours",
    fasting: false,
    homeCollection: true,
    popular: true
  },
  {
    id: "test-8",
    name: "Vitamin B12",
    description: "Measures Vitamin B12 levels to check for deficiency",
    parameters: 1,
    mrp: 900,
    discount: 45,
    price: 495,
    reportTime: "24 hours",
    fasting: false,
    homeCollection: true,
    popular: false
  }
]

const healthPackages = [
  {
    id: "pkg-1",
    name: "Basic Health Checkup",
    tests: ["CBC", "Blood Sugar", "Lipid Profile", "Liver Function", "Kidney Function"],
    parameters: 55,
    mrp: 2500,
    discount: 60,
    price: 999,
    popular: true
  },
  {
    id: "pkg-2",
    name: "Comprehensive Health Checkup",
    tests: ["CBC", "Lipid Profile", "LFT", "KFT", "Thyroid", "HbA1c", "Vitamin D", "Vitamin B12", "Urine Analysis"],
    parameters: 85,
    mrp: 5500,
    discount: 65,
    price: 1925,
    popular: true
  },
  {
    id: "pkg-3",
    name: "Diabetes Care Package",
    tests: ["Blood Sugar Fasting", "Blood Sugar PP", "HbA1c", "Kidney Function", "Lipid Profile"],
    parameters: 25,
    mrp: 2200,
    discount: 55,
    price: 990,
    popular: false
  }
]

type BookingStep = "select" | "schedule" | "confirm"

export default function LabTestsPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedTests, setSelectedTests] = useState<string[]>([])
  const [step, setStep] = useState<BookingStep>("select")
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null)
  const [collectionType, setCollectionType] = useState<"home" | "lab">("home")

  const filteredTests = labTestsData.filter(test => 
    test.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    test.description.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const toggleTest = (testId: string) => {
    setSelectedTests(prev => 
      prev.includes(testId) 
        ? prev.filter(id => id !== testId)
        : [...prev, testId]
    )
  }

  const selectedTestsData = labTestsData.filter(test => selectedTests.includes(test.id))
  const totalPrice = selectedTestsData.reduce((sum, test) => sum + test.price, 0)
  const totalMrp = selectedTestsData.reduce((sum, test) => sum + test.mrp, 0)
  const homeCollectionFee = collectionType === "home" ? 50 : 0

  const generateDates = () => {
    const dates = []
    const today = new Date()
    for (let i = 0; i < 7; i++) {
      const date = new Date(today)
      date.setDate(today.getDate() + i)
      dates.push(date)
    }
    return dates
  }

  const formatDate = (date: Date) => {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return {
      day: days[date.getDay()],
      date: date.getDate(),
      month: months[date.getMonth()],
      isToday: date.toDateString() === new Date().toDateString()
    }
  }

  const morningSlots = ["6:00 AM", "7:00 AM", "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM"]
  const eveningSlots = ["3:00 PM", "4:00 PM", "5:00 PM", "6:00 PM"]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center gap-4 px-4">
          <button 
            onClick={() => step === "select" ? router.back() : setStep(step === "confirm" ? "schedule" : "select")}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <main className="container px-4 py-6 max-w-4xl mx-auto">
        {step === "select" && (
          <>
            {/* Page Title */}
            <div className="mb-6">
              <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">Book Lab Tests</h1>
              <p className="text-muted-foreground">Home sample collection available</p>
            </div>

            {/* Promises */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="flex flex-col items-center text-center p-3 bg-card rounded-xl border border-border">
                <Home className="h-6 w-6 text-primary mb-2" />
                <p className="text-xs font-medium text-foreground">Home Collection</p>
                <p className="text-xs text-muted-foreground">At your doorstep</p>
              </div>
              <div className="flex flex-col items-center text-center p-3 bg-card rounded-xl border border-border">
                <FileText className="h-6 w-6 text-primary mb-2" />
                <p className="text-xs font-medium text-foreground">E-Reports</p>
                <p className="text-xs text-muted-foreground">On WhatsApp/Email</p>
              </div>
              <div className="flex flex-col items-center text-center p-3 bg-card rounded-xl border border-border">
                <Shield className="h-6 w-6 text-primary mb-2" />
                <p className="text-xs font-medium text-foreground">NABL Labs</p>
                <p className="text-xs text-muted-foreground">Certified partners</p>
              </div>
            </div>

            {/* Search */}
            <div className="relative mb-6">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search for tests..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12"
              />
            </div>

            {/* Health Packages */}
            <div className="mb-8">
              <h2 className="text-lg font-bold text-foreground mb-4">Popular Health Packages</h2>
              <div className="space-y-4">
                {healthPackages.map((pkg) => (
                  <Card key={pkg.id} className="overflow-hidden">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-foreground">{pkg.name}</h3>
                            {pkg.popular && (
                              <Badge variant="secondary" className="text-[10px] bg-amber-100 text-amber-700">Popular</Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">{pkg.parameters} parameters included</p>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {pkg.tests.slice(0, 4).map((test, i) => (
                              <Badge key={i} variant="outline" className="text-[10px]">{test}</Badge>
                            ))}
                            {pkg.tests.length > 4 && (
                              <Badge variant="outline" className="text-[10px]">+{pkg.tests.length - 4} more</Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-3">
                            <span className="font-bold text-lg text-foreground">Rs. {pkg.price}</span>
                            <span className="text-sm text-muted-foreground line-through">Rs. {pkg.mrp}</span>
                            <Badge variant="secondary" className="text-[10px] bg-emerald-100 text-emerald-700">
                              {pkg.discount}% off
                            </Badge>
                          </div>
                        </div>
                        <Button size="sm" onClick={() => router.push(`/lab-tests/${pkg.id}`)}>
                          Book
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Individual Tests */}
            <div>
              <h2 className="text-lg font-bold text-foreground mb-4">Individual Tests</h2>
              <div className="space-y-3">
                {filteredTests.map((test) => (
                  <Card 
                    key={test.id} 
                    className={`overflow-hidden cursor-pointer transition-all ${
                      selectedTests.includes(test.id) ? "border-primary bg-primary/5" : ""
                    }`}
                    onClick={() => toggleTest(test.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Checkbox 
                          checked={selectedTests.includes(test.id)}
                          onCheckedChange={() => toggleTest(test.id)}
                          className="mt-1"
                        />
                        <div className="flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="flex items-center gap-2">
                                <h3 className="font-medium text-foreground">{test.name}</h3>
                                {test.popular && (
                                  <Badge variant="secondary" className="text-[10px] bg-amber-100 text-amber-700">Popular</Badge>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground mt-0.5">{test.description}</p>
                            </div>
                          </div>
                          <div className="flex flex-wrap items-center gap-3 mt-2">
                            <span className="text-xs text-muted-foreground">{test.parameters} parameters</span>
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {test.reportTime}
                            </span>
                            {test.fasting && (
                              <Badge variant="outline" className="text-[10px]">Fasting required</Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-2">
                            <span className="font-bold text-foreground">Rs. {test.price}</span>
                            <span className="text-sm text-muted-foreground line-through">Rs. {test.mrp}</span>
                            <Badge variant="secondary" className="text-[10px] bg-emerald-100 text-emerald-700">
                              {test.discount}% off
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </>
        )}

        {step === "schedule" && (
          <>
            <h2 className="text-xl font-bold text-foreground mb-6">Schedule Sample Collection</h2>

            {/* Collection Type */}
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Collection Type</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <button
                  onClick={() => setCollectionType("home")}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg border-2 transition-all ${
                    collectionType === "home" ? "border-primary bg-primary/5" : "border-border"
                  }`}
                >
                  <Home className={`h-5 w-5 ${collectionType === "home" ? "text-primary" : "text-muted-foreground"}`} />
                  <div className="flex-1 text-left">
                    <p className="font-medium text-foreground">Home Collection</p>
                    <p className="text-sm text-muted-foreground">Sample collection at your doorstep</p>
                  </div>
                  <span className="text-sm text-muted-foreground">Rs. 50</span>
                </button>
                <button
                  onClick={() => setCollectionType("lab")}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg border-2 transition-all ${
                    collectionType === "lab" ? "border-primary bg-primary/5" : "border-border"
                  }`}
                >
                  <MapPin className={`h-5 w-5 ${collectionType === "lab" ? "text-primary" : "text-muted-foreground"}`} />
                  <div className="flex-1 text-left">
                    <p className="font-medium text-foreground">Visit Lab</p>
                    <p className="text-sm text-muted-foreground">Visit nearest partner lab</p>
                  </div>
                  <span className="text-sm text-emerald-600">Free</span>
                </button>
              </CardContent>
            </Card>

            {/* Date Selection */}
            <div className="mb-6">
              <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                Select Date
              </h3>
              <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4">
                {generateDates().map((date) => {
                  const formatted = formatDate(date)
                  const isSelected = date.toDateString() === selectedDate.toDateString()
                  return (
                    <button
                      key={date.toISOString()}
                      onClick={() => setSelectedDate(date)}
                      className={`flex flex-col items-center min-w-[60px] p-3 rounded-xl border-2 transition-all ${
                        isSelected 
                          ? "border-primary bg-primary/10" 
                          : "border-border bg-card hover:border-primary/50"
                      }`}
                    >
                      <span className="text-xs text-muted-foreground">{formatted.day}</span>
                      <span className={`text-lg font-bold ${isSelected ? "text-primary" : "text-foreground"}`}>
                        {formatted.date}
                      </span>
                      <span className="text-xs text-muted-foreground">{formatted.month}</span>
                      {formatted.isToday && (
                        <Badge variant="secondary" className="mt-1 text-[10px] px-1.5 py-0">Today</Badge>
                      )}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Time Slots */}
            <div className="space-y-6">
              <div>
                <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                  <Sun className="h-4 w-4 text-amber-500" />
                  Morning Slots
                </h4>
                <div className="grid grid-cols-3 gap-2">
                  {morningSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => setSelectedSlot(slot)}
                      className={`px-3 py-2 text-sm border rounded-lg transition-colors ${
                        selectedSlot === slot 
                          ? "border-primary bg-primary text-primary-foreground" 
                          : "border-border bg-card hover:border-primary"
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                  <Sunset className="h-4 w-4 text-orange-500" />
                  Evening Slots
                </h4>
                <div className="grid grid-cols-3 gap-2">
                  {eveningSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => setSelectedSlot(slot)}
                      className={`px-3 py-2 text-sm border rounded-lg transition-colors ${
                        selectedSlot === slot 
                          ? "border-primary bg-primary text-primary-foreground" 
                          : "border-border bg-card hover:border-primary"
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}

        {step === "confirm" && (
          <>
            <h2 className="text-xl font-bold text-foreground mb-6">Confirm Booking</h2>

            {/* Selected Tests */}
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Selected Tests ({selectedTestsData.length})</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {selectedTestsData.map((test) => (
                  <div key={test.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                    <div>
                      <p className="font-medium text-foreground text-sm">{test.name}</p>
                      <p className="text-xs text-muted-foreground">{test.parameters} parameters</p>
                    </div>
                    <span className="font-medium">Rs. {test.price}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Schedule Details */}
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Collection Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  {collectionType === "home" ? (
                    <Home className="h-5 w-5 text-primary" />
                  ) : (
                    <MapPin className="h-5 w-5 text-primary" />
                  )}
                  <div>
                    <p className="font-medium text-foreground">
                      {collectionType === "home" ? "Home Collection" : "Lab Visit"}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {formatDate(selectedDate).day}, {formatDate(selectedDate).date} {formatDate(selectedDate).month} at {selectedSlot}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Bill Details */}
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Bill Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tests Total</span>
                  <span>Rs. {totalPrice.toFixed(2)}</span>
                </div>
                {collectionType === "home" && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Home Collection Fee</span>
                    <span>Rs. {homeCollectionFee}</span>
                  </div>
                )}
                <Separator />
                <div className="flex justify-between">
                  <span className="font-semibold">Total Amount</span>
                  <span className="font-bold text-lg text-primary">Rs. {(totalPrice + homeCollectionFee).toFixed(2)}</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-600 text-sm">
                  <Check className="h-4 w-4" />
                  <span>You save Rs. {(totalMrp - totalPrice).toFixed(2)}</span>
                </div>
              </CardContent>
            </Card>

            {/* CareVia Promises */}
            <Card className="mb-6 bg-primary/5 border-primary/20">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>E-Reports on WhatsApp & Email</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>NABL Accredited Labs</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Free Doctor Consultation on Reports</span>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </main>

      {/* Bottom CTA */}
      {selectedTests.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-card border-t border-border">
          <div className="container max-w-4xl mx-auto">
            {step === "select" && (
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{selectedTests.length} tests selected</p>
                  <p className="font-bold text-lg text-foreground">Rs. {totalPrice.toFixed(2)}</p>
                </div>
                <Button onClick={() => setStep("schedule")} className="gap-1">
                  Schedule Collection
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
            {step === "schedule" && (
              <Button 
                onClick={() => setStep("confirm")} 
                className="w-full h-12"
                disabled={!selectedSlot}
              >
                Continue to Payment
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            )}
            {step === "confirm" && (
              <Button 
                onClick={() => router.push("/lab-tests/success")}
                className="w-full h-14 text-lg font-semibold"
              >
                Confirm & Pay Rs. {(totalPrice + homeCollectionFee).toFixed(2)}
              </Button>
            )}
          </div>
        </div>
      )}

      {/* Spacer for fixed bottom */}
      {selectedTests.length > 0 && <div className="h-24" />}
    </div>
  )
}
