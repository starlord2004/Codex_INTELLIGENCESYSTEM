"use client"

import Link from "next/link"
import { Check, ArrowLeft, Home, Calendar, Clock, DollarSign, FileText, Phone, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Suspense, useEffect, useState } from "react"

function BookingConfirmedContent() {
  const [booking, setBooking] = useState<any>(null)

  useEffect(() => {
    const lastBooking = localStorage.getItem('lastLabBooking')
    if (lastBooking) {
      setBooking(JSON.parse(lastBooking))
    }
  }, [])

  if (!booking) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card>
          <CardContent className="py-8 text-center">
            <p className="text-muted-foreground mb-4">Loading booking details...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  const confirmationNumber = `LAB${Math.random().toString(36).substr(2, 9).toUpperCase()}`

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur">
        <div className="container px-4 flex h-16 items-center gap-4">
          <Link href="/lab-tests">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
          <h1 className="font-bold">Booking Confirmed</h1>
        </div>
      </header>

      <main className="container px-4 py-8 max-w-2xl">
        {/* Success Message */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center">
              <Check className="h-8 w-8 text-green-600" />
            </div>
          </div>
          <h2 className="text-3xl font-bold mb-2">Lab Test Booked Successfully!</h2>
          <p className="text-muted-foreground">Your appointment has been confirmed. Check your email for details.</p>
        </div>

        {/* Confirmation Number */}
        <Card className="mb-6 border-green-200 bg-green-50">
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">Confirmation Number</p>
              <p className="text-2xl font-bold text-green-700 font-mono">{confirmationNumber}</p>
            </div>
          </CardContent>
        </Card>

        {/* Booking Details */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Booking Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <FileText className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-muted-foreground">Test Name</p>
                  <p className="font-semibold break-words">{booking.testName}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Calendar className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-muted-foreground">Appointment Date</p>
                  <p className="font-semibold">{new Date(booking.date).toDateString()}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-muted-foreground">Appointment Time</p>
                  <p className="font-semibold">{booking.slot}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Home className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-muted-foreground">Collection Type</p>
                  <p className="font-semibold">{booking.collectionType === "home" ? "Home Collection" : "Visit Lab"}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <DollarSign className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-muted-foreground">Total Amount Paid</p>
                  <p className="font-semibold text-lg">₹{booking.totalPrice}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Next Steps */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-base">What's Next?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex gap-3">
              <Badge className="flex-shrink-0">1</Badge>
              <div>
                <p className="font-medium">Prepare for your test</p>
                <p className="text-sm text-muted-foreground">Please check if fasting is required</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Badge className="flex-shrink-0">2</Badge>
              <div>
                <p className="font-medium">Sample Collection</p>
                <p className="text-sm text-muted-foreground">Our collection agent will visit at your scheduled time</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Badge className="flex-shrink-0">3</Badge>
              <div>
                <p className="font-medium">Receive Results</p>
                <p className="text-sm text-muted-foreground">Results will be sent to your email/WhatsApp within the turnaround time</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Support */}
        <Card className="bg-blue-50 border-blue-200 mb-6">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <Phone className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-foreground mb-1">Need Help?</p>
                <p className="text-sm text-muted-foreground mb-2">If you have any questions, call us at <a href="tel:1800123456" className="text-blue-600 hover:underline font-medium">1800-123-456</a></p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Link href="/lab-tests" className="flex-1">
            <Button variant="outline" className="w-full">
              Book Another Test
            </Button>
          </Link>
          <Link href="/" className="flex-1">
            <Button className="w-full">
              Go to Home
            </Button>
          </Link>
        </div>
      </main>
    </div>
  )
}

export default function BookingConfirmedPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    }>
      <BookingConfirmedContent />
    </Suspense>
  )
}
