"use client"

import Link from "next/link"
import { ArrowLeft, Calendar, Sun, Sunset, Home, MapPin, Check, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useRouter, useParams } from "next/navigation"
import { useState } from "react"

const labTestsData = [
  {
    id: "test-1",
    name: "Complete Blood Count (CBC)",
    description: "Measures different components of blood including RBC, WBC, Hemoglobin, Platelets",
    parameters: 24,
    mrp: 450,
    discount: 40,
    price: 270,
    reportTime: "6 hours",
    fasting: false,
    homeCollection: true,
  },
  {
    id: "test-2",
    name: "Lipid Profile",
    description: "Complete cholesterol test including Total Cholesterol, HDL, LDL, Triglycerides",
    parameters: 8,
    mrp: 700,
    discount: 35,
    price: 455,
    reportTime: "12 hours",
    fasting: true,
    homeCollection: true,
  },
  {
    id: "test-3",
    name: "Thyroid Profile (T3, T4, TSH)",
    description: "Complete thyroid function test to check thyroid hormone levels",
    parameters: 3,
    mrp: 850,
    discount: 45,
    price: 467.50,
    reportTime: "24 hours",
    fasting: false,
    homeCollection: true,
  },
]

export default function LabTestBookingPage() {
  const params = useParams()
  const router = useRouter()
  const testId = params.id as string
  
  const test = labTestsData.find(t => t.id === testId)
  const [step, setStep] = useState<"schedule" | "payment" | "confirm">("schedule")
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null)
  const [collectionType, setCollectionType] = useState<"home" | "lab">("home")

  if (!test) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card>
          <CardContent className="py-8 text-center">
            <p className="text-muted-foreground mb-4">Test not found</p>
            <Link href="/lab-tests">
              <Button>Back to Lab Tests</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const generateDates = () => {
    const dates = []
    const today = new Date()
    for (let i = 0; i < 7; i++) {
      const date = new Date(today)
      date.setDate(today.getDate() + i)
      dates.push(date)
    }
    return dates
  }

  const formatDate = (date: Date) => {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return {
      day: days[date.getDay()],
      date: date.getDate(),
      month: months[date.getMonth()],
      isToday: date.toDateString() === new Date().toDateString()
    }
  }

  const morningSlots = ["6:00 AM", "7:00 AM", "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM"]
  const eveningSlots = ["3:00 PM", "4:00 PM", "5:00 PM", "6:00 PM"]
  const homeCollectionFee = collectionType === "home" ? 50 : 0
  const totalPrice = test.price + homeCollectionFee

  const handleConfirmPayment = () => {
    // Save booking details
    const bookingDetails = {
      testId: test.id,
      testName: test.name,
      date: selectedDate.toISOString(),
      slot: selectedSlot,
      collectionType,
      totalPrice,
      status: "confirmed"
    }
    
    // Store in localStorage temporarily
    localStorage.setItem('lastLabBooking', JSON.stringify(bookingDetails))
    
    // Navigate to success page
    router.push(`/lab-tests/booking-confirmed?testId=${test.id}`)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur">
        <div className="container px-4 flex h-16 items-center gap-4">
          <Link href="/lab-tests">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
          <div>
            <h1 className="font-bold">{test.name}</h1>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8 max-w-3xl">
        {/* Test Summary */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <h2 className="font-bold text-lg mb-4">{test.name}</h2>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">MRP</span>
                <span className="line-through">₹{test.mrp}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Discount</span>
                <span className="text-emerald-600">{test.discount}% off</span>
              </div>
              <div className="border-t pt-3 flex justify-between font-bold">
                <span>Price</span>
                <span>₹{test.price}</span>
              </div>
              <div className="flex flex-wrap gap-2 mt-4">
                <Badge variant="outline">{test.parameters} parameters</Badge>
                <Badge variant="outline">Report in {test.reportTime}</Badge>
                {test.fasting && <Badge variant="outline">Fasting required</Badge>}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Progress Steps */}
        <div className="flex gap-2 mb-8">
          <button 
            onClick={() => setStep("schedule")}
            className={`flex-1 p-3 rounded-lg border-2 text-center font-medium transition-colors ${
              step === "schedule" 
                ? "border-primary bg-primary/10 text-primary"
                : step === "payment" || step === "confirm"
                ? "border-primary bg-primary/10 text-primary cursor-pointer"
                : "border-border"
            }`}
          >
            Schedule
          </button>
          <button 
            onClick={() => selectedSlot && setStep("payment")}
            className={`flex-1 p-3 rounded-lg border-2 text-center font-medium transition-colors ${
              step === "payment" 
                ? "border-primary bg-primary/10 text-primary"
                : step === "confirm"
                ? "border-primary bg-primary/10 text-primary cursor-pointer"
                : "border-border"
            }`}
          >
            Payment
          </button>
          <button 
            className={`flex-1 p-3 rounded-lg border-2 text-center font-medium transition-colors ${
              step === "confirm" 
                ? "border-primary bg-primary/10 text-primary"
                : "border-border"
            }`}
          >
            Confirm
          </button>
        </div>

        {/* Schedule Step */}
        {step === "schedule" && (
          <div className="space-y-6">
            {/* Collection Type */}
            <div>
              <h3 className="font-semibold text-foreground mb-4">Select Collection Type</h3>
              <div className="space-y-3">
                <button
                  onClick={() => setCollectionType("home")}
                  className={`w-full flex items-center gap-3 p-4 rounded-lg border-2 transition-all ${
                    collectionType === "home" ? "border-primary bg-primary/5" : "border-border"
                  }`}
                >
                  <Home className={`h-5 w-5 flex-shrink-0 ${collectionType === "home" ? "text-primary" : "text-muted-foreground"}`} />
                  <div className="flex-1 text-left">
                    <p className="font-medium text-foreground">Home Collection</p>
                    <p className="text-sm text-muted-foreground">Sample collection at your doorstep</p>
                  </div>
                  <span className="text-sm font-medium">+₹50</span>
                </button>
                <button
                  onClick={() => setCollectionType("lab")}
                  className={`w-full flex items-center gap-3 p-4 rounded-lg border-2 transition-all ${
                    collectionType === "lab" ? "border-primary bg-primary/5" : "border-border"
                  }`}
                >
                  <MapPin className={`h-5 w-5 flex-shrink-0 ${collectionType === "lab" ? "text-primary" : "text-muted-foreground"}`} />
                  <div className="flex-1 text-left">
                    <p className="font-medium text-foreground">Visit Lab</p>
                    <p className="text-sm text-muted-foreground">Visit our partner lab</p>
                  </div>
                  <span className="text-sm font-medium text-emerald-600">Free</span>
                </button>
              </div>
            </div>

            {/* Date Selection */}
            <div>
              <h3 className="font-semibold text-foreground mb-4">Select Date</h3>
              <div className="flex gap-2 overflow-x-auto pb-2">
                {generateDates().map((date) => {
                  const formatted = formatDate(date)
                  const isSelected = date.toDateString() === selectedDate.toDateString()
                  return (
                    <button
                      key={date.toISOString()}
                      onClick={() => setSelectedDate(date)}
                      className={`flex flex-col items-center min-w-[60px] p-3 rounded-lg border-2 transition-all ${
                        isSelected 
                          ? "border-primary bg-primary/10" 
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <span className="text-xs text-muted-foreground">{formatted.day}</span>
                      <span className="text-lg font-bold">{formatted.date}</span>
                      <span className="text-xs text-muted-foreground">{formatted.month}</span>
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Time Slots */}
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                  <Sun className="h-4 w-4 text-amber-500" />
                  Morning Slots
                </h4>
                <div className="grid grid-cols-3 gap-2">
                  {morningSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => setSelectedSlot(slot)}
                      className={`px-3 py-2 text-sm border rounded-lg transition-colors ${
                        selectedSlot === slot 
                          ? "border-primary bg-primary text-primary-foreground" 
                          : "border-border hover:border-primary"
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                  <Sunset className="h-4 w-4 text-orange-500" />
                  Evening Slots
                </h4>
                <div className="grid grid-cols-3 gap-2">
                  {eveningSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => setSelectedSlot(slot)}
                      className={`px-3 py-2 text-sm border rounded-lg transition-colors ${
                        selectedSlot === slot 
                          ? "border-primary bg-primary text-primary-foreground" 
                          : "border-border hover:border-primary"
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <Button 
              onClick={() => setStep("payment")} 
              disabled={!selectedSlot}
              className="w-full"
            >
              Continue to Payment
            </Button>
          </div>
        )}

        {/* Payment Step */}
        {step === "payment" && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{test.name}</span>
                  <span>₹{test.price}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Collection Charge</span>
                  <span>₹{homeCollectionFee}</span>
                </div>
                <div className="border-t pt-3 flex justify-between font-bold text-lg">
                  <span>Total Amount</span>
                  <span>₹{totalPrice}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Booking Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Date:</span>
                  <span>{selectedDate.toDateString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Slot:</span>
                  <span>{selectedSlot}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Collection Type:</span>
                  <span>{collectionType === "home" ? "Home Collection" : "Visit Lab"}</span>
                </div>
              </CardContent>
            </Card>

            <div className="flex gap-3">
              <Button 
                variant="outline" 
                onClick={() => setStep("schedule")}
                className="flex-1"
              >
                Back
              </Button>
              <Button 
                onClick={() => setStep("confirm")}
                className="flex-1"
              >
                Proceed to Payment
              </Button>
            </div>
          </div>
        )}

        {/* Confirm Step */}
        {step === "confirm" && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Confirm & Pay</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-green-900">Booking Details Confirmed</p>
                      <p className="text-sm text-green-700 mt-1">Your test is scheduled for {selectedDate.toDateString()} at {selectedSlot}</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-foreground">Test Details</h4>
                  <div className="text-sm space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{test.name}</span>
                      <span>₹{test.price}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Collection Type</span>
                      <span>{collectionType === "home" ? "Home (+₹50)" : "Lab (Free)"}</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between font-bold">
                      <span>Total Amount</span>
                      <span>₹{totalPrice}</span>
                    </div>
                  </div>
                </div>

                <Button 
                  onClick={handleConfirmPayment}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  Confirm & Pay ₹{totalPrice}
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  )
}
