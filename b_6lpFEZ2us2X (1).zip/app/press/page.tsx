import Link from "next/link"
import { ArrowLeft, Newspaper, Megaphone, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata = {
  title: "Press - CAREVIA",
  description: "Latest news and press releases from CAREVIA",
}

const pressReleases = [
  {
    id: 1,
    title: "CAREVIA Announces $50 Million Series B Funding",
    date: "March 20, 2024",
    excerpt: "CAREVIA secures $50 million in Series B funding to expand healthcare services across India.",
    content: "Healthcare platform CAREVIA has announced the successful closure of its Series B funding round, raising $50 million from leading venture capital firms. The funds will be utilized to expand operations, enhance technology infrastructure, and bring healthcare services to more users across India.",
  },
  {
    id: 2,
    title: "CAREVIA Partners with 500+ Hospitals Nationwide",
    date: "March 10, 2024",
    excerpt: "Strategic partnership reaches milestone of 500 hospitals joining the CAREVIA network.",
    content: "CAREVIA proudly announces that it has successfully onboarded 500+ hospitals across India onto its integrated healthcare platform. This partnership enables seamless appointment booking, lab test referrals, and medical record management for millions of patients.",
  },
  {
    id: 3,
    title: "Launching Video Consultation Service for Remote Areas",
    date: "February 28, 2024",
    excerpt: "New telemedicine feature brings specialist consultations to underserved regions.",
    content: "In a significant step towards democratizing healthcare access, CAREVIA launches its advanced video consultation platform. This service enables patients in remote areas to connect with top specialists from major metros without traveling.",
  },
  {
    id: 4,
    title: "CAREVIA Wins Healthcare Innovation Award 2024",
    date: "February 15, 2024",
    excerpt: "Platform recognized for transforming healthcare delivery in India.",
    content: "CAREVIA has been awarded the prestigious Healthcare Innovation Award 2024 by the Indian Medical Association for its groundbreaking work in digital health transformation and making quality healthcare accessible to all Indians.",
  },
]

const mediaKit = [
  { name: "Company Logo", size: "5 MB" },
  { name: "Brand Guidelines", size: "3.2 MB" },
  { name: "Founder Photos", size: "8.5 MB" },
  { name: "Product Screenshots", size: "12 MB" },
]

export default function PressPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center px-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
        </div>
      </header>

      <main className="container max-w-6xl py-12">
        {/* Hero Section */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">Press Center</h1>
          <p className="text-lg text-muted-foreground max-w-2xl">
            Latest news, press releases, and media resources from CAREVIA. Stay updated on our latest announcements and achievements.
          </p>
        </div>

        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {/* Press Releases */}
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold mb-6">Latest Press Releases</h2>
            <div className="space-y-4">
              {pressReleases.map((release) => (
                <Card key={release.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <div className="flex items-start gap-3">
                      <Newspaper className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                      <div className="flex-1">
                        <CardTitle className="text-lg">{release.title}</CardTitle>
                        <p className="text-sm text-muted-foreground mt-1">{release.date}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground">{release.excerpt}</p>
                    <Button variant="outline" size="sm">
                      Read More
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Media Kit */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Megaphone className="h-5 w-5" />
                  Media Kit
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {mediaKit.map((item) => (
                  <a
                    key={item.name}
                    href="#"
                    className="flex items-center justify-between p-2 rounded hover:bg-secondary/30 transition-colors text-sm"
                  >
                    <span>{item.name}</span>
                    <span className="text-xs text-muted-foreground">{item.size}</span>
                  </a>
                ))}
              </CardContent>
            </Card>

            {/* Press Contact */}
            <Card>
              <CardHeader>
                <CardTitle>Press Contact</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>
                  <p className="font-medium">Priya Sharma</p>
                  <p className="text-muted-foreground">PR Manager</p>
                </div>
                <a href="mailto:press@carevia.com" className="text-primary hover:underline">
                  press@carevia.com
                </a>
                <a href="tel:+91-9876543210" className="text-primary hover:underline block">
                  +91-9876-543-210
                </a>
              </CardContent>
            </Card>

            {/* Newsletter */}
            <Card>
              <CardHeader>
                <CardTitle>Subscribe to Updates</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Get the latest news delivered to your inbox.
                </p>
                <Button className="w-full" size="sm">
                  Subscribe
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Company Info */}
        <div className="p-8 bg-secondary/30 rounded-xl">
          <h2 className="text-2xl font-bold mb-6">About CAREVIA</h2>
          <p className="text-muted-foreground mb-4">
            CAREVIA is India's leading healthcare platform that brings quality healthcare to every Indian. Founded in 2020, we have connected millions of patients with top doctors, hospitals, and health services across the country.
          </p>
          <p className="text-muted-foreground">
            Our mission is to democratize healthcare access and make quality medical services affordable and accessible to all. Through our innovative platform, we enable patients to find doctors, book appointments, order medicines, and access lab tests - all from the comfort of their homes.
          </p>
        </div>
      </main>
    </div>
  )
}
