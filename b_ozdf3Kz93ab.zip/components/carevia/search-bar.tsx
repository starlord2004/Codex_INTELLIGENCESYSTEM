"use client"

import { useState } from "react"
import { Search, Stethoscope, Building2, Hospital, Sparkles } from "lucide-react"
import { Input } from "@/components/ui/input"

const searchSuggestions = [
  { icon: Stethoscope, text: "Cardiologist", type: "Specialty" },
  { icon: Building2, text: "Apollo Hospital", type: "Hospital" },
  { icon: Stethoscope, text: "Dr. Sharma", type: "Doctor" },
  { icon: Hospital, text: "City Care Clinic", type: "Clinic" },
  { icon: Stethoscope, text: "Dermatologist", type: "Specialty" },
  { icon: Building2, text: "Fortis Healthcare", type: "Hospital" },
]

export function SearchBar() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isFocused, setIsFocused] = useState(false)

  const filteredSuggestions = searchQuery
    ? searchSuggestions.filter((s) =>
        s.text.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : searchSuggestions

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="relative">
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search doctors, clinics, hospitals, specialities..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setTimeout(() => setIsFocused(false), 200)}
            className="w-full h-14 pl-12 pr-4 text-base rounded-xl border-2 border-border bg-card shadow-sm focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2">
            <kbd className="hidden sm:inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-muted-foreground bg-muted rounded">
              <Sparkles className="h-3 w-3" />
              AI Powered
            </kbd>
          </div>
        </div>

        {/* Search Suggestions Dropdown */}
        {isFocused && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-card border border-border rounded-xl shadow-lg overflow-hidden z-50">
            <div className="p-2">
              <p className="px-3 py-2 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                {searchQuery ? "Search Results" : "Popular Searches"}
              </p>
              {filteredSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  className="w-full flex items-center gap-3 px-3 py-2.5 text-left hover:bg-secondary rounded-lg transition-colors"
                  onClick={() => setSearchQuery(suggestion.text)}
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                    <suggestion.icon className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{suggestion.text}</p>
                    <p className="text-xs text-muted-foreground">{suggestion.type}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
