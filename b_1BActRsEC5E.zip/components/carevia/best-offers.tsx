"use client"

import { useState } from "react"
import { Tag, Clock, Percent, Gift, ArrowRight, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

const offers = [
  {
    id: 1,
    title: "First Consultation FREE",
    description: "Get your first doctor consultation absolutely free for new users",
    code: "FIRST100",
    discount: "100% OFF",
    validTill: "31 Dec 2026",
    color: "from-blue-500 to-blue-600",
    icon: Gift,
  },
  {
    id: 2,
    title: "Lab Tests at Home",
    description: "Flat 30% off on all lab tests with free home sample collection",
    code: "LAB30",
    discount: "30% OFF",
    validTill: "15 Jan 2027",
    color: "from-emerald-500 to-emerald-600",
    icon: Percent,
  },
  {
    id: 3,
    title: "Medicine Delivery",
    description: "Get 25% off on all medicines with same day delivery",
    code: "MED25",
    discount: "25% OFF",
    validTill: "28 Feb 2027",
    color: "from-amber-500 to-amber-600",
    icon: Tag,
  },
  {
    id: 4,
    title: "Health Checkup Package",
    description: "Complete health checkup with 50+ tests at unbeatable prices",
    code: "HEALTH50",
    discount: "40% OFF",
    validTill: "31 Mar 2027",
    color: "from-rose-500 to-rose-600",
    icon: Clock,
  },
]

export function BestOffers() {
  const [isModalOpen, setIsModalOpen] = useState(false)

  return (
    <section className="w-full">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-foreground">
            Best Offers
          </h2>
          <p className="mt-1 text-muted-foreground">
            Exclusive deals on healthcare services
          </p>
        </div>
        <Button 
          variant="ghost" 
          className="hidden sm:flex items-center gap-1 text-primary hover:text-primary/80"
          onClick={() => setIsModalOpen(true)}
        >
          View All
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {offers.map((offer) => (
          <Card 
            key={offer.id} 
            className="overflow-hidden border-0 shadow-md hover:shadow-lg transition-shadow"
          >
            <div className={`bg-gradient-to-r ${offer.color} p-4`}>
              <div className="flex items-center justify-between">
                <offer.icon className="h-8 w-8 text-white/90" />
                <span className="text-lg font-bold text-white">
                  {offer.discount}
                </span>
              </div>
            </div>
            <CardContent className="p-4">
              <h3 className="font-semibold text-foreground line-clamp-1">
                {offer.title}
              </h3>
              <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
                {offer.description}
              </p>
              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-1 text-xs font-mono font-medium bg-secondary text-secondary-foreground rounded">
                    {offer.code}
                  </span>
                </div>
                <span className="text-xs text-muted-foreground">
                  Till {offer.validTill}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex justify-center mt-6 sm:hidden">
        <Button 
          variant="outline" 
          className="flex items-center gap-1"
          onClick={() => setIsModalOpen(true)}
        >
          View All Offers
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Modal for all offers */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>All Offers</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
            {offers.map((offer) => (
              <Card 
                key={offer.id} 
                className="overflow-hidden border-0 shadow-md hover:shadow-lg transition-shadow"
              >
                <div className={`bg-gradient-to-r ${offer.color} p-4`}>
                  <div className="flex items-center justify-between">
                    <offer.icon className="h-8 w-8 text-white/90" />
                    <span className="text-lg font-bold text-white">
                      {offer.discount}
                    </span>
                  </div>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-foreground">
                    {offer.title}
                  </h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {offer.description}
                  </p>
                  <div className="mt-4 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-1 text-xs font-mono font-medium bg-secondary text-secondary-foreground rounded">
                        {offer.code}
                      </span>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      Till {offer.validTill}
                    </span>
                  </div>
                  <Button className="w-full mt-4" size="sm">
                    Use Code
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </section>
  )
}
