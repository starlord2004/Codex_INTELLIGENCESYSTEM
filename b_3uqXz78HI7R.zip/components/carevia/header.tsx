"use client"

import { useState } from "react"
import { ChevronDown, Menu, X, User, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from "@/components/ui/dropdown-menu"

// Location data structure for India
const locationData: Record<string, string[]> = {
  "Mumbai": ["Andheri", "Bandra", "Borivali", "Colaba", "Dadar", "Goregaon", "Juhu", "Kandivali", "Malad", "Powai"],
  "Delhi": ["Connaught Place", "Dwarka", "Karol Bagh", "Lajpat Nagar", "Nehru Place", "Rohini", "Saket", "Vasant Kunj"],
  "Bangalore": ["Indiranagar", "Koramangala", "HSR Layout", "Whitefield", "Electronic City", "Jayanagar", "MG Road", "Marathahalli"],
  "Chennai": ["Adyar", "Anna Nagar", "T. Nagar", "Velachery", "Porur", "Tambaram", "OMR", "Nungambakkam"],
  "Hyderabad": ["Banjara Hills", "Gachibowli", "Hitech City", "Jubilee Hills", "Kukatpally", "Madhapur", "Secunderabad"],
  "Kolkata": ["Park Street", "Salt Lake", "New Town", "Ballygunge", "Alipore", "Howrah", "Dum Dum"],
  "Pune": ["Kothrud", "Viman Nagar", "Hinjewadi", "Baner", "Koregaon Park", "Wakad", "Aundh"],
  "Ahmedabad": ["Navrangpura", "Satellite", "Prahlad Nagar", "Maninagar", "Vastrapur", "Bodakdev"],
  "Jaipur": ["Malviya Nagar", "Vaishali Nagar", "Mansarovar", "Raja Park", "C-Scheme", "Tonk Road"],
  "Lucknow": ["Gomti Nagar", "Hazratganj", "Aliganj", "Indira Nagar", "Mahanagar", "Alambagh"],
}

export function Header() {
  const [selectedCity, setSelectedCity] = useState("Mumbai")
  const [selectedArea, setSelectedArea] = useState("Andheri")
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const handleCitySelect = (city: string) => {
    setSelectedCity(city)
    setSelectedArea(locationData[city][0])
  }

  const handleAreaSelect = (area: string) => {
    setSelectedArea(area)
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <Heart className="h-5 w-5 text-primary-foreground" fill="currentColor" />
            </div>
            <span className="text-xl font-bold text-foreground">CAREVIA</span>
          </div>

          {/* Location Selector - Desktop */}
          <div className="hidden md:flex items-center">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-1 text-foreground hover:bg-secondary">
                  <span className="font-medium">{selectedCity}</span>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                {Object.keys(locationData).map((city) => (
                  <DropdownMenuSub key={city}>
                    <DropdownMenuSubTrigger 
                      className={selectedCity === city ? "bg-secondary" : ""}
                      onClick={() => handleCitySelect(city)}
                    >
                      {city}
                    </DropdownMenuSubTrigger>
                    <DropdownMenuSubContent className="w-48">
                      {locationData[city].map((area) => (
                        <DropdownMenuItem
                          key={area}
                          className={selectedArea === area && selectedCity === city ? "bg-secondary" : ""}
                          onClick={() => {
                            handleCitySelect(city)
                            handleAreaSelect(area)
                          }}
                        >
                          {area}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuSubContent>
                  </DropdownMenuSub>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <span className="mx-2 text-muted-foreground">/</span>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-1 text-foreground hover:bg-secondary">
                  <span className="font-medium">{selectedArea}</span>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-48">
                {locationData[selectedCity].map((area) => (
                  <DropdownMenuItem
                    key={area}
                    className={selectedArea === area ? "bg-secondary" : ""}
                    onClick={() => handleAreaSelect(area)}
                  >
                    {area}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Navigation Links - Desktop */}
          <nav className="hidden lg:flex items-center gap-6">
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Find Doctors
            </a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Video Consult
            </a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Medicines
            </a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Lab Tests
            </a>
          </nav>

          {/* Auth Buttons - Desktop */}
          <div className="hidden md:flex items-center gap-3">
            <Button variant="ghost" size="sm" className="text-foreground">
              Login
            </Button>
            <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
              <User className="h-4 w-4 mr-1" />
              Sign Up
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <Button 
            variant="ghost" 
            size="icon" 
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border py-4">
            {/* Mobile Location */}
            <div className="flex items-center gap-2 px-2 py-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="flex items-center gap-1">
                    {selectedCity} / {selectedArea}
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-56">
                  {Object.keys(locationData).map((city) => (
                    <DropdownMenuSub key={city}>
                      <DropdownMenuSubTrigger>{city}</DropdownMenuSubTrigger>
                      <DropdownMenuSubContent>
                        {locationData[city].map((area) => (
                          <DropdownMenuItem
                            key={area}
                            onClick={() => {
                              handleCitySelect(city)
                              handleAreaSelect(area)
                            }}
                          >
                            {area}
                          </DropdownMenuItem>
                        ))}
                      </DropdownMenuSubContent>
                    </DropdownMenuSub>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Mobile Nav Links */}
            <nav className="flex flex-col gap-1 mt-2">
              <a href="#" className="px-4 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-md">
                Find Doctors
              </a>
              <a href="#" className="px-4 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-md">
                Video Consult
              </a>
              <a href="#" className="px-4 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-md">
                Medicines
              </a>
              <a href="#" className="px-4 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-md">
                Lab Tests
              </a>
            </nav>

            {/* Mobile Auth */}
            <div className="flex items-center gap-2 mt-4 px-2">
              <Button variant="outline" size="sm" className="flex-1">
                Login
              </Button>
              <Button size="sm" className="flex-1 bg-primary text-primary-foreground">
                Sign Up
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
