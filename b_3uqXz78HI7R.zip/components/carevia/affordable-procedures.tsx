"use client"

import { useState } from "react"
import { 
  CircleDot,
  Scissors,
  Eye,
  Bone,
  Heart,
  Activity,
  Brain,
  Stethoscope,
  Baby,
  Smile,
  Ear,
  Pill,
  Syringe,
  Thermometer,
  Shield,
  Zap,
  Waves,
  Droplets,
  Wind,
  Moon,
  Plus,
  X,
  IndianRupee,
  HeartPulse,
  FlaskConical
} from "lucide-react"
import { Button } from "@/components/ui/button"

const procedures = [
  { icon: CircleDot, name: "Piles Treatment", price: "30,000" },
  { icon: Scissors, name: "General Surgery", price: "45,000" },
  { icon: Eye, name: "Lasik Eye Surgery", price: "25,000" },
  // Hidden initially
  { icon: Bone, name: "Knee Replacement", price: "1,50,000" },
  { icon: Heart, name: "Angioplasty", price: "2,00,000" },
  { icon: Activity, name: "Hysterectomy", price: "60,000" },
  { icon: Brain, name: "Brain Surgery", price: "3,00,000" },
  { icon: Stethoscope, name: "Appendix Surgery", price: "35,000" },
  { icon: Baby, name: "C-Section Delivery", price: "50,000" },
  { icon: Smile, name: "Dental Implants", price: "25,000" },
  { icon: Ear, name: "Cochlear Implant", price: "5,00,000" },
  { icon: Pill, name: "Gallbladder Surgery", price: "40,000" },
  { icon: Syringe, name: "Hernia Surgery", price: "45,000" },
  { icon: Thermometer, name: "Thyroid Surgery", price: "55,000" },
  { icon: Shield, name: "Prostate Surgery", price: "70,000" },
  { icon: Zap, name: "Kidney Stone Removal", price: "35,000" },
  { icon: Waves, name: "Varicose Veins", price: "50,000" },
  { icon: Droplets, name: "Dialysis Setup", price: "20,000" },
  { icon: Wind, name: "Sinus Surgery", price: "30,000" },
  { icon: Moon, name: "Sleep Apnea Surgery", price: "80,000" },
  { icon: Wind, name: "Lung Surgery", price: "2,50,000" },
  { icon: Droplets, name: "Kidney Transplant", price: "5,00,000" },
  { icon: HeartPulse, name: "Bypass Surgery", price: "3,50,000" },
  { icon: FlaskConical, name: "Chemotherapy", price: "1,00,000" },
  { icon: Eye, name: "Cataract Surgery", price: "20,000" },
  { icon: Bone, name: "Hip Replacement", price: "2,00,000" },
  { icon: Smile, name: "Root Canal", price: "5,000" },
  { icon: Activity, name: "Fibroid Removal", price: "55,000" },
  { icon: Brain, name: "Spine Surgery", price: "2,50,000" },
  { icon: Ear, name: "Tympanoplasty", price: "40,000" },
  { icon: Shield, name: "Circumcision", price: "15,000" },
  { icon: CircleDot, name: "Fistula Surgery", price: "35,000" },
  { icon: Scissors, name: "Lipoma Removal", price: "20,000" },
  { icon: Thermometer, name: "Tonsillectomy", price: "25,000" },
  { icon: Zap, name: "Lithotripsy", price: "30,000" },
  { icon: Waves, name: "Sclerotherapy", price: "25,000" },
  { icon: Baby, name: "IVF Treatment", price: "1,50,000" },
  { icon: Heart, name: "Pacemaker Implant", price: "3,00,000" },
  { icon: Bone, name: "ACL Reconstruction", price: "1,20,000" },
  { icon: Eye, name: "Glaucoma Surgery", price: "35,000" },
  { icon: Smile, name: "Teeth Whitening", price: "8,000" },
  { icon: Activity, name: "Ovarian Cyst Removal", price: "45,000" },
  { icon: Brain, name: "Tumor Removal", price: "2,00,000" },
  { icon: Pill, name: "Bariatric Surgery", price: "2,50,000" },
  { icon: Syringe, name: "Botox Treatment", price: "15,000" },
  { icon: Shield, name: "Vasectomy", price: "10,000" },
  { icon: Wind, name: "Bronchoscopy", price: "20,000" },
  { icon: HeartPulse, name: "Aneurysm Repair", price: "4,00,000" },
  { icon: Droplets, name: "Nephrectomy", price: "1,50,000" },
  { icon: FlaskConical, name: "Biopsy", price: "10,000" },
  { icon: Ear, name: "Stapedectomy", price: "50,000" },
  { icon: Droplets, name: "Varicocele Surgery", price: "40,000" },
  { icon: Wind, name: "Septoplasty", price: "35,000" },
]

export function AffordableProcedures() {
  const [showAll, setShowAll] = useState(false)
  const [selectedProcedure, setSelectedProcedure] = useState<string | null>(null)
  
  const visibleProcedures = showAll ? procedures : procedures.slice(0, 3)
  const hiddenCount = procedures.length - 3

  const handleGetEstimate = (procedureName: string) => {
    setSelectedProcedure(selectedProcedure === procedureName ? null : procedureName)
  }

  return (
    <section className="w-full">
      <div className="text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-bold text-foreground">
          Affordable Procedures by Expert Doctors
        </h2>
        <p className="mt-2 text-muted-foreground">
          Quality healthcare at transparent prices
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {visibleProcedures.map((procedure) => (
          <div
            key={procedure.name}
            className="group flex flex-col items-start p-4 bg-card rounded-xl border border-border hover:border-primary/50 hover:shadow-md transition-all duration-200"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 mb-3 group-hover:bg-primary/20 transition-colors">
              <procedure.icon className="h-5 w-5 text-primary" />
            </div>
            <span className="text-sm font-medium text-foreground line-clamp-2 mb-3">
              {procedure.name}
            </span>
            
            {selectedProcedure === procedure.name ? (
              <div className="w-full space-y-2">
                <div className="flex items-center gap-1 p-2 bg-primary/5 rounded-lg">
                  <span className="text-xs text-muted-foreground">Starting from</span>
                  <span className="text-base font-bold text-primary flex items-center">
                    <IndianRupee className="h-4 w-4" />
                    {procedure.price}
                  </span>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full text-xs"
                  onClick={() => handleGetEstimate(procedure.name)}
                >
                  Hide Price
                </Button>
              </div>
            ) : (
              <Button
                size="sm"
                className="w-full mt-auto text-xs gap-1"
                onClick={() => handleGetEstimate(procedure.name)}
              >
                <IndianRupee className="h-3 w-3" />
                Get Cost Estimate
              </Button>
            )}
          </div>
        ))}
        
        {!showAll && (
          <button
            onClick={() => setShowAll(true)}
            className="group flex flex-col items-center justify-center p-4 bg-primary/5 rounded-xl border-2 border-dashed border-primary/30 hover:border-primary hover:bg-primary/10 transition-all duration-200 min-h-[160px]"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 mb-3 group-hover:bg-primary/20 transition-colors">
              <Plus className="h-5 w-5 text-primary" />
            </div>
            <span className="text-sm font-semibold text-primary">
              +{hiddenCount} More Procedures
            </span>
          </button>
        )}
      </div>

      {showAll && (
        <div className="flex justify-center mt-6">
          <Button
            variant="outline"
            onClick={() => setShowAll(false)}
            className="gap-2"
          >
            <X className="h-4 w-4" />
            Show Less
          </Button>
        </div>
      )}
    </section>
  )
}
