"use client"

import { useRouter } from "next/navigation"
import { 
  Thermometer,
  Sparkles,
  HeartPulse,
  Brain,
  Wind,
  Droplets,
  Zap,
  Activity,
  Eye,
  Pill,
  Baby,
  Smile
} from "lucide-react"
import { Button } from "@/components/ui/button"

const conditions = [
  { icon: Thermometer, name: "Fever", slug: "fever", color: "bg-red-100 text-red-600" },
  { icon: Sparkles, name: "Acne", slug: "acne", color: "bg-purple-100 text-purple-600" },
  { icon: Wind, name: "Cough", slug: "cough", color: "bg-slate-100 text-slate-600" },
  { icon: Brain, name: "Headache", slug: "headache", color: "bg-indigo-100 text-indigo-600" },
  { icon: Activity, name: "Joint Pain", slug: "joint-pain", color: "bg-orange-100 text-orange-600" },
  { icon: Droplets, name: "Allergies", slug: "allergies", color: "bg-cyan-100 text-cyan-600" },
  { icon: Zap, name: "Fatigue", slug: "fatigue", color: "bg-yellow-100 text-yellow-600" },
  { icon: HeartPulse, name: "Heart Issues", slug: "heart-issues", color: "bg-rose-100 text-rose-600" },
]

export function PopularConditions() {
  const router = useRouter()

  const handleConditionClick = (slug: string) => {
    router.push(`/doctors?condition=${slug}`)
  }

  return (
    <section className="w-full">
      <div className="text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-bold text-foreground">
          Popular Health Searches
        </h2>
        <p className="mt-2 text-muted-foreground">
          Find doctors for common health concerns
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        {conditions.map((condition) => (
          <button
            key={condition.slug}
            onClick={() => handleConditionClick(condition.slug)}
            className="group flex flex-col items-center p-4 bg-card rounded-lg border border-border hover:border-primary/50 hover:shadow-md transition-all duration-200 cursor-pointer"
          >
            <div className={`flex h-10 w-10 items-center justify-center rounded-full ${condition.color} mb-2 group-hover:scale-110 transition-transform`}>
              <condition.icon className="h-5 w-5" />
            </div>
            <span className="text-sm font-medium text-foreground text-center">
              {condition.name}
            </span>
          </button>
        ))}
      </div>
    </section>
  )
}
