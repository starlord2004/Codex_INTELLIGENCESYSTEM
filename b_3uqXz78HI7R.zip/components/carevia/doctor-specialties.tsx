"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { 
  Eye, 
  Baby, 
  Sparkles, 
  Brain, 
  Bone, 
  Heart, 
  Stethoscope,
  Activity,
  Smile,
  Ear,
  Pill,
  Syringe,
  Shield,
  Zap,
  Thermometer,
  Wind,
  Moon,
  Waves,
  Droplets,
  CircleDot,
  Scissors,
  FlaskConical,
  HeartPulse,
  Plus,
  X
} from "lucide-react"
import { Button } from "@/components/ui/button"

const specialties = [
  { icon: Heart, name: "Cardiologist", color: "bg-red-100 text-red-600", slug: "cardiologist" },
  { icon: Sparkles, name: "Dermatologist", color: "bg-purple-100 text-purple-600", slug: "dermatologist" },
  { icon: Stethoscope, name: "General Physician", color: "bg-emerald-100 text-emerald-600", slug: "general-physician" },
  { icon: Brain, name: "Neurologist", color: "bg-indigo-100 text-indigo-600", slug: "neurologist" },
  { icon: Baby, name: "Pediatrician", color: "bg-pink-100 text-pink-600", slug: "pediatrician" },
  { icon: Eye, name: "Eye Specialist", color: "bg-blue-100 text-blue-600", slug: "eye-specialist" },
  { icon: Bone, name: "Orthopedic", color: "bg-amber-100 text-amber-600", slug: "orthopedic" },
  { icon: Ear, name: "ENT Specialist", color: "bg-teal-100 text-teal-600", slug: "ent-specialist" },
  // Below are hidden initially
  { icon: Wind, name: "Pulmonologist", color: "bg-slate-100 text-slate-600", slug: "pulmonologist" },
  { icon: Smile, name: "Dentist", color: "bg-cyan-100 text-cyan-600", slug: "dentist" },
  { icon: Pill, name: "Gastroenterologist", color: "bg-orange-100 text-orange-600", slug: "gastroenterologist" },
  { icon: Syringe, name: "Diabetologist", color: "bg-lime-100 text-lime-600", slug: "diabetologist" },
  { icon: Shield, name: "Urologist", color: "bg-sky-100 text-sky-600", slug: "urologist" },
  { icon: Zap, name: "Psychiatrist", color: "bg-violet-100 text-violet-600", slug: "psychiatrist" },
  { icon: Thermometer, name: "Infectious Disease", color: "bg-red-100 text-red-600", slug: "infectious-disease" },
  { icon: Moon, name: "Sleep Specialist", color: "bg-indigo-100 text-indigo-600", slug: "sleep-specialist" },
  { icon: Waves, name: "Rheumatologist", color: "bg-blue-100 text-blue-600", slug: "rheumatologist" },
  { icon: Droplets, name: "Nephrologist", color: "bg-cyan-100 text-cyan-600", slug: "nephrologist" },
  { icon: CircleDot, name: "Proctologist", color: "bg-amber-100 text-amber-600", slug: "proctologist" },
  { icon: Scissors, name: "Plastic Surgeon", color: "bg-pink-100 text-pink-600", slug: "plastic-surgeon" },
  { icon: FlaskConical, name: "Oncologist", color: "bg-purple-100 text-purple-600", slug: "oncologist" },
  { icon: HeartPulse, name: "Vascular Surgeon", color: "bg-rose-100 text-rose-600", slug: "vascular-surgeon" },
  { icon: Stethoscope, name: "Internal Medicine", color: "bg-blue-100 text-blue-600", slug: "internal-medicine" },
  { icon: Baby, name: "Neonatologist", color: "bg-pink-100 text-pink-600", slug: "neonatologist" },
  { icon: Brain, name: "Neurosurgeon", color: "bg-indigo-100 text-indigo-600", slug: "neurosurgeon" },
]

export function DoctorSpecialties() {
  const [showAll, setShowAll] = useState(false)
  const router = useRouter()
  
  const visibleSpecialties = showAll ? specialties : specialties.slice(0, 8)
  const hiddenCount = specialties.length - 8

  const handleSpecialtyClick = (slug: string) => {
    router.push(`/doctors?specialty=${slug}`)
  }

  return (
    <section className="w-full">
      <div className="text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-bold text-foreground">
          Find a Doctor for Your Health Problem
        </h2>
        <p className="mt-2 text-muted-foreground">
          Consult with top specialists in your area
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {visibleSpecialties.map((specialty) => (
          <button
            key={specialty.name}
            onClick={() => handleSpecialtyClick(specialty.slug)}
            className="group flex flex-col items-center p-4 bg-card rounded-xl border border-border hover:border-primary/50 hover:shadow-md transition-all duration-200 cursor-pointer"
          >
            <div className={`flex h-12 w-12 items-center justify-center rounded-full ${specialty.color} mb-3 group-hover:scale-110 transition-transform`}>
              <specialty.icon className="h-6 w-6" />
            </div>
            <span className="text-sm font-medium text-foreground text-center">
              {specialty.name}
            </span>
          </button>
        ))}
        
        {!showAll && (
          <button
            onClick={() => setShowAll(true)}
            className="group flex flex-col items-center justify-center p-4 bg-primary/5 rounded-xl border-2 border-dashed border-primary/30 hover:border-primary hover:bg-primary/10 transition-all duration-200"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 mb-3 group-hover:bg-primary/20 transition-colors">
              <Plus className="h-6 w-6 text-primary" />
            </div>
            <span className="text-sm font-semibold text-primary">
              +{hiddenCount} More
            </span>
          </button>
        )}
      </div>

      {showAll && (
        <div className="flex justify-center mt-6">
          <Button
            variant="outline"
            onClick={() => setShowAll(false)}
            className="gap-2"
          >
            <X className="h-4 w-4" />
            Show Less
          </Button>
        </div>
      )}
    </section>
  )
}
