"use client"

import Link from "next/link"
import { CalendarCheck, Pill, FlaskConical, Scissors } from "lucide-react"

const services = [
  {
    icon: CalendarCheck,
    title: "Physical Appointment",
    description: "Book in-person doctor visits",
    color: "bg-blue-500",
    hoverColor: "hover:bg-blue-600",
    href: "/appointment",
  },
  {
    icon: Pill,
    title: "Medicines",
    description: "Order medicines online",
    color: "bg-emerald-500",
    hoverColor: "hover:bg-emerald-600",
    href: "/medicines",
  },
  {
    icon: FlaskConical,
    title: "Lab Tests",
    description: "Book diagnostic tests",
    color: "bg-amber-500",
    hoverColor: "hover:bg-amber-600",
    href: "/lab-tests",
  },
  {
    icon: Scissors,
    title: "Surgeries",
    description: "Plan surgical procedures",
    color: "bg-rose-500",
    hoverColor: "hover:bg-rose-600",
    href: "/surgeries",
  },
]

export function ServiceButtons() {
  return (
    <section className="w-full">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {services.map((service) => (
          <Link
            key={service.title}
            href={service.href}
            className="group relative flex flex-col items-center p-6 bg-card rounded-2xl border border-border shadow-sm hover:shadow-md transition-all duration-200 hover:-translate-y-1"
          >
            <div className={`flex h-14 w-14 items-center justify-center rounded-xl ${service.color} ${service.hoverColor} transition-colors mb-4`}>
              <service.icon className="h-7 w-7 text-white" />
            </div>
            <h3 className="text-base font-semibold text-foreground text-center">
              {service.title}
            </h3>
            <p className="mt-1 text-sm text-muted-foreground text-center">
              {service.description}
            </p>
          </Link>
        ))}
      </div>
    </section>
  )
}
