import { 
  Header, 
  SearchBar, 
  ServiceButtons, 
  DoctorSpecialties, 
  PopularConditions,
  AffordableProcedures, 
  HealthPackages,
  BestOffers, 
  Footer 
} from "@/components/carevia"

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header with Location Selector */}
      <Header />

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Section with Search */}
        <section className="bg-gradient-to-b from-primary/5 to-background py-12 md:py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground text-balance">
                Your Health, Our Priority
              </h1>
              <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
                Find the best doctors, book appointments, order medicines, and get lab tests - all from the comfort of your home.
              </p>
            </div>

            {/* Search Bar */}
            <SearchBar />
          </div>
        </section>

        {/* Service Buttons Section */}
        <section className="py-10 md:py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <ServiceButtons />
          </div>
        </section>

        {/* Doctor Specialties Section */}
        <section className="py-10 md:py-12 bg-secondary/30">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <DoctorSpecialties />
          </div>
        </section>

        {/* Popular Health Conditions Section */}
        <section className="py-10 md:py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <PopularConditions />
          </div>
        </section>

        {/* Affordable Procedures Section */}
        <section className="py-10 md:py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <AffordableProcedures />
          </div>
        </section>

        {/* Health Packages Section */}
        <section className="py-10 md:py-12 bg-secondary/30">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <HealthPackages />
          </div>
        </section>

        {/* Best Offers Section */}
        <section className="py-10 md:py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <BestOffers />
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  )
}
