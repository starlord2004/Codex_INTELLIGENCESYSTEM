"use client"

import { use } from "react"
import { useRouter } from "next/navigation"
import { 
  ArrowLeft,
  Star,
  ThumbsUp,
  MapPin,
  Clock,
  Verified,
  Phone,
  Globe,
  ChevronRight,
  Building2,
  Users,
  Bed,
  Award,
  Ambulance
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

// Mock hospital data
const hospitalsData: Record<string, {
  id: string
  name: string
  type: string
  address: string
  phone: string
  website: string
  rating: number
  totalRatings: number
  beds: number
  established: number
  accreditations: string[]
  specialties: string[]
  facilities: string[]
  emergencyServices: boolean
  doctors: {
    id: string
    name: string
    designation: string
    department: string
    experience: number
    rating: number
    recommendation: number
    consultationFee: number
    availableToday: boolean
    nextSlot: string
    verified: boolean
  }[]
}> = {
  "apollo-hospital": {
    id: "apollo-hospital",
    name: "Apollo Hospital",
    type: "Multi-Specialty Hospital",
    address: "154, Bannerghatta Road, Bangalore - 560076",
    phone: "+91 80 2630 4050",
    website: "www.apollohospitals.com",
    rating: 4.7,
    totalRatings: 15420,
    beds: 350,
    established: 1995,
    accreditations: ["NABH", "JCI", "NABL"],
    specialties: ["Cardiology", "Oncology", "Neurology", "Orthopedics", "Gastroenterology", "Nephrology"],
    facilities: ["24/7 Emergency", "ICU", "NICU", "Blood Bank", "Pharmacy", "Cafeteria", "Parking"],
    emergencyServices: true,
    doctors: [
      {
        id: "dr-rajesh-kumar",
        name: "Dr. Rajesh Kumar",
        designation: "Senior Consultant",
        department: "Cardiology",
        experience: 15,
        rating: 4.8,
        recommendation: 98,
        consultationFee: 500,
        availableToday: true,
        nextSlot: "10:30 AM",
        verified: true
      },
      {
        id: "dr-priya-sharma",
        name: "Dr. Priya Sharma",
        designation: "Consultant",
        department: "Cardiology",
        experience: 12,
        rating: 4.9,
        recommendation: 99,
        consultationFee: 600,
        availableToday: true,
        nextSlot: "11:00 AM",
        verified: true
      },
      {
        id: "dr-anil-mehta",
        name: "Dr. Anil Mehta",
        designation: "HOD - Cardiology",
        department: "Cardiology",
        experience: 20,
        rating: 4.7,
        recommendation: 96,
        consultationFee: 800,
        availableToday: false,
        nextSlot: "Tomorrow 9:00 AM",
        verified: true
      },
      {
        id: "dr-neha-gupta",
        name: "Dr. Neha Gupta",
        designation: "Senior Consultant",
        department: "Neurology",
        experience: 14,
        rating: 4.8,
        recommendation: 97,
        consultationFee: 700,
        availableToday: true,
        nextSlot: "2:00 PM",
        verified: true
      },
      {
        id: "dr-sanjay-patel",
        name: "Dr. Sanjay Patel",
        designation: "Consultant",
        department: "Orthopedics",
        experience: 10,
        rating: 4.6,
        recommendation: 94,
        consultationFee: 550,
        availableToday: true,
        nextSlot: "3:30 PM",
        verified: true
      }
    ]
  },
  "fortis-healthcare": {
    id: "fortis-healthcare",
    name: "Fortis Hospital",
    type: "Multi-Specialty Hospital",
    address: "14, Cunningham Road, Bangalore - 560052",
    phone: "+91 80 6621 4444",
    website: "www.fortishealthcare.com",
    rating: 4.6,
    totalRatings: 12350,
    beds: 280,
    established: 2001,
    accreditations: ["NABH", "JCI"],
    specialties: ["Cardiac Sciences", "Oncology", "Neurosciences", "Renal Sciences", "Bone & Joint"],
    facilities: ["24/7 Emergency", "ICU", "PICU", "Blood Bank", "Diagnostic Center", "Pharmacy"],
    emergencyServices: true,
    doctors: [
      {
        id: "dr-vikram-singh",
        name: "Dr. Vikram Singh",
        designation: "Senior Consultant",
        department: "Dermatology",
        experience: 10,
        rating: 4.8,
        recommendation: 97,
        consultationFee: 450,
        availableToday: true,
        nextSlot: "12:00 PM",
        verified: true
      },
      {
        id: "dr-anita-desai",
        name: "Dr. Anita Desai",
        designation: "HOD - Oncology",
        department: "Oncology",
        experience: 18,
        rating: 4.9,
        recommendation: 98,
        consultationFee: 1000,
        availableToday: true,
        nextSlot: "10:00 AM",
        verified: true
      },
      {
        id: "dr-ramesh-iyer",
        name: "Dr. Ramesh Iyer",
        designation: "Consultant",
        department: "Nephrology",
        experience: 8,
        rating: 4.5,
        recommendation: 93,
        consultationFee: 600,
        availableToday: false,
        nextSlot: "Tomorrow 11:00 AM",
        verified: true
      }
    ]
  },
  "city-care-clinic": {
    id: "city-care-clinic",
    name: "City Care Clinic",
    type: "Multi-Specialty Clinic",
    address: "78, Koramangala 5th Block, Bangalore - 560034",
    phone: "+91 80 4567 8901",
    website: "www.citycareclinic.in",
    rating: 4.5,
    totalRatings: 3250,
    beds: 50,
    established: 2010,
    accreditations: ["NABH"],
    specialties: ["General Medicine", "Pediatrics", "Gynecology", "ENT", "Ophthalmology"],
    facilities: ["Minor OT", "Lab Services", "Pharmacy", "X-Ray", "Ultrasound"],
    emergencyServices: false,
    doctors: [
      {
        id: "dr-sharma",
        name: "Dr. Amit Sharma",
        designation: "Chief Consultant",
        department: "General Medicine",
        experience: 18,
        rating: 4.9,
        recommendation: 98,
        consultationFee: 500,
        availableToday: true,
        nextSlot: "9:30 AM",
        verified: true
      },
      {
        id: "dr-sunita-reddy",
        name: "Dr. Sunita Reddy",
        designation: "Consultant",
        department: "Cardiology",
        experience: 8,
        rating: 4.6,
        recommendation: 94,
        consultationFee: 400,
        availableToday: true,
        nextSlot: "2:30 PM",
        verified: true
      },
      {
        id: "dr-kavitha-nair",
        name: "Dr. Kavitha Nair",
        designation: "Senior Consultant",
        department: "Pediatrics",
        experience: 12,
        rating: 4.8,
        recommendation: 96,
        consultationFee: 450,
        availableToday: true,
        nextSlot: "4:00 PM",
        verified: true
      }
    ]
  }
}

export default function HospitalPage({ params }: { params: Promise<{ hospitalId: string }> }) {
  const resolvedParams = use(params)
  const router = useRouter()
  const hospital = hospitalsData[resolvedParams.hospitalId]

  if (!hospital) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Hospital not found</p>
          <Button onClick={() => router.push("/")}>Go to Home</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center gap-4 px-4">
          <button 
            onClick={() => router.back()}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <main className="container px-4 py-6 max-w-4xl mx-auto">
        {/* Hospital Header */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <Building2 className="h-10 w-10 text-primary" />
                </div>
              </div>
              <div className="flex-1">
                <h1 className="text-xl font-bold text-foreground">{hospital.name}</h1>
                <p className="text-sm text-muted-foreground">{hospital.type}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                  <span className="font-medium">{hospital.rating}</span>
                  <span className="text-xs text-muted-foreground">({hospital.totalRatings.toLocaleString()} reviews)</span>
                </div>
                <div className="flex flex-wrap gap-2 mt-3">
                  {hospital.accreditations.map((acc, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">{acc}</Badge>
                  ))}
                </div>
              </div>
            </div>

            <Separator className="my-4" />

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <Bed className="h-5 w-5 mx-auto text-primary mb-1" />
                <p className="text-lg font-bold text-foreground">{hospital.beds}</p>
                <p className="text-xs text-muted-foreground">Beds</p>
              </div>
              <div>
                <Users className="h-5 w-5 mx-auto text-primary mb-1" />
                <p className="text-lg font-bold text-foreground">{hospital.doctors.length}+</p>
                <p className="text-xs text-muted-foreground">Doctors</p>
              </div>
              <div>
                <Award className="h-5 w-5 mx-auto text-primary mb-1" />
                <p className="text-lg font-bold text-foreground">{new Date().getFullYear() - hospital.established}+</p>
                <p className="text-xs text-muted-foreground">Years</p>
              </div>
              <div>
                <Ambulance className="h-5 w-5 mx-auto text-primary mb-1" />
                <p className="text-lg font-bold text-foreground">{hospital.emergencyServices ? "24/7" : "No"}</p>
                <p className="text-xs text-muted-foreground">Emergency</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Info */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                <p className="text-sm text-muted-foreground">{hospital.address}</p>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-primary flex-shrink-0" />
                <p className="text-sm text-muted-foreground">{hospital.phone}</p>
              </div>
              <div className="flex items-center gap-3">
                <Globe className="h-5 w-5 text-primary flex-shrink-0" />
                <p className="text-sm text-muted-foreground">{hospital.website}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Specialties */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Specialties</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {hospital.specialties.map((specialty, index) => (
                <Badge key={index} variant="outline">{specialty}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Facilities */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Facilities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {hospital.facilities.map((facility, index) => (
                <Badge key={index} variant="secondary">{facility}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Doctors List */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-foreground mb-4">Doctors at {hospital.name}</h2>
          <p className="text-sm text-muted-foreground mb-4">{hospital.doctors.length} doctors available</p>
          
          <div className="space-y-4">
            {hospital.doctors.map((doctor) => (
              <Card key={doctor.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    {/* Doctor Image */}
                    <div className="flex-shrink-0">
                      <div className="w-16 h-16 md:w-20 md:h-20 rounded-xl bg-secondary flex items-center justify-center overflow-hidden">
                        <div className="w-full h-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                          <span className="text-xl font-bold text-primary">
                            {doctor.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Doctor Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-foreground">{doctor.name}</h3>
                        {doctor.verified && <Verified className="h-4 w-4 text-primary flex-shrink-0" />}
                      </div>
                      <p className="text-sm text-primary font-medium">{doctor.designation}</p>
                      <p className="text-sm text-muted-foreground">{doctor.department}</p>
                      <p className="text-sm text-muted-foreground">{doctor.experience} years experience</p>

                      {/* Rating & Recommendation */}
                      <div className="flex flex-wrap items-center gap-3 mt-2">
                        <div className="flex items-center gap-1">
                          <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                          <span className="text-sm font-medium">{doctor.rating}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <ThumbsUp className="h-3.5 w-3.5 text-emerald-500" />
                          <span className="text-sm font-medium text-emerald-600">{doctor.recommendation}%</span>
                        </div>
                      </div>

                      {/* Availability & Fee */}
                      <div className="flex flex-wrap items-center justify-between gap-3 mt-3 pt-3 border-t border-border">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-1.5">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            {doctor.availableToday ? (
                              <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
                                {doctor.nextSlot}
                              </Badge>
                            ) : (
                              <span className="text-sm text-muted-foreground">{doctor.nextSlot}</span>
                            )}
                          </div>
                          <div className="text-sm">
                            <span className="font-semibold text-foreground">Rs. {doctor.consultationFee}</span>
                          </div>
                        </div>

                        <Button 
                          size="sm"
                          onClick={() => router.push(`/doctors/${doctor.id}/book`)}
                          className="gap-1"
                        >
                          Book Visit
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
