"use client"

import { use } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { 
  ArrowLeft,
  Star,
  ThumbsUp,
  MapPin,
  Clock,
  Verified,
  GraduationCap,
  Award,
  Languages,
  Phone,
  MessageCircle,
  Building2,
  ChevronRight
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

// Mock doctor data
const doctorsData: Record<string, {
  id: string
  name: string
  specialty: string
  qualification: string
  experience: number
  rating: number
  totalRatings: number
  recommendation: number
  consultationFee: number
  about: string
  clinics: {
    name: string
    address: string
    timing: string
    phone: string
  }[]
  education: string[]
  awards: string[]
  languages: string[]
  services: string[]
  verified: boolean
}> = {
  "dr-sharma": {
    id: "dr-sharma",
    name: "Dr. Amit Sharma",
    specialty: "General Physician",
    qualification: "MBBS, MD (General Medicine)",
    experience: 18,
    rating: 4.9,
    totalRatings: 2450,
    recommendation: 98,
    consultationFee: 500,
    about: "Dr. Amit Sharma is a highly experienced General Physician with over 18 years of practice. He specializes in treating common illnesses, chronic disease management, preventive healthcare, and provides comprehensive health checkups. Known for his patient-centric approach and accurate diagnosis.",
    clinics: [
      {
        name: "Sharma Health Clinic",
        address: "45, Koramangala 4th Block, Bangalore - 560034",
        timing: "Mon-Sat: 9:00 AM - 1:00 PM, 5:00 PM - 9:00 PM",
        phone: "+91 98765 43210"
      },
      {
        name: "Apollo Clinic - Indiranagar",
        address: "12, 100 Feet Road, Indiranagar, Bangalore - 560038",
        timing: "Mon, Wed, Fri: 2:00 PM - 5:00 PM",
        phone: "+91 98765 43211"
      }
    ],
    education: [
      "MBBS - Bangalore Medical College, 2002",
      "MD (General Medicine) - AIIMS Delhi, 2006"
    ],
    awards: [
      "Best General Physician Award - Karnataka Medical Association, 2020",
      "Excellence in Patient Care - Apollo Hospitals, 2018"
    ],
    languages: ["English", "Hindi", "Kannada", "Telugu"],
    services: [
      "General Health Checkup",
      "Diabetes Management",
      "Hypertension Treatment",
      "Fever & Infections",
      "Preventive Healthcare",
      "Chronic Disease Management"
    ],
    verified: true
  },
  "dr-rajesh-kumar": {
    id: "dr-rajesh-kumar",
    name: "Dr. Rajesh Kumar",
    specialty: "Cardiologist",
    qualification: "MBBS, MD (Cardiology), DM",
    experience: 15,
    rating: 4.8,
    totalRatings: 1250,
    recommendation: 98,
    consultationFee: 500,
    about: "Dr. Rajesh Kumar is a renowned Cardiologist specializing in interventional cardiology and heart failure management. With 15 years of experience, he has performed over 5000 cardiac procedures including angioplasty and stenting.",
    clinics: [
      {
        name: "HeartCare Clinic",
        address: "123, MG Road, Bangalore - 560001",
        timing: "Mon-Sat: 10:00 AM - 2:00 PM, 6:00 PM - 9:00 PM",
        phone: "+91 98765 12345"
      }
    ],
    education: [
      "MBBS - JIPMER Puducherry, 2005",
      "MD (Cardiology) - AIIMS Delhi, 2009",
      "DM (Cardiology) - NIMHANS, 2012"
    ],
    awards: [
      "Best Interventional Cardiologist - IMA Karnataka, 2022",
      "Young Achiever Award - Cardiological Society of India, 2019"
    ],
    languages: ["English", "Hindi", "Kannada"],
    services: [
      "Angioplasty & Stenting",
      "Heart Failure Management",
      "Cardiac Checkup",
      "ECG & Echo",
      "Pacemaker Implantation",
      "Preventive Cardiology"
    ],
    verified: true
  },
  "dr-priya-sharma": {
    id: "dr-priya-sharma",
    name: "Dr. Priya Sharma",
    specialty: "Cardiologist",
    qualification: "MBBS, DNB (Cardiology)",
    experience: 12,
    rating: 4.9,
    totalRatings: 980,
    recommendation: 99,
    consultationFee: 600,
    about: "Dr. Priya Sharma is a skilled Cardiologist with expertise in non-invasive cardiology and women's heart health. She focuses on preventive care and lifestyle modifications for heart disease management.",
    clinics: [
      {
        name: "Apollo Heart Centre",
        address: "45, Indiranagar, Bangalore - 560038",
        timing: "Mon-Fri: 9:00 AM - 5:00 PM",
        phone: "+91 98765 67890"
      }
    ],
    education: [
      "MBBS - St. John's Medical College, 2008",
      "DNB (Cardiology) - Apollo Hospitals, 2013"
    ],
    awards: [
      "Women in Medicine Award - 2021",
      "Best Heart Specialist - Bangalore Health Awards, 2020"
    ],
    languages: ["English", "Hindi"],
    services: [
      "Women's Heart Health",
      "Preventive Cardiology",
      "Stress Testing",
      "Holter Monitoring",
      "Cardiac Rehabilitation"
    ],
    verified: true
  }
}

export default function DoctorProfilePage({ params }: { params: Promise<{ doctorId: string }> }) {
  const resolvedParams = use(params)
  const router = useRouter()
  const doctor = doctorsData[resolvedParams.doctorId]

  if (!doctor) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Doctor not found</p>
          <Button onClick={() => router.push("/doctors")}>View all doctors</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center gap-4 px-4">
          <button 
            onClick={() => router.back()}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <main className="container px-4 py-6 max-w-3xl mx-auto">
        {/* Doctor Header Card */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-24 h-24 rounded-2xl bg-secondary flex items-center justify-center overflow-hidden">
                  <div className="w-full h-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                    <span className="text-3xl font-bold text-primary">
                      {doctor.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h1 className="text-xl font-bold text-foreground">{doctor.name}</h1>
                  {doctor.verified && <Verified className="h-5 w-5 text-primary" />}
                </div>
                <p className="text-muted-foreground">{doctor.specialty}</p>
                <p className="text-sm text-muted-foreground">{doctor.qualification}</p>
                <div className="flex flex-wrap items-center gap-3 mt-3">
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                    <span className="font-medium">{doctor.rating}</span>
                    <span className="text-xs text-muted-foreground">({doctor.totalRatings} reviews)</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <ThumbsUp className="h-4 w-4 text-emerald-500" />
                    <span className="font-medium text-emerald-600">{doctor.recommendation}%</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">{doctor.experience} years experience</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Book Appointment CTA */}
        <Card className="mb-6 bg-primary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-foreground">Book In-Clinic Consultation</p>
                <p className="text-sm text-muted-foreground">Consultation Fee: Rs. {doctor.consultationFee}</p>
              </div>
              <Button onClick={() => router.push(`/doctors/${doctor.id}/book`)} className="gap-1">
                Book Now
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* About */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">About</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground leading-relaxed">{doctor.about}</p>
          </CardContent>
        </Card>

        {/* Clinic Locations */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              Clinic Locations
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {doctor.clinics.map((clinic, index) => (
              <div key={index} className={index > 0 ? "pt-4 border-t border-border" : ""}>
                <h4 className="font-medium text-foreground">{clinic.name}</h4>
                <div className="flex items-start gap-2 mt-2">
                  <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-muted-foreground">{clinic.address}</p>
                </div>
                <div className="flex items-start gap-2 mt-1">
                  <Clock className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-muted-foreground">{clinic.timing}</p>
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <Phone className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  <p className="text-sm text-muted-foreground">{clinic.phone}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Services */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">Services</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {doctor.services.map((service, index) => (
                <Badge key={index} variant="secondary">{service}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Education */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <GraduationCap className="h-5 w-5 text-primary" />
              Education
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {doctor.education.map((edu, index) => (
                <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                  {edu}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Awards */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Award className="h-5 w-5 text-primary" />
              Awards & Recognition
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {doctor.awards.map((award, index) => (
                <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 flex-shrink-0" />
                  {award}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Languages */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Languages className="h-5 w-5 text-primary" />
              Languages Spoken
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {doctor.languages.map((lang, index) => (
                <Badge key={index} variant="outline">{lang}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Fixed Bottom CTA */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-card border-t border-border">
          <div className="container max-w-3xl mx-auto flex gap-3">
            <Button variant="outline" className="flex-1 gap-2">
              <Phone className="h-4 w-4" />
              Call Clinic
            </Button>
            <Button 
              onClick={() => router.push(`/doctors/${doctor.id}/book`)}
              className="flex-1 gap-2"
            >
              Book Clinic Visit
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Spacer for fixed bottom */}
        <div className="h-20" />
      </main>
    </div>
  )
}
