"use client"

import { Suspense, use } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { 
  CheckCircle2,
  Calendar,
  Clock,
  MapPin,
  Download,
  Share2,
  Home,
  MessageCircle
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

// Mock doctor data
const doctorsData: Record<string, {
  id: string
  name: string
  specialty: string
  clinic: string
  clinicAddress: string
}> = {
  "dr-rajesh-kumar": {
    id: "dr-rajesh-kumar",
    name: "Dr. Rajesh Kumar",
    specialty: "Cardiologist",
    clinic: "HeartCare Clinic",
    clinicAddress: "123, MG Road, Bangalore - 560001",
  },
  "dr-priya-sharma": {
    id: "dr-priya-sharma",
    name: "Dr. Priya Sharma",
    specialty: "Cardiologist",
    clinic: "Apollo Heart Centre",
    clinicAddress: "45, Indiranagar, Bangalore - 560038",
  },
  "dr-anil-mehta": {
    id: "dr-anil-mehta",
    name: "Dr. Anil Mehta",
    specialty: "Cardiologist",
    clinic: "Fortis Hospital",
    clinicAddress: "154, Bannerghatta Road, Bangalore - 560076",
  },
  "dr-sunita-reddy": {
    id: "dr-sunita-reddy",
    name: "Dr. Sunita Reddy",
    specialty: "Cardiologist",
    clinic: "City Heart Hospital",
    clinicAddress: "78, Koramangala, Bangalore - 560034",
  },
  "dr-vikram-singh": {
    id: "dr-vikram-singh",
    name: "Dr. Vikram Singh",
    specialty: "Dermatologist",
    clinic: "SkinGlow Clinic",
    clinicAddress: "32, HSR Layout, Bangalore - 560102",
  },
}

function SuccessContent({ doctorId }: { doctorId: string }) {
  const searchParams = useSearchParams()
  const dateStr = searchParams.get("date")
  const slot = searchParams.get("slot")
  
  const doctor = doctorsData[doctorId]
  const bookingDate = dateStr ? new Date(dateStr) : new Date()
  
  const formatDate = (date: Date) => {
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    return `${days[date.getDay()]}, ${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`
  }

  const bookingId = `CV${Date.now().toString().slice(-8)}`

  if (!doctor) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Booking not found</p>
          <Link href="/">
            <Button>Go to Home</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="w-full border-b border-border bg-card">
        <div className="container flex h-16 items-center justify-center px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8 max-w-lg mx-auto">
        {/* Success Icon */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-emerald-100 mb-4">
            <CheckCircle2 className="h-12 w-12 text-emerald-500" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">Booking Confirmed!</h1>
          <p className="text-muted-foreground">Your appointment has been successfully booked</p>
        </div>

        {/* Booking Details Card */}
        <Card className="mb-6">
          <CardContent className="p-6 space-y-4">
            <div className="flex justify-between items-center pb-4 border-b border-border">
              <span className="text-sm text-muted-foreground">Booking ID</span>
              <span className="font-mono font-medium text-foreground">{bookingId}</span>
            </div>

            {/* Doctor Info */}
            <div className="flex gap-4 pb-4 border-b border-border">
              <div className="flex-shrink-0">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                  <span className="text-lg font-bold text-primary">
                    {doctor.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                  </span>
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{doctor.name}</h3>
                <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
              </div>
            </div>

            {/* Date & Time */}
            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5 text-primary" />
              <div>
                <p className="font-medium text-foreground">{formatDate(bookingDate)}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Clock className="h-5 w-5 text-primary" />
              <div>
                <p className="font-medium text-foreground">{slot || "10:00 AM"}</p>
              </div>
            </div>

            {/* Clinic Address */}
            <div className="flex items-start gap-3 pt-4 border-t border-border">
              <MapPin className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <p className="font-medium text-foreground">{doctor.clinic}</p>
                <p className="text-sm text-muted-foreground">{doctor.clinicAddress}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* WhatsApp Notification */}
        <div className="flex items-center gap-3 p-4 mb-6 bg-emerald-50 rounded-xl border border-emerald-200">
          <MessageCircle className="h-5 w-5 text-emerald-600" />
          <p className="text-sm text-emerald-800">
            Booking confirmation sent to your WhatsApp
          </p>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Download
          </Button>
          <Button variant="outline" className="gap-2">
            <Share2 className="h-4 w-4" />
            Share
          </Button>
        </div>

        {/* Go Home Button */}
        <Link href="/" className="block">
          <Button className="w-full gap-2" size="lg">
            <Home className="h-5 w-5" />
            Back to Home
          </Button>
        </Link>
      </main>
    </div>
  )
}

export default function BookingSuccessPage({ params }: { params: Promise<{ doctorId: string }> }) {
  const resolvedParams = use(params)
  
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    }>
      <SuccessContent doctorId={resolvedParams.doctorId} />
    </Suspense>
  )
}
