"use client"

import { useState, use } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { 
  ArrowLeft,
  Star,
  ThumbsUp,
  MapPin,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Sun,
  Sunset,
  Moon,
  Verified,
  Check,
  Shield,
  Clock,
  RefreshCcw,
  MessageCircle
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

// Mock doctor data (in real app, fetch from API)
const doctorsData: Record<string, {
  id: string
  name: string
  specialty: string
  experience: number
  rating: number
  totalRatings: number
  recommendation: number
  consultationFee: number
  serviceFee: number
  tax: number
  clinic: string
  clinicAddress: string
  image: string
  verified: boolean
  languages: string[]
  availableSlots: {
    date: Date
    morning: string[]
    evening: string[]
    night: string[]
  }[]
}> = {
  "dr-sharma": {
    id: "dr-sharma",
    name: "Dr. Amit Sharma",
    specialty: "General Physician",
    experience: 18,
    rating: 4.9,
    totalRatings: 2450,
    recommendation: 98,
    consultationFee: 500,
    serviceFee: 50,
    tax: 28,
    clinic: "Sharma Health Clinic",
    clinicAddress: "45, Koramangala 4th Block, Bangalore - 560034",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada", "Telugu"],
    availableSlots: [],
  },
  "dr-rajesh-kumar": {
    id: "dr-rajesh-kumar",
    name: "Dr. Rajesh Kumar",
    specialty: "Cardiologist",
    experience: 15,
    rating: 4.8,
    totalRatings: 1250,
    recommendation: 98,
    consultationFee: 500,
    serviceFee: 50,
    tax: 27,
    clinic: "HeartCare Clinic",
    clinicAddress: "123, MG Road, Bangalore - 560001",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
    availableSlots: [],
  },
  "dr-priya-sharma": {
    id: "dr-priya-sharma",
    name: "Dr. Priya Sharma",
    specialty: "Cardiologist",
    experience: 12,
    rating: 4.9,
    totalRatings: 980,
    recommendation: 99,
    consultationFee: 600,
    serviceFee: 60,
    tax: 33,
    clinic: "Apollo Heart Centre",
    clinicAddress: "45, Indiranagar, Bangalore - 560038",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
    availableSlots: [],
  },
  "dr-anil-mehta": {
    id: "dr-anil-mehta",
    name: "Dr. Anil Mehta",
    specialty: "Cardiologist",
    experience: 20,
    rating: 4.7,
    totalRatings: 2100,
    recommendation: 96,
    consultationFee: 800,
    serviceFee: 80,
    tax: 44,
    clinic: "Fortis Hospital",
    clinicAddress: "154, Bannerghatta Road, Bangalore - 560076",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Tamil"],
    availableSlots: [],
  },
  "dr-sunita-reddy": {
    id: "dr-sunita-reddy",
    name: "Dr. Sunita Reddy",
    specialty: "Cardiologist",
    experience: 8,
    rating: 4.6,
    totalRatings: 650,
    recommendation: 94,
    consultationFee: 400,
    serviceFee: 40,
    tax: 22,
    clinic: "City Heart Hospital",
    clinicAddress: "78, Koramangala, Bangalore - 560034",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Telugu", "Kannada"],
    availableSlots: [],
  },
  "dr-vikram-singh": {
    id: "dr-vikram-singh",
    name: "Dr. Vikram Singh",
    specialty: "Dermatologist",
    experience: 10,
    rating: 4.8,
    totalRatings: 890,
    recommendation: 97,
    consultationFee: 450,
    serviceFee: 45,
    tax: 25,
    clinic: "SkinGlow Clinic",
    clinicAddress: "32, HSR Layout, Bangalore - 560102",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Punjabi"],
    availableSlots: [],
  },
  "dr-kavitha-nair": {
    id: "dr-kavitha-nair",
    name: "Dr. Kavitha Nair",
    specialty: "Pediatrician",
    experience: 12,
    rating: 4.8,
    totalRatings: 1560,
    recommendation: 96,
    consultationFee: 450,
    serviceFee: 45,
    tax: 25,
    clinic: "Kids Care Clinic",
    clinicAddress: "88, Whitefield Main Road, Bangalore - 560066",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Malayalam"],
    availableSlots: [],
  },
  "dr-neha-gupta": {
    id: "dr-neha-gupta",
    name: "Dr. Neha Gupta",
    specialty: "Neurologist",
    experience: 14,
    rating: 4.8,
    totalRatings: 980,
    recommendation: 97,
    consultationFee: 700,
    serviceFee: 70,
    tax: 39,
    clinic: "NeuroLife Clinic",
    clinicAddress: "56, Jayanagar 4th Block, Bangalore - 560041",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
    availableSlots: [],
  },
  "dr-priya-patel": {
    id: "dr-priya-patel",
    name: "Dr. Priya Patel",
    specialty: "General Physician",
    experience: 12,
    rating: 4.8,
    totalRatings: 1890,
    recommendation: 97,
    consultationFee: 450,
    serviceFee: 45,
    tax: 25,
    clinic: "Wellness Care Center",
    clinicAddress: "78, Indiranagar Main Road, Bangalore - 560038",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
    availableSlots: [],
  },
  "dr-meera-nair": {
    id: "dr-meera-nair",
    name: "Dr. Meera Nair",
    specialty: "Dermatologist",
    experience: 8,
    rating: 4.7,
    totalRatings: 720,
    recommendation: 96,
    consultationFee: 400,
    serviceFee: 40,
    tax: 22,
    clinic: "Skin Expert Clinic",
    clinicAddress: "56, Whitefield, Bangalore - 560066",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Tamil", "Hindi"],
    availableSlots: [],
  },
  "dr-rohit-kapoor": {
    id: "dr-rohit-kapoor",
    name: "Dr. Rohit Kapoor",
    specialty: "Dermatologist",
    experience: 14,
    rating: 4.9,
    totalRatings: 1240,
    recommendation: 98,
    consultationFee: 550,
    serviceFee: 55,
    tax: 30,
    clinic: "Derma Plus Clinic",
    clinicAddress: "89, MG Road, Bangalore - 560001",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
    availableSlots: [],
  },
  "dr-sandeep-gupta": {
    id: "dr-sandeep-gupta",
    name: "Dr. Sandeep Gupta",
    specialty: "Pediatrician",
    experience: 10,
    rating: 4.7,
    totalRatings: 945,
    recommendation: 95,
    consultationFee: 400,
    serviceFee: 40,
    tax: 22,
    clinic: "Little Stars Pediatric",
    clinicAddress: "45, Jayanagar, Bangalore - 560041",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
    availableSlots: [],
  },
  "dr-ravi-sharma": {
    id: "dr-ravi-sharma",
    name: "Dr. Ravi Sharma",
    specialty: "Neurologist",
    experience: 16,
    rating: 4.8,
    totalRatings: 1100,
    recommendation: 96,
    consultationFee: 650,
    serviceFee: 65,
    tax: 36,
    clinic: "Brain & Mind Centre",
    clinicAddress: "123, Koramangala, Bangalore - 560034",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
    availableSlots: [],
  },
  "dr-susan-desai": {
    id: "dr-susan-desai",
    name: "Dr. Susan Desai",
    specialty: "Eye Specialist",
    experience: 11,
    rating: 4.9,
    totalRatings: 1350,
    recommendation: 98,
    consultationFee: 500,
    serviceFee: 50,
    tax: 28,
    clinic: "Clear Vision Clinic",
    clinicAddress: "78, HSR Layout, Bangalore - 560102",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
    availableSlots: [],
  },
  "dr-ajay-mishra": {
    id: "dr-ajay-mishra",
    name: "Dr. Ajay Mishra",
    specialty: "ENT Specialist",
    experience: 13,
    rating: 4.7,
    totalRatings: 820,
    recommendation: 95,
    consultationFee: 450,
    serviceFee: 45,
    tax: 25,
    clinic: "ENT Care Center",
    clinicAddress: "34, MG Road, Bangalore - 560001",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
    availableSlots: [],
  },
  "dr-mahesh-verma": {
    id: "dr-mahesh-verma",
    name: "Dr. Mahesh Verma",
    specialty: "Orthopedic",
    experience: 16,
    rating: 4.9,
    totalRatings: 1680,
    recommendation: 98,
    consultationFee: 600,
    serviceFee: 60,
    tax: 33,
    clinic: "Bone & Joint Care",
    clinicAddress: "67, Indiranagar, Bangalore - 560038",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
    availableSlots: [],
  },
  "dr-anjali-kapoor": {
    id: "dr-anjali-kapoor",
    name: "Dr. Anjali Kapoor",
    specialty: "Orthopedic",
    experience: 9,
    rating: 4.7,
    totalRatings: 650,
    recommendation: 94,
    consultationFee: 500,
    serviceFee: 50,
    tax: 28,
    clinic: "Sports Medicine Clinic",
    clinicAddress: "45, Koramangala, Bangalore - 560034",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Punjabi"],
    availableSlots: [],
  },
  "dr-deepak-patel": {
    id: "dr-deepak-patel",
    name: "Dr. Deepak Patel",
    specialty: "Pulmonologist",
    experience: 15,
    rating: 4.8,
    totalRatings: 1100,
    recommendation: 97,
    consultationFee: 550,
    serviceFee: 55,
    tax: 30,
    clinic: "Chest & Lung Clinic",
    clinicAddress: "23, Whitefield, Bangalore - 560066",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Gujarati"],
    availableSlots: [],
  },
  "dr-swati-joshi": {
    id: "dr-swati-joshi",
    name: "Dr. Swati Joshi",
    specialty: "Diabetologist",
    experience: 13,
    rating: 4.9,
    totalRatings: 1450,
    recommendation: 98,
    consultationFee: 600,
    serviceFee: 60,
    tax: 33,
    clinic: "Diabetes Care Center",
    clinicAddress: "92, MG Road, Bangalore - 560001",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
    availableSlots: [],
  },
  "dr-vikram-reddy": {
    id: "dr-vikram-reddy",
    name: "Dr. Vikram Reddy",
    specialty: "Diabetologist",
    experience: 11,
    rating: 4.7,
    totalRatings: 890,
    recommendation: 96,
    consultationFee: 500,
    serviceFee: 50,
    tax: 28,
    clinic: "Endocrine Clinic",
    clinicAddress: "45, Indiranagar, Bangalore - 560038",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Telugu", "Hindi"],
    availableSlots: [],
  },
  "dr-anand-iyer": {
    id: "dr-anand-iyer",
    name: "Dr. Anand Iyer",
    specialty: "Gastroenterologist",
    experience: 17,
    rating: 4.8,
    totalRatings: 1320,
    recommendation: 97,
    consultationFee: 700,
    serviceFee: 70,
    tax: 39,
    clinic: "GI Care Clinic",
    clinicAddress: "67, Jayanagar, Bangalore - 560041",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Tamil"],
    availableSlots: [],
  },
  "dr-rashmi-gupta": {
    id: "dr-rashmi-gupta",
    name: "Dr. Rashmi Gupta",
    specialty: "Gastroenterologist",
    experience: 9,
    rating: 4.6,
    totalRatings: 720,
    recommendation: 94,
    consultationFee: 600,
    serviceFee: 60,
    tax: 33,
    clinic: "Digestive Health Center",
    clinicAddress: "34, Koramangala, Bangalore - 560034",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
    availableSlots: [],
  },
  "dr-meera-kapoor": {
    id: "dr-meera-kapoor",
    name: "Dr. Meera Kapoor",
    specialty: "Rheumatologist",
    experience: 14,
    rating: 4.7,
    totalRatings: 980,
    recommendation: 95,
    consultationFee: 650,
    serviceFee: 65,
    tax: 36,
    clinic: "Rheumatic Diseases Clinic",
    clinicAddress: "78, HSR Layout, Bangalore - 560102",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
    availableSlots: [],
  },
  "dr-rohan-sinha": {
    id: "dr-rohan-sinha",
    name: "Dr. Rohan Sinha",
    specialty: "Rheumatologist",
    experience: 12,
    rating: 4.8,
    totalRatings: 1100,
    recommendation: 97,
    consultationFee: 600,
    serviceFee: 60,
    tax: 33,
    clinic: "Joint & Rheumatic Care",
    clinicAddress: "45, Whitefield, Bangalore - 560066",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Punjabi"],
    availableSlots: [],
  },
  "dr-priya-menon": {
    id: "dr-priya-menon",
    name: "Dr. Priya Menon",
    specialty: "Psychiatrist",
    experience: 10,
    rating: 4.8,
    totalRatings: 850,
    recommendation: 96,
    consultationFee: 800,
    serviceFee: 80,
    tax: 44,
    clinic: "Mental Health Clinic",
    clinicAddress: "56, Indiranagar, Bangalore - 560038",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Malayalam"],
    availableSlots: [],
  },
  "dr-arjun-verma": {
    id: "dr-arjun-verma",
    name: "Dr. Arjun Verma",
    specialty: "Psychiatrist",
    experience: 15,
    rating: 4.9,
    totalRatings: 1250,
    recommendation: 98,
    consultationFee: 850,
    serviceFee: 85,
    tax: 47,
    clinic: "Behavioral Health Center",
    clinicAddress: "89, MG Road, Bangalore - 560001",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
    availableSlots: [],
  },
  "dr-kavya-sharma": {
    id: "dr-kavya-sharma",
    name: "Dr. Kavya Sharma",
    specialty: "Dentist",
    experience: 8,
    rating: 4.8,
    totalRatings: 1620,
    recommendation: 96,
    consultationFee: 400,
    serviceFee: 40,
    tax: 22,
    clinic: "Smile Dental Clinic",
    clinicAddress: "23, Koramangala, Bangalore - 560034",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
    availableSlots: [],
  },
  "dr-harsh-patel": {
    id: "dr-harsh-patel",
    name: "Dr. Harsh Patel",
    specialty: "Dentist",
    experience: 11,
    rating: 4.7,
    totalRatings: 1450,
    recommendation: 95,
    consultationFee: 450,
    serviceFee: 45,
    tax: 25,
    clinic: "Advanced Dental Care",
    clinicAddress: "67, HSR Layout, Bangalore - 560102",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Tamil"],
    availableSlots: [],
  },
  "dr-vikram-nair": {
    id: "dr-vikram-nair",
    name: "Dr. Vikram Nair",
    specialty: "Urologist",
    experience: 16,
    rating: 4.8,
    totalRatings: 1100,
    recommendation: 97,
    consultationFee: 750,
    serviceFee: 75,
    tax: 41,
    clinic: "Urology Care Center",
    clinicAddress: "45, Jayanagar, Bangalore - 560041",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Malayalam"],
    availableSlots: [],
  },
  "dr-sumit-singh": {
    id: "dr-sumit-singh",
    name: "Dr. Sumit Singh",
    specialty: "Urologist",
    experience: 9,
    rating: 4.6,
    totalRatings: 750,
    recommendation: 94,
    consultationFee: 650,
    serviceFee: 65,
    tax: 36,
    clinic: "Advanced Urology Clinic",
    clinicAddress: "78, Whitefield, Bangalore - 560066",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Punjabi"],
    availableSlots: [],
  },
  "dr-pooja-desai": {
    id: "dr-pooja-desai",
    name: "Dr. Pooja Desai",
    specialty: "ENT Specialist",
    experience: 10,
    rating: 4.8,
    totalRatings: 920,
    recommendation: 96,
    consultationFee: 500,
    serviceFee: 50,
    tax: 28,
    clinic: "ENT Solutions Clinic",
    clinicAddress: "56, Indiranagar, Bangalore - 560038",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi", "Kannada"],
    availableSlots: [],
  },
  "dr-rajesh-nair": {
    id: "dr-rajesh-nair",
    name: "Dr. Rajesh Nair",
    specialty: "Oncologist",
    experience: 18,
    rating: 4.9,
    totalRatings: 680,
    recommendation: 98,
    consultationFee: 1000,
    serviceFee: 100,
    tax: 55,
    clinic: "Cancer Care Institute",
    clinicAddress: "123, Indiranagar, Bangalore - 560038",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
    availableSlots: [],
  },
  "dr-arun-sharma": {
    id: "dr-arun-sharma",
    name: "Dr. Arun Sharma",
    specialty: "Nephrologist",
    experience: 14,
    rating: 4.8,
    totalRatings: 840,
    recommendation: 97,
    consultationFee: 700,
    serviceFee: 70,
    tax: 39,
    clinic: "Kidney Care Center",
    clinicAddress: "67, Whitefield, Bangalore - 560066",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
    availableSlots: [],
  },
  "dr-sanjay-mishra": {
    id: "dr-sanjay-mishra",
    name: "Dr. Sanjay Mishra",
    specialty: "Vascular Surgeon",
    experience: 17,
    rating: 4.7,
    totalRatings: 620,
    recommendation: 96,
    consultationFee: 900,
    serviceFee: 90,
    tax: 50,
    clinic: "Vascular Surgery Center",
    clinicAddress: "89, MG Road, Bangalore - 560001",
    image: "/placeholder.svg?height=120&width=120",
    verified: true,
    languages: ["English", "Hindi"],
    availableSlots: [],
  },
}

// Generate available dates (next 7 days)
function generateDates() {
  const dates = []
  const today = new Date()
  for (let i = 0; i < 7; i++) {
    const date = new Date(today)
    date.setDate(today.getDate() + i)
    dates.push(date)
  }
  return dates
}

// Generate time slots
const morningSlots = ["9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM"]
const eveningSlots = ["2:00 PM", "2:30 PM", "3:00 PM", "3:30 PM", "4:00 PM", "4:30 PM", "5:00 PM"]
const nightSlots = ["6:00 PM", "6:30 PM", "7:00 PM", "7:30 PM", "8:00 PM"]

type BookingStep = "slots" | "confirm"

export default function BookDoctorPage({ params }: { params: Promise<{ doctorId: string }> }) {
  const resolvedParams = use(params)
  const router = useRouter()
  const doctor = doctorsData[resolvedParams.doctorId]
  
  const [step, setStep] = useState<BookingStep>("slots")
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null)
  const [whatsappNotify, setWhatsappNotify] = useState(true)
  
  const dates = generateDates()

  if (!doctor) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Doctor not found</p>
          <Button onClick={() => router.push("/doctors")}>View all doctors</Button>
        </div>
      </div>
    )
  }

  const totalAmount = doctor.consultationFee + doctor.serviceFee + doctor.tax

  const formatDate = (date: Date) => {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return {
      day: days[date.getDay()],
      date: date.getDate(),
      month: months[date.getMonth()],
      isToday: date.toDateString() === new Date().toDateString()
    }
  }

  const handleSlotSelect = (slot: string) => {
    setSelectedSlot(slot)
    setStep("confirm")
  }

  const handleConfirmBooking = () => {
    // In real app, make API call to confirm booking
    router.push(`/doctors/${resolvedParams.doctorId}/book/success?date=${selectedDate.toISOString()}&slot=${selectedSlot}`)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center gap-4 px-4">
          <button 
            onClick={() => step === "confirm" ? setStep("slots") : router.back()}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back</span>
          </button>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <main className="container px-4 py-6 max-w-3xl mx-auto">
        {step === "slots" && (
          <>
            {/* Doctor Card */}
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 rounded-xl bg-secondary flex items-center justify-center overflow-hidden">
                      <div className="w-full h-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                        <span className="text-xl font-bold text-primary">
                          {doctor.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h2 className="font-semibold text-foreground">{doctor.name}</h2>
                      {doctor.verified && <Verified className="h-4 w-4 text-primary" />}
                    </div>
                    <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <div className="flex items-center gap-1">
                        <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                        <span className="text-sm">{doctor.rating}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <ThumbsUp className="h-3.5 w-3.5 text-emerald-500" />
                        <span className="text-sm text-emerald-600">{doctor.recommendation}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Date Selection */}
            <div className="mb-6">
              <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                Select Date
              </h3>
              <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4">
                {dates.map((date) => {
                  const formatted = formatDate(date)
                  const isSelected = date.toDateString() === selectedDate.toDateString()
                  return (
                    <button
                      key={date.toISOString()}
                      onClick={() => setSelectedDate(date)}
                      className={`flex flex-col items-center min-w-[60px] p-3 rounded-xl border-2 transition-all ${
                        isSelected 
                          ? "border-primary bg-primary/10" 
                          : "border-border bg-card hover:border-primary/50"
                      }`}
                    >
                      <span className="text-xs text-muted-foreground">{formatted.day}</span>
                      <span className={`text-lg font-bold ${isSelected ? "text-primary" : "text-foreground"}`}>
                        {formatted.date}
                      </span>
                      <span className="text-xs text-muted-foreground">{formatted.month}</span>
                      {formatted.isToday && (
                        <Badge variant="secondary" className="mt-1 text-[10px] px-1.5 py-0">Today</Badge>
                      )}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Time Slots */}
            <div className="space-y-6">
              {/* Morning Slots */}
              <div>
                <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                  <Sun className="h-4 w-4 text-amber-500" />
                  Morning Slots
                </h4>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {morningSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => handleSlotSelect(slot)}
                      className="px-3 py-2 text-sm border border-border rounded-lg bg-card hover:border-primary hover:bg-primary/5 transition-colors"
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Evening Slots */}
              <div>
                <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                  <Sunset className="h-4 w-4 text-orange-500" />
                  Evening Slots
                </h4>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {eveningSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => handleSlotSelect(slot)}
                      className="px-3 py-2 text-sm border border-border rounded-lg bg-card hover:border-primary hover:bg-primary/5 transition-colors"
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Night Slots */}
              <div>
                <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                  <Moon className="h-4 w-4 text-indigo-500" />
                  Night Slots
                </h4>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {nightSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => handleSlotSelect(slot)}
                      className="px-3 py-2 text-sm border border-border rounded-lg bg-card hover:border-primary hover:bg-primary/5 transition-colors"
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}

        {step === "confirm" && (
          <>
            {/* Booking Summary */}
            <Card className="mb-6">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Booking Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Doctor Profile */}
                <div className="flex gap-4 pb-4 border-b border-border">
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 rounded-xl bg-secondary flex items-center justify-center overflow-hidden">
                      <div className="w-full h-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                        <span className="text-xl font-bold text-primary">
                          {doctor.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-foreground">{doctor.name}</h3>
                      {doctor.verified && <Verified className="h-4 w-4 text-primary" />}
                    </div>
                    <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
                    <p className="text-sm text-muted-foreground">{doctor.experience} years experience</p>
                  </div>
                </div>

                {/* Date & Time */}
                <div className="flex items-center gap-3 py-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium text-foreground">
                      {formatDate(selectedDate).day}, {formatDate(selectedDate).date} {formatDate(selectedDate).month}
                    </p>
                    <p className="text-sm text-muted-foreground">{selectedSlot}</p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="ml-auto text-primary"
                    onClick={() => setStep("slots")}
                  >
                    Change
                  </Button>
                </div>

                {/* Clinic Address */}
                <div className="flex items-start gap-3 py-2 border-t border-border">
                  <MapPin className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <p className="font-medium text-foreground">{doctor.clinic}</p>
                    <p className="text-sm text-muted-foreground">{doctor.clinicAddress}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Bill Details */}
            <Card className="mb-6">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Bill Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Consultation Fee</span>
                  <span className="font-medium">Rs. {doctor.consultationFee}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Service Fee</span>
                  <span className="font-medium">Rs. {doctor.serviceFee}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tax</span>
                  <span className="font-medium">Rs. {doctor.tax}</span>
                </div>
                <div className="flex justify-between pt-3 border-t border-border">
                  <span className="font-semibold text-foreground">Total Amount</span>
                  <span className="font-bold text-lg text-primary">Rs. {totalAmount}</span>
                </div>
              </CardContent>
            </Card>

            {/* CareVia Promises */}
            <Card className="mb-6 bg-primary/5 border-primary/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  CareVia Promises
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Confirmed Instantly</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>100% Refund if cancelled 2 hours before appointment</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Free follow-up consultation within 7 days</span>
                </div>
              </CardContent>
            </Card>

            {/* WhatsApp Notification */}
            <div className="flex items-center gap-3 p-4 mb-6 bg-card rounded-xl border border-border">
              <Checkbox 
                id="whatsapp" 
                checked={whatsappNotify}
                onCheckedChange={(checked) => setWhatsappNotify(!!checked)}
              />
              <Label htmlFor="whatsapp" className="flex items-center gap-2 cursor-pointer">
                <MessageCircle className="h-5 w-5 text-emerald-500" />
                <span className="text-sm">Get notifications on WhatsApp</span>
              </Label>
              <span className="text-xs text-muted-foreground ml-auto">Sent to registered number</span>
            </div>

            {/* Confirm Button */}
            <Button 
              onClick={handleConfirmBooking}
              className="w-full h-14 text-lg font-semibold"
              size="lg"
            >
              Confirm Clinic Visit - Rs. {totalAmount}
            </Button>
          </>
        )}
      </main>
    </div>
  )
}
