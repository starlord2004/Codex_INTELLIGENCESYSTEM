"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { 
  Search, 
  ArrowLeft,
  Eye, 
  Baby, 
  Sparkles, 
  Brain, 
  Bone, 
  Heart, 
  Stethoscope,
  Activity,
  Smile,
  Ear,
  Pill,
  Syringe,
  Shield,
  Zap,
  Thermometer,
  Wind,
  Moon,
  Waves,
  Droplets,
  CircleDot,
  Scissors,
  FlaskConical,
  HeartPulse,
  TrendingUp,
  ChevronDown,
  ChevronUp
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const mostSearchedSpecialists = [
  { icon: Stethoscope, name: "General Physician", consultations: "2.5L+", color: "bg-emerald-100 text-emerald-600", slug: "general-physician" },
  { icon: Smile, name: "Dentist", consultations: "1.8L+", color: "bg-cyan-100 text-cyan-600", slug: "dentist" },
  { icon: Sparkles, name: "Dermatologist", consultations: "1.5L+", color: "bg-purple-100 text-purple-600", slug: "dermatologist" },
  { icon: Baby, name: "Pediatrician", consultations: "1.2L+", color: "bg-pink-100 text-pink-600", slug: "pediatrician" },
  { icon: Activity, name: "Gynecologist", consultations: "1.1L+", color: "bg-rose-100 text-rose-600", slug: "gynecologist" },
  { icon: Bone, name: "Orthopedic", consultations: "95K+", color: "bg-amber-100 text-amber-600", slug: "orthopedic" },
  { icon: Brain, name: "Neurologist", consultations: "85K+", color: "bg-indigo-100 text-indigo-600", slug: "neurologist" },
  { icon: Heart, name: "Cardiologist", consultations: "75K+", color: "bg-red-100 text-red-600", slug: "cardiologist" },
]

const allSpecialists = [
  ...mostSearchedSpecialists,
  { icon: Eye, name: "Eye Specialist", consultations: "70K+", color: "bg-blue-100 text-blue-600", slug: "eye-specialist" },
  { icon: Ear, name: "ENT Specialist", consultations: "65K+", color: "bg-teal-100 text-teal-600", slug: "ent-specialist" },
  { icon: Pill, name: "Gastroenterologist", consultations: "60K+", color: "bg-orange-100 text-orange-600", slug: "gastroenterologist" },
  { icon: Syringe, name: "Diabetologist", consultations: "55K+", color: "bg-lime-100 text-lime-600", slug: "diabetologist" },
  { icon: Shield, name: "Urologist", consultations: "50K+", color: "bg-sky-100 text-sky-600", slug: "urologist" },
  { icon: Zap, name: "Psychiatrist", consultations: "48K+", color: "bg-violet-100 text-violet-600", slug: "psychiatrist" },
  { icon: Thermometer, name: "Infectious Disease", consultations: "45K+", color: "bg-red-100 text-red-600", slug: "infectious-disease" },
  { icon: Wind, name: "Pulmonologist", consultations: "42K+", color: "bg-slate-100 text-slate-600", slug: "pulmonologist" },
  { icon: Moon, name: "Sleep Specialist", consultations: "38K+", color: "bg-indigo-100 text-indigo-600", slug: "sleep-specialist" },
  { icon: Waves, name: "Rheumatologist", consultations: "35K+", color: "bg-blue-100 text-blue-600", slug: "rheumatologist" },
  { icon: Droplets, name: "Nephrologist", consultations: "32K+", color: "bg-cyan-100 text-cyan-600", slug: "nephrologist" },
  { icon: CircleDot, name: "Proctologist", consultations: "30K+", color: "bg-amber-100 text-amber-600", slug: "proctologist" },
  { icon: Scissors, name: "Plastic Surgeon", consultations: "28K+", color: "bg-pink-100 text-pink-600", slug: "plastic-surgeon" },
  { icon: FlaskConical, name: "Oncologist", consultations: "25K+", color: "bg-purple-100 text-purple-600", slug: "oncologist" },
  { icon: HeartPulse, name: "Vascular Surgeon", consultations: "22K+", color: "bg-rose-100 text-rose-600", slug: "vascular-surgeon" },
  { icon: Wind, name: "Chest Specialist", consultations: "20K+", color: "bg-teal-100 text-teal-600", slug: "chest-specialist" },
  { icon: FlaskConical, name: "Endocrinologist", consultations: "18K+", color: "bg-emerald-100 text-emerald-600", slug: "endocrinologist" },
]

const popularSymptoms = [
  { name: "Fever", slug: "fever" },
  { name: "Cold & Cough", slug: "cough" },
  { name: "Headache", slug: "headache" },
  { name: "Back Pain", slug: "back-pain" },
  { name: "Skin Rash", slug: "skin-rash" },
  { name: "Stomach Pain", slug: "stomach-pain" },
  { name: "Joint Pain", slug: "joint-pain" },
  { name: "Anxiety", slug: "anxiety" },
  { name: "Hair Loss", slug: "hair-loss" },
  { name: "Acne", slug: "acne" },
]

export default function AppointmentPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [showAllSpecialists, setShowAllSpecialists] = useState(false)
  
  const displayedSpecialists = showAllSpecialists ? allSpecialists : mostSearchedSpecialists
  const filteredSpecialists = searchQuery 
    ? allSpecialists.filter(s => 
        s.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : displayedSpecialists

  const handleSpecialistClick = (slug: string) => {
    router.push(`/doctors?specialty=${slug}`)
  }

  const handleSymptomClick = (slug: string) => {
    router.push(`/doctors?condition=${slug}`)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center gap-4 px-4">
          <Link href="/" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back to Home</span>
          </Link>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8">
        {/* Page Title */}
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
            Book Physical Appointment
          </h1>
          <p className="text-muted-foreground">
            Find and book appointments with top doctors near you
          </p>
        </div>

        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative max-w-2xl">
            <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search symptoms or specialists..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-14 pl-12 pr-4 text-base rounded-xl border-2 border-border focus:border-primary"
            />
          </div>
          
          {/* Popular Searches */}
          <div className="mt-4">
            <p className="text-sm text-muted-foreground mb-2">Popular searches:</p>
            <div className="flex flex-wrap gap-2">
              {popularSymptoms.map((symptom) => (
                <button
                  key={symptom.slug}
                  onClick={() => handleSymptomClick(symptom.slug)}
                  className="px-3 py-1.5 text-sm bg-muted hover:bg-muted/80 rounded-full transition-colors cursor-pointer"
                >
                  {symptom.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Most Searched Specialists */}
        <section className="mb-8">
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-semibold text-foreground">
              {searchQuery ? "Search Results" : "Most Searched Specialists"}
            </h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {filteredSpecialists.map((specialist) => (
              <button
                key={specialist.slug}
                onClick={() => handleSpecialistClick(specialist.slug)}
                className="group flex flex-col items-center p-4 bg-card rounded-xl border border-border hover:border-primary/50 hover:shadow-md transition-all duration-200 cursor-pointer"
              >
                <div className={`flex h-14 w-14 items-center justify-center rounded-full ${specialist.color} mb-3 group-hover:scale-110 transition-transform`}>
                  <specialist.icon className="h-7 w-7" />
                </div>
                <span className="text-sm font-medium text-foreground text-center mb-1">
                  {specialist.name}
                </span>
                <span className="text-xs text-muted-foreground">
                  {specialist.consultations} consultations
                </span>
              </button>
            ))}
          </div>

          {!searchQuery && (
            <div className="flex justify-center mt-6">
              <Button
                variant="outline"
                size="lg"
                onClick={() => setShowAllSpecialists(!showAllSpecialists)}
                className="gap-2"
              >
                {showAllSpecialists ? (
                  <>
                    <ChevronUp className="h-4 w-4" />
                    Show Less
                  </>
                ) : (
                  <>
                    <ChevronDown className="h-4 w-4" />
                    View All Specialists ({allSpecialists.length})
                  </>
                )}
              </Button>
            </div>
          )}

          {searchQuery && filteredSpecialists.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No specialists found for &quot;{searchQuery}&quot;</p>
              <Button
                variant="link"
                onClick={() => setSearchQuery("")}
                className="mt-2"
              >
                Clear search
              </Button>
            </div>
          )}
        </section>

        {/* How it Works */}
        <section className="bg-muted/50 rounded-2xl p-6 md:p-8">
          <h2 className="text-xl font-semibold text-foreground mb-6 text-center">
            How to Book an Appointment
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex flex-col items-center text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold text-lg mb-3">
                1
              </div>
              <h3 className="font-medium text-foreground mb-1">Search Specialist</h3>
              <p className="text-sm text-muted-foreground">
                Find doctors by specialty, symptom, or name
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold text-lg mb-3">
                2
              </div>
              <h3 className="font-medium text-foreground mb-1">Choose Time Slot</h3>
              <p className="text-sm text-muted-foreground">
                Select a convenient date and time
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold text-lg mb-3">
                3
              </div>
              <h3 className="font-medium text-foreground mb-1">Visit Doctor</h3>
              <p className="text-sm text-muted-foreground">
                Get consultation at the clinic
              </p>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
