"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { 
  ArrowLeft,
  Search,
  ShoppingCart,
  Plus,
  Minus,
  Upload,
  Pill,
  Clock,
  Truck,
  Shield,
  Tag,
  ChevronRight,
  X,
  Percent,
  Package,
  AlertCircle,
  Check
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"

// Mock medicines data
const medicinesData = [
  {
    id: "med-1",
    name: "Paracetamol 500mg",
    brand: "Crocin",
    type: "Tablet",
    packSize: "Strip of 15 tablets",
    mrp: 35,
    discount: 15,
    price: 29.75,
    category: "Pain Relief",
    prescription: false,
    inStock: true,
    image: null
  },
  {
    id: "med-2",
    name: "Azithromycin 500mg",
    brand: "Azee",
    type: "Tablet",
    packSize: "Strip of 3 tablets",
    mrp: 120,
    discount: 10,
    price: 108,
    category: "Antibiotics",
    prescription: true,
    inStock: true,
    image: null
  },
  {
    id: "med-3",
    name: "Cetirizine 10mg",
    brand: "Zyrtec",
    type: "Tablet",
    packSize: "Strip of 10 tablets",
    mrp: 85,
    discount: 12,
    price: 74.80,
    category: "Allergy",
    prescription: false,
    inStock: true,
    image: null
  },
  {
    id: "med-4",
    name: "Omeprazole 20mg",
    brand: "Omez",
    type: "Capsule",
    packSize: "Strip of 15 capsules",
    mrp: 145,
    discount: 18,
    price: 118.90,
    category: "Digestive Health",
    prescription: false,
    inStock: true,
    image: null
  },
  {
    id: "med-5",
    name: "Metformin 500mg",
    brand: "Glycomet",
    type: "Tablet",
    packSize: "Strip of 20 tablets",
    mrp: 55,
    discount: 20,
    price: 44,
    category: "Diabetes",
    prescription: true,
    inStock: true,
    image: null
  },
  {
    id: "med-6",
    name: "Amlodipine 5mg",
    brand: "Amlong",
    type: "Tablet",
    packSize: "Strip of 15 tablets",
    mrp: 75,
    discount: 15,
    price: 63.75,
    category: "Blood Pressure",
    prescription: true,
    inStock: true,
    image: null
  },
  {
    id: "med-7",
    name: "Vitamin D3 60000 IU",
    brand: "D-Rise",
    type: "Capsule",
    packSize: "Strip of 4 capsules",
    mrp: 180,
    discount: 10,
    price: 162,
    category: "Vitamins",
    prescription: false,
    inStock: true,
    image: null
  },
  {
    id: "med-8",
    name: "Multivitamin Tablets",
    brand: "Supradyn",
    type: "Tablet",
    packSize: "Strip of 15 tablets",
    mrp: 95,
    discount: 8,
    price: 87.40,
    category: "Vitamins",
    prescription: false,
    inStock: true,
    image: null
  },
  // Cough & Cold
  {
    id: "med-9",
    name: "Cough Syrup",
    brand: "Ascoril",
    type: "Syrup",
    packSize: "100ml Bottle",
    mrp: 65,
    discount: 12,
    price: 57.20,
    category: "Cough & Cold",
    prescription: false,
    inStock: true,
    image: null
  },
  {
    id: "med-10",
    name: "Ibuprofen 400mg",
    brand: "Combiflam",
    type: "Tablet",
    packSize: "Strip of 15 tablets",
    mrp: 58,
    discount: 14,
    price: 49.92,
    category: "Pain Relief",
    prescription: false,
    inStock: true,
    image: null
  },
  // Antibiotics
  {
    id: "med-11",
    name: "Amoxicillin 500mg",
    brand: "Amoxin",
    type: "Capsule",
    packSize: "Strip of 10 capsules",
    mrp: 90,
    discount: 16,
    price: 75.60,
    category: "Antibiotics",
    prescription: true,
    inStock: true,
    image: null
  },
  {
    id: "med-12",
    name: "Ciprofloxacin 500mg",
    brand: "Cipro",
    type: "Tablet",
    packSize: "Strip of 10 tablets",
    mrp: 110,
    discount: 15,
    price: 93.50,
    category: "Antibiotics",
    prescription: true,
    inStock: true,
    image: null
  },
  // Skin Care
  {
    id: "med-13",
    name: "Clotrimazole Cream",
    brand: "Candid",
    type: "Cream",
    packSize: "30g Tube",
    mrp: 85,
    discount: 18,
    price: 69.70,
    category: "Skin Care",
    prescription: false,
    inStock: true,
    image: null
  },
  {
    id: "med-14",
    name: "Salicylic Acid Lotion",
    brand: "Saliguard",
    type: "Lotion",
    packSize: "100ml Bottle",
    mrp: 150,
    discount: 20,
    price: 120,
    category: "Skin Care",
    prescription: false,
    inStock: true,
    image: null
  },
  // Heart Health
  {
    id: "med-15",
    name: "Aspirin 75mg",
    brand: "Aspirn",
    type: "Tablet",
    packSize: "Strip of 15 tablets",
    mrp: 45,
    discount: 10,
    price: 40.50,
    category: "Heart Health",
    prescription: true,
    inStock: true,
    image: null
  },
  {
    id: "med-16",
    name: "Atorvastatin 10mg",
    brand: "Atorlip",
    type: "Tablet",
    packSize: "Strip of 15 tablets",
    mrp: 95,
    discount: 22,
    price: 74.10,
    category: "Heart Health",
    prescription: true,
    inStock: true,
    image: null
  },
  // Joint & Bone
  {
    id: "med-17",
    name: "Calcium + Vitamin D3",
    brand: "Shelcal",
    type: "Tablet",
    packSize: "Strip of 15 tablets",
    mrp: 125,
    discount: 16,
    price: 105,
    category: "Joint & Bone",
    prescription: false,
    inStock: true,
    image: null
  },
  {
    id: "med-18",
    name: "Diclofenac 50mg",
    brand: "Voveran",
    type: "Tablet",
    packSize: "Strip of 10 tablets",
    mrp: 70,
    discount: 15,
    price: 59.50,
    category: "Joint & Bone",
    prescription: true,
    inStock: true,
    image: null
  },
  // Digestive Health
  {
    id: "med-19",
    name: "Antacid Tablets",
    brand: "Gelusil",
    type: "Tablet",
    packSize: "Strip of 20 tablets",
    mrp: 55,
    discount: 18,
    price: 45.10,
    category: "Digestive Health",
    prescription: false,
    inStock: true,
    image: null
  },
  {
    id: "med-20",
    name: "Ranitidine 150mg",
    brand: "Rantac",
    type: "Tablet",
    packSize: "Strip of 10 tablets",
    mrp: 80,
    discount: 12,
    price: 70.40,
    category: "Digestive Health",
    prescription: true,
    inStock: true,
    image: null
  },
  // Respiratory
  {
    id: "med-21",
    name: "Salbutamol Inhaler",
    brand: "Asthalin",
    type: "Inhaler",
    packSize: "120 Metered Dose",
    mrp: 250,
    discount: 10,
    price: 225,
    category: "Respiratory",
    prescription: true,
    inStock: true,
    image: null
  },
  {
    id: "med-22",
    name: "Montelukast 10mg",
    brand: "Montair",
    type: "Tablet",
    packSize: "Strip of 10 tablets",
    mrp: 120,
    discount: 20,
    price: 96,
    category: "Respiratory",
    prescription: true,
    inStock: true,
    image: null
  },
  // Sleep & Anxiety
  {
    id: "med-23",
    name: "Melatonin 3mg",
    brand: "Melatrol",
    type: "Tablet",
    packSize: "Strip of 15 tablets",
    mrp: 140,
    discount: 15,
    price: 119,
    category: "Sleep & Anxiety",
    prescription: false,
    inStock: true,
    image: null
  },
  {
    id: "med-24",
    name: "Alprazolam 0.5mg",
    brand: "Xanax",
    type: "Tablet",
    packSize: "Strip of 10 tablets",
    mrp: 65,
    discount: 12,
    price: 57.20,
    category: "Sleep & Anxiety",
    prescription: true,
    inStock: true,
    image: null
  },
  // Fever & Pain
  {
    id: "med-25",
    name: "Disprin 325mg",
    brand: "Disprin",
    type: "Effervescent Tablet",
    packSize: "Strip of 10 tablets",
    mrp: 48,
    discount: 10,
    price: 43.20,
    category: "Pain Relief",
    prescription: false,
    inStock: true,
    image: null
  },
  {
    id: "med-26",
    name: "Aceclofenac 100mg",
    brand: "Hifenac",
    type: "Tablet",
    packSize: "Strip of 15 tablets",
    mrp: 85,
    discount: 18,
    price: 69.70,
    category: "Pain Relief",
    prescription: true,
    inStock: true,
    image: null
  },
  // Allergy
  {
    id: "med-27",
    name: "Fexofenadine 180mg",
    brand: "Allegra",
    type: "Tablet",
    packSize: "Strip of 10 tablets",
    mrp: 150,
    discount: 15,
    price: 127.50,
    category: "Allergy",
    prescription: false,
    inStock: true,
    image: null
  },
  {
    id: "med-28",
    name: "Loratadine 10mg",
    brand: "Claritin",
    type: "Tablet",
    packSize: "Strip of 10 tablets",
    mrp: 95,
    discount: 14,
    price: 81.70,
    category: "Allergy",
    prescription: false,
    inStock: true,
    image: null
  },
]

const categories = ["All", "Pain Relief", "Antibiotics", "Allergy", "Digestive Health", "Diabetes", "Blood Pressure", "Vitamins", "Cough & Cold", "Skin Care", "Heart Health", "Joint & Bone", "Respiratory", "Sleep & Anxiety"]

type CartItem = {
  medicine: typeof medicinesData[0]
  quantity: number
}

export default function MedicinesPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [cart, setCart] = useState<CartItem[]>([])
  const [showCart, setShowCart] = useState(false)
  const [showPrescriptionModal, setShowPrescriptionModal] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [recognizedMedicines, setRecognizedMedicines] = useState<Array<typeof medicinesData[0]>>([])
  const [isProcessing, setIsProcessing] = useState(false)

  const filteredMedicines = medicinesData.filter(med => {
    const matchesSearch = med.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         med.brand.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "All" || med.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const addToCart = (medicine: typeof medicinesData[0]) => {
    setCart(prev => {
      const existing = prev.find(item => item.medicine.id === medicine.id)
      if (existing) {
        return prev.map(item => 
          item.medicine.id === medicine.id 
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }
      return [...prev, { medicine, quantity: 1 }]
    })
  }

  const removeFromCart = (medicineId: string) => {
    setCart(prev => {
      const existing = prev.find(item => item.medicine.id === medicineId)
      if (existing && existing.quantity > 1) {
        return prev.map(item => 
          item.medicine.id === medicineId 
            ? { ...item, quantity: item.quantity - 1 }
            : item
        )
      }
      return prev.filter(item => item.medicine.id !== medicineId)
    })
  }

  const getCartQuantity = (medicineId: string) => {
    const item = cart.find(item => item.medicine.id === medicineId)
    return item?.quantity || 0
  }

  const cartTotal = cart.reduce((sum, item) => sum + (item.medicine.price * item.quantity), 0)
  const cartItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0)

  // Mock OCR function - simulates prescription recognition
  const processPrescription = async (file: File) => {
    setIsProcessing(true)
    
    // Simulate OCR processing
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    // Mock detected medicines from prescription
    const mockDetectedMedicines = [
      medicinesData.find(m => m.id === "med-2"), // Azithromycin
      medicinesData.find(m => m.id === "med-6"), // Amlodipine
      medicinesData.find(m => m.id === "med-9"), // Cough Syrup
    ].filter(Boolean) as typeof medicinesData
    
    setRecognizedMedicines(mockDetectedMedicines)
    setIsProcessing(false)
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setUploadedFile(file)
      processPrescription(file)
    }
  }

  const addRecognizedMedicineToCart = (medicine: typeof medicinesData[0]) => {
    addToCart(medicine)
  }

  const addAllRecognizedToCart = () => {
    recognizedMedicines.forEach(med => {
      addToCart(med)
    })
    setShowPrescriptionModal(false)
    setRecognizedMedicines([])
    setUploadedFile(null)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => router.back()}
              className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <span className="text-sm font-bold text-primary-foreground">C</span>
              </div>
              <span className="text-xl font-bold text-primary">CAREVIA</span>
            </div>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            className="relative gap-2"
            onClick={() => setShowCart(true)}
          >
            <ShoppingCart className="h-4 w-4" />
            <span className="hidden sm:inline">Cart</span>
            {cartItemsCount > 0 && (
              <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs">
                {cartItemsCount}
              </Badge>
            )}
          </Button>
        </div>
      </header>

      <main className="container px-4 py-6 max-w-4xl mx-auto">
        {/* Page Title */}
        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">Order Medicines</h1>
          <p className="text-muted-foreground">Get medicines delivered to your doorstep</p>
        </div>

        {/* Upload Prescription Banner */}
        <Card className="mb-6 bg-primary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Upload className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">Upload Prescription</p>
                  <p className="text-sm text-muted-foreground">Order medicines with valid prescription</p>
                </div>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowPrescriptionModal(true)}
              >
                Upload
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Promises */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="flex flex-col items-center text-center p-3 bg-card rounded-xl border border-border">
            <Truck className="h-6 w-6 text-primary mb-2" />
            <p className="text-xs font-medium text-foreground">Free Delivery</p>
            <p className="text-xs text-muted-foreground">Above Rs. 199</p>
          </div>
          <div className="flex flex-col items-center text-center p-3 bg-card rounded-xl border border-border">
            <Clock className="h-6 w-6 text-primary mb-2" />
            <p className="text-xs font-medium text-foreground">Express</p>
            <p className="text-xs text-muted-foreground">2-4 Hours</p>
          </div>
          <div className="flex flex-col items-center text-center p-3 bg-card rounded-xl border border-border">
            <Shield className="h-6 w-6 text-primary mb-2" />
            <p className="text-xs font-medium text-foreground">100% Genuine</p>
            <p className="text-xs text-muted-foreground">Medicines</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search medicines, brands..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 h-12"
          />
        </div>

        {/* Categories */}
        <div className="flex gap-2 overflow-x-auto pb-4 -mx-4 px-4 mb-4">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className="whitespace-nowrap"
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Medicines Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filteredMedicines.map((medicine) => {
            const quantity = getCartQuantity(medicine.id)
            return (
              <Card key={medicine.id} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex gap-3">
                    <div className="w-16 h-16 rounded-lg bg-secondary flex items-center justify-center flex-shrink-0">
                      <Pill className="h-8 w-8 text-primary/50" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-medium text-foreground text-sm">{medicine.name}</h3>
                          <p className="text-xs text-muted-foreground">{medicine.brand}</p>
                          <p className="text-xs text-muted-foreground">{medicine.packSize}</p>
                        </div>
                        {medicine.prescription && (
                          <Badge variant="outline" className="text-[10px] flex-shrink-0">Rx</Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-2 mt-2">
                        <span className="font-bold text-foreground">Rs. {medicine.price.toFixed(2)}</span>
                        <span className="text-xs text-muted-foreground line-through">Rs. {medicine.mrp}</span>
                        <Badge variant="secondary" className="text-[10px] bg-emerald-100 text-emerald-700">
                          {medicine.discount}% off
                        </Badge>
                      </div>

                      <div className="mt-3">
                        {quantity === 0 ? (
                          <Button 
                            size="sm" 
                            className="w-full"
                            onClick={() => addToCart(medicine)}
                          >
                            Add to Cart
                          </Button>
                        ) : (
                          <div className="flex items-center justify-center gap-3 bg-primary/10 rounded-lg p-1">
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-8 w-8"
                              onClick={() => removeFromCart(medicine.id)}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <span className="font-medium text-foreground w-8 text-center">{quantity}</span>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-8 w-8"
                              onClick={() => addToCart(medicine)}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {filteredMedicines.length === 0 && (
          <div className="text-center py-12">
            <Pill className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No medicines found</p>
          </div>
        )}
      </main>

      {/* Cart Sidebar */}
      {showCart && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowCart(false)} />
          <div className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-card border-l border-border">
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between p-4 border-b border-border">
                <h2 className="text-lg font-bold text-foreground">Your Cart</h2>
                <Button variant="ghost" size="icon" onClick={() => setShowCart(false)}>
                  <X className="h-5 w-5" />
                </Button>
              </div>

              {cart.length === 0 ? (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <ShoppingCart className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">Your cart is empty</p>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {cart.map((item) => (
                      <div key={item.medicine.id} className="flex gap-3 pb-4 border-b border-border">
                        <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center flex-shrink-0">
                          <Pill className="h-6 w-6 text-primary/50" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-foreground text-sm">{item.medicine.name}</h4>
                          <p className="text-xs text-muted-foreground">{item.medicine.packSize}</p>
                          <p className="font-medium text-foreground mt-1">Rs. {(item.medicine.price * item.quantity).toFixed(2)}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            size="icon"
                            variant="outline"
                            className="h-8 w-8"
                            onClick={() => removeFromCart(item.medicine.id)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-6 text-center font-medium">{item.quantity}</span>
                          <Button
                            size="icon"
                            variant="outline"
                            className="h-8 w-8"
                            onClick={() => addToCart(item.medicine)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="p-4 border-t border-border">
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Subtotal</span>
                        <span className="font-medium">Rs. {cartTotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Delivery</span>
                        <span className="font-medium text-emerald-600">{cartTotal >= 199 ? "FREE" : "Rs. 40"}</span>
                      </div>
                      <Separator />
                      <div className="flex justify-between">
                        <span className="font-semibold">Total</span>
                        <span className="font-bold text-lg text-primary">
                          Rs. {(cartTotal + (cartTotal >= 199 ? 0 : 40)).toFixed(2)}
                        </span>
                      </div>
                    </div>
                    <Button 
                      className="w-full" 
                      size="lg"
                      onClick={() => router.push("/medicines/checkout")}
                    >
                      Proceed to Checkout
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Floating Cart Button */}
      {cart.length > 0 && !showCart && (
        <div className="fixed bottom-4 left-4 right-4 max-w-md mx-auto">
          <Button 
            className="w-full h-14 shadow-lg gap-2"
            onClick={() => setShowCart(true)}
          >
            <ShoppingCart className="h-5 w-5" />
            <span>{cartItemsCount} items</span>
            <span className="mx-2">|</span>
            <span className="font-bold">Rs. {cartTotal.toFixed(2)}</span>
            <ChevronRight className="h-5 w-5 ml-auto" />
          </Button>
        </div>
      )}

      {/* Prescription Upload Modal */}
      {showPrescriptionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <Card className="w-full max-w-md mx-4 max-h-[90vh] overflow-y-auto">
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <CardTitle>Upload Prescription</CardTitle>
              <button
                onClick={() => {
                  setShowPrescriptionModal(false)
                  setUploadedFile(null)
                  setRecognizedMedicines([])
                }}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-5 w-5" />
              </button>
            </CardHeader>
            <CardContent className="space-y-4">
              {!uploadedFile ? (
                <>
                  <p className="text-sm text-muted-foreground">
                    Upload a clear image of your prescription. We&apos;ll recognize the medicines automatically.
                  </p>
                  
                  <div className="relative border-2 border-dashed border-primary/30 rounded-xl p-6 text-center hover:border-primary/50 transition-colors cursor-pointer">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    <Upload className="h-8 w-8 text-primary mx-auto mb-2" />
                    <p className="font-medium text-foreground">Click to upload</p>
                    <p className="text-xs text-muted-foreground mt-1">PNG, JPG up to 5MB</p>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-700">
                    <AlertCircle className="h-4 w-4 inline mr-2" />
                    Prescription should be clear and readable
                  </div>
                </>
              ) : (
                <>
                  {isProcessing ? (
                    <div className="flex flex-col items-center justify-center py-8">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mb-4"></div>
                      <p className="font-medium text-foreground">Analyzing prescription...</p>
                      <p className="text-sm text-muted-foreground mt-1">This may take a few seconds</p>
                    </div>
                  ) : recognizedMedicines.length > 0 ? (
                    <>
                      <div className="flex items-center gap-2 text-sm font-medium text-emerald-600 mb-4">
                        <Check className="h-4 w-4" />
                        {recognizedMedicines.length} medicine{recognizedMedicines.length !== 1 ? "s" : ""} recognized
                      </div>

                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {recognizedMedicines.map((med) => (
                          <div
                            key={med.id}
                            className="flex items-center justify-between p-3 bg-secondary rounded-lg"
                          >
                            <div className="flex-1">
                              <p className="font-medium text-foreground text-sm">{med.name}</p>
                              <p className="text-xs text-muted-foreground">{med.brand} • Rs. {med.price}</p>
                            </div>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => addRecognizedMedicineToCart(med)}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        ))}
                      </div>

                      <Separator className="my-4" />

                      <Button
                        onClick={addAllRecognizedToCart}
                        size="lg"
                        className="w-full mb-2"
                      >
                        Add All to Cart
                      </Button>
                      <Button
                        variant="outline"
                        size="lg"
                        className="w-full"
                        onClick={() => {
                          setShowPrescriptionModal(false)
                          setUploadedFile(null)
                          setRecognizedMedicines([])
                        }}
                      >
                        Close
                      </Button>
                    </>
                  ) : (
                    <>
                      <p className="text-sm text-muted-foreground text-center py-4">
                        No medicines could be recognized from this prescription. Please try another image.
                      </p>
                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => {
                          setUploadedFile(null)
                          setRecognizedMedicines([])
                        }}
                      >
                        Try Another Image
                      </Button>
                    </>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
