"use client"

import { useState, useEffect, Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { 
  CheckCircle,
  Package,
  Truck,
  Clock,
  MapPin,
  Phone,
  Copy,
  Home,
  ChevronRight
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

function OrderConfirmationContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const bookingId = searchParams.get("bookingId") || "ORD-LOADING"
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    if (copied) {
      const timer = setTimeout(() => setCopied(false), 2000)
      return () => clearTimeout(timer)
    }
  }, [copied])

  const copyToClipboard = () => {
    navigator.clipboard.writeText(bookingId)
    setCopied(true)
  }

  return (
    <main className="container px-4 py-12 max-w-2xl mx-auto">
      {/* Success Icon */}
      <div className="flex justify-center mb-8">
        <div className="relative">
          <div className="absolute inset-0 bg-emerald-500/20 rounded-full blur-xl"></div>
          <div className="relative w-24 h-24 rounded-full bg-emerald-100 flex items-center justify-center">
            <CheckCircle className="h-16 w-16 text-emerald-600" />
          </div>
        </div>
      </div>

      {/* Success Message */}
      <div className="text-center mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
          Order Confirmed!
        </h1>
        <p className="text-lg text-muted-foreground">
          Your medicine order has been successfully placed
        </p>
      </div>

      {/* Booking ID */}
      <Card className="mb-6 bg-primary/5 border-primary/20">
        <CardContent className="p-6">
          <p className="text-sm text-muted-foreground mb-2">Your Booking ID</p>
          <div className="flex items-center gap-3">
            <span className="text-2xl font-bold text-primary font-mono">
              {bookingId}
            </span>
            <Button
              size="sm"
              variant="outline"
              onClick={copyToClipboard}
              className={copied ? "bg-emerald-50 border-emerald-200" : ""}
            >
              <Copy className={`h-4 w-4 ${copied ? "text-emerald-600" : ""}`} />
              {copied ? "Copied" : "Copy"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Order Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {/* Status */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-emerald-600" />
              </div>
              <h3 className="font-semibold text-foreground">Order Status</h3>
            </div>
            <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">
              Order Confirmed
            </Badge>
            <p className="text-xs text-muted-foreground mt-2">
              Payment received successfully
            </p>
          </CardContent>
        </Card>

        {/* Delivery */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                <Truck className="h-5 w-5 text-blue-600" />
              </div>
              <h3 className="font-semibold text-foreground">Estimated Delivery</h3>
            </div>
            <p className="font-semibold text-foreground">2-4 Hours</p>
            <p className="text-xs text-muted-foreground mt-1">
              Within business hours
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Order Summary */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Order Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <div>
                <p className="font-medium text-foreground">Paracetamol 500mg (Crocin)</p>
                <p className="text-xs text-muted-foreground">Strip of 15 tablets × 1</p>
              </div>
              <p className="font-semibold">Rs. 29.75</p>
            </div>
            <div className="flex justify-between text-sm">
              <div>
                <p className="font-medium text-foreground">Azithromycin 500mg (Azee)</p>
                <p className="text-xs text-muted-foreground">Strip of 3 tablets × 1</p>
              </div>
              <p className="font-semibold">Rs. 108.00</p>
            </div>
          </div>
          <div className="border-t border-border pt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotal</span>
              <span>Rs. 137.75</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Delivery Fee</span>
              <span className="text-emerald-600">FREE</span>
            </div>
            <div className="border-t border-border pt-2 flex justify-between font-bold">
              <span>Total Paid</span>
              <span className="text-primary">Rs. 137.75</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Delivery Details */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Delivery Address</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-3">
            <MapPin className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-foreground">Bangalore, India</p>
              <p className="text-sm text-muted-foreground">Your registered delivery address</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Phone className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-foreground">+91-XXXXXXXXXX</p>
              <p className="text-sm text-muted-foreground">Our executive will contact you soon</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Info Box */}
      <Card className="mb-8 bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex gap-3">
            <Clock className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-semibold text-blue-900 mb-1">Tracking Information</p>
              <p className="text-blue-700">
                You&apos;ll receive an SMS/Email with tracking details shortly. Save your booking ID for reference.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="space-y-3">
        <Button 
          size="lg" 
          className="w-full"
          onClick={() => router.push("/medicines")}
        >
          <Package className="h-4 w-4 mr-2" />
          Continue Shopping
          <ChevronRight className="h-4 w-4 ml-auto" />
        </Button>
        <Button 
          size="lg" 
          variant="outline"
          className="w-full"
          onClick={() => router.push("/")}
        >
          <Home className="h-4 w-4 mr-2" />
          Back to Home
        </Button>
      </div>
    </main>
  )
}

export default function OrderConfirmationPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur">
        <div className="container flex h-16 items-center gap-4 px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <Suspense fallback={
        <div className="flex items-center justify-center min-h-[500px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading order details...</p>
          </div>
        </div>
      }>
        <OrderConfirmationContent />
      </Suspense>
    </div>
  )
}
