"use client"

import { useState, Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { 
  ArrowLeft,
  CreditCard,
  Smartphone,
  Wallet,
  Truck,
  DollarSign,
  CheckCircle2,
  ChevronRight
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

const paymentMethods = [
  { id: "credit-card", name: "Credit/Debit Card", icon: CreditCard },
  { id: "upi", name: "UPI (Google Pay, PhonePe)", icon: Smartphone },
  { id: "wallet", name: "Wallet", icon: Wallet },
  { id: "netbanking", name: "Net Banking", icon: DollarSign },
  { id: "cod", name: "Cash on Delivery", icon: Truck },
  { id: "prepaid", name: "Prepaid Wallet", icon: Wallet },
]

function PaymentContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const customerName = searchParams.get("customer") || "Customer"
  const [selectedMethod, setSelectedMethod] = useState("upi")
  const [isProcessing, setIsProcessing] = useState(false)

  const handlePayment = async () => {
    setIsProcessing(true)
    
    // Simulate payment processing
    setTimeout(() => {
      const bookingId = `ORD-${Math.random().toString(36).substr(2, 8).toUpperCase()}-${new Date().getFullYear()}`
      router.push(`/medicines/order-confirmation?bookingId=${bookingId}&method=${selectedMethod}`)
    }, 2000)
  }

  const cartTotal = 137.75
  const deliveryFee = 0
  const finalTotal = cartTotal + deliveryFee

  return (
    <>
      {/* Progress Steps */}
      <div className="mb-8 flex items-center justify-between">
        <div className="flex items-center gap-2 opacity-50">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-muted-foreground font-bold">
            1
          </div>
          <span className="font-semibold">Details</span>
        </div>
        <div className="flex-1 h-1 mx-2 bg-muted"></div>
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold">
            2
          </div>
          <span className="font-semibold text-foreground">Payment</span>
        </div>
        <div className="flex-1 h-1 mx-2 bg-muted"></div>
        <div className="flex items-center gap-2 opacity-50">
          <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-muted font-bold">
            3
          </div>
          <span className="font-semibold">Confirm</span>
        </div>
      </div>

      <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
        Select Payment Method
      </h1>
      <p className="text-muted-foreground mb-8">
        Choose how you&apos;d like to pay for your order
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Payment Methods */}
        <div className="lg:col-span-2 space-y-4">
          {paymentMethods.map((method) => {
            const Icon = method.icon
            return (
              <Card 
                key={method.id}
                className={`cursor-pointer transition-all ${selectedMethod === method.id ? "border-primary ring-2 ring-primary/20" : "hover:border-primary/50"}`}
                onClick={() => setSelectedMethod(method.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="w-6 h-6 rounded-full border-2 border-primary flex items-center justify-center flex-shrink-0">
                      {selectedMethod === method.id && (
                        <div className="w-2.5 h-2.5 rounded-full bg-primary"></div>
                      )}
                    </div>
                    <div className="flex-1 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <label 
                        htmlFor={method.id}
                        className="flex-1 font-medium text-foreground cursor-pointer"
                      >
                        {method.name}
                      </label>
                    </div>
                    {selectedMethod === method.id && (
                      <CheckCircle2 className="h-5 w-5 text-primary" />
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <Card className="sticky top-20">
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">2 Items</span>
                  <span className="font-medium">Rs. {cartTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Delivery</span>
                  <span className="font-medium text-emerald-600">FREE</span>
                </div>
              </div>

              <Separator />

              <div className="flex justify-between">
                <span className="font-semibold text-foreground">Total Amount</span>
                <span className="font-bold text-lg text-primary">
                  Rs. {finalTotal.toFixed(2)}
                </span>
              </div>

              <Separator />

              <div className="space-y-2 text-xs text-muted-foreground">
                <p>Delivery to: {customerName}</p>
                <p>Payment via: {paymentMethods.find(m => m.id === selectedMethod)?.name}</p>
              </div>

              <Button 
                onClick={handlePayment}
                disabled={isProcessing}
                size="lg"
                className="w-full mt-6"
              >
                {isProcessing ? "Processing Payment..." : `Pay Rs. ${finalTotal.toFixed(2)}`}
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  )
}

export default function PaymentPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur">
        <div className="container flex h-16 items-center gap-4 px-4">
          <Link 
            href="/medicines/checkout"
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8 max-w-2xl mx-auto">
        <Suspense fallback={
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading payment options...</p>
            </div>
          </div>
        }>
          <PaymentContent />
        </Suspense>
      </main>
    </div>
  )
}
