"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { 
  ArrowLeft,
  Check,
  MapPin,
  Phone,
  Mail,
  ChevronRight
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"

const medicinesData = [
  {
    id: "med-1",
    name: "Paracetamol 500mg",
    brand: "Crocin",
    price: 29.75,
    packSize: "Strip of 15 tablets"
  },
  {
    id: "med-2",
    name: "Azithromycin 500mg",
    brand: "Azee",
    price: 108,
    packSize: "Strip of 3 tablets"
  },
  {
    id: "med-3",
    name: "Cetirizine 10mg",
    brand: "Zyrtec",
    price: 74.80,
    packSize: "Strip of 10 tablets"
  }
]

export default function CheckoutPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    name: "",
    address: "",
    phone: "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }))
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}
    
    if (!formData.name.trim()) newErrors.name = "Name is required"
    if (!formData.address.trim()) newErrors.address = "Address is required"
    if (!formData.phone.trim()) newErrors.phone = "Phone number is required"
    else if (!/^\d{10}$/.test(formData.phone.replace(/\D/g, ""))) {
      newErrors.phone = "Phone number must be 10 digits"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!validateForm()) return

    setIsSubmitting(true)
    
    setTimeout(() => {
      const cartData = JSON.stringify({
        customer: formData,
        timestamp: new Date().toISOString()
      })
      router.push(`/medicines/payment?customer=${encodeURIComponent(formData.name)}&address=${encodeURIComponent(formData.address)}&phone=${formData.phone}`)
    }, 500)
  }

  // Mock cart data
  const cart = [
    { medicine: medicinesData[0], quantity: 1 },
    { medicine: medicinesData[1], quantity: 1 }
  ]
  const cartTotal = cart.reduce((sum, item) => sum + (item.medicine.price * item.quantity), 0)
  const deliveryFee = cartTotal >= 199 ? 0 : 40
  const finalTotal = cartTotal + deliveryFee

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur">
        <div className="container flex h-16 items-center gap-4 px-4">
          <Link 
            href="/medicines"
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8 max-w-2xl mx-auto">
        {/* Progress Steps */}
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold">
              1
            </div>
            <span className="font-semibold text-foreground">Details</span>
          </div>
          <div className="flex-1 h-1 mx-2 bg-muted"></div>
          <div className="flex items-center gap-2 opacity-50">
            <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-muted font-bold">
              2
            </div>
            <span className="font-semibold">Payment</span>
          </div>
          <div className="flex-1 h-1 mx-2 bg-muted"></div>
          <div className="flex items-center gap-2 opacity-50">
            <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-muted font-bold">
              3
            </div>
            <span className="font-semibold">Confirm</span>
          </div>
        </div>

        <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
          Enter Your Details
        </h1>
        <p className="text-muted-foreground mb-8">
          Please provide your delivery details to complete your order
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Delivery Information</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label className="text-sm font-medium text-foreground mb-1.5 flex items-center gap-1">
                      <Mail className="h-4 w-4" />
                      Full Name
                    </label>
                    <Input
                      type="text"
                      name="name"
                      placeholder="John Doe"
                      value={formData.name}
                      onChange={handleInputChange}
                      className={errors.name ? "border-red-500" : ""}
                    />
                    {errors.name && (
                      <p className="text-sm text-red-500 mt-1">{errors.name}</p>
                    )}
                  </div>

                  <div>
                    <label className="text-sm font-medium text-foreground mb-1.5 flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      Delivery Address
                    </label>
                    <textarea
                      name="address"
                      placeholder="Enter your complete address with house number, street, area, city, and postal code"
                      value={formData.address}
                      onChange={handleInputChange}
                      className={`w-full px-3 py-2 rounded-lg border ${errors.address ? "border-red-500" : "border-border"} bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none`}
                      rows={3}
                    />
                    {errors.address && (
                      <p className="text-sm text-red-500 mt-1">{errors.address}</p>
                    )}
                  </div>

                  <div>
                    <label className="text-sm font-medium text-foreground mb-1.5 flex items-center gap-1">
                      <Phone className="h-4 w-4" />
                      Phone Number
                    </label>
                    <Input
                      type="tel"
                      name="phone"
                      placeholder="10-digit phone number"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className={errors.phone ? "border-red-500" : ""}
                    />
                    {errors.phone && (
                      <p className="text-sm text-red-500 mt-1">{errors.phone}</p>
                    )}
                  </div>

                  <Separator />

                  <Button 
                    type="submit"
                    size="lg"
                    disabled={isSubmitting}
                    className="w-full"
                  >
                    {isSubmitting ? "Processing..." : "Proceed to Payment"}
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {cart.map((item) => (
                  <div key={item.medicine.id} className="flex justify-between text-sm">
                    <div>
                      <p className="font-medium text-foreground">{item.medicine.name}</p>
                      <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                    </div>
                    <p className="font-semibold text-foreground">
                      Rs. {(item.medicine.price * item.quantity).toFixed(2)}
                    </p>
                  </div>
                ))}
                
                <Separator />
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="font-medium">Rs. {cartTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Delivery Fee</span>
                    <span className="font-medium">
                      {deliveryFee === 0 ? (
                        <span className="text-emerald-600">FREE</span>
                      ) : (
                        `Rs. ${deliveryFee}`
                      )}
                    </span>
                  </div>
                  {cartTotal >= 199 && (
                    <div className="flex items-center gap-2 text-xs text-emerald-600">
                      <Check className="h-3 w-3" />
                      Free delivery applicable
                    </div>
                  )}
                </div>

                <Separator />

                <div className="flex justify-between">
                  <span className="font-semibold text-foreground">Total Amount</span>
                  <span className="font-bold text-lg text-primary">
                    Rs. {finalTotal.toFixed(2)}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
