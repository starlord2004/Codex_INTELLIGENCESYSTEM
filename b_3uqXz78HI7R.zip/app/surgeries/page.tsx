"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { 
  ArrowLeft,
  Search,
  Scissors,
  Clock,
  Shield,
  ChevronRight,
  Star,
  MapPin,
  Check,
  Phone,
  FileText,
  HeartPulse,
  Bed,
  Users,
  Calendar,
  Verified,
  ThumbsUp,
  IndianRupee,
  MessageCircle
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

// Mock surgeries data
const surgeriesData = [
  {
    id: "surgery-1",
    name: "Cataract Surgery",
    category: "Ophthalmology",
    description: "Advanced phacoemulsification with premium IOL implantation",
    duration: "30-45 mins",
    recovery: "1-2 days",
    hospitalStay: "Day care",
    startingPrice: 25000,
    maxPrice: 60000,
    popular: true
  },
  {
    id: "surgery-2",
    name: "Knee Replacement",
    category: "Orthopedics",
    description: "Total knee replacement surgery with imported implants",
    duration: "2-3 hours",
    recovery: "6-8 weeks",
    hospitalStay: "4-5 days",
    startingPrice: 150000,
    maxPrice: 350000,
    popular: true
  },
  {
    id: "surgery-3",
    name: "Appendectomy",
    category: "General Surgery",
    description: "Laparoscopic appendix removal surgery",
    duration: "1-2 hours",
    recovery: "1-2 weeks",
    hospitalStay: "1-2 days",
    startingPrice: 45000,
    maxPrice: 85000,
    popular: false
  },
  {
    id: "surgery-4",
    name: "Hernia Repair",
    category: "General Surgery",
    description: "Laparoscopic hernia repair with mesh",
    duration: "1-2 hours",
    recovery: "2-3 weeks",
    hospitalStay: "1 day",
    startingPrice: 50000,
    maxPrice: 100000,
    popular: true
  },
  {
    id: "surgery-5",
    name: "Gallbladder Removal",
    category: "General Surgery",
    description: "Laparoscopic cholecystectomy for gallstones",
    duration: "1-2 hours",
    recovery: "1-2 weeks",
    hospitalStay: "1-2 days",
    startingPrice: 55000,
    maxPrice: 95000,
    popular: false
  },
  {
    id: "surgery-6",
    name: "LASIK Eye Surgery",
    category: "Ophthalmology",
    description: "Blade-free LASIK for vision correction",
    duration: "20-30 mins",
    recovery: "1-2 days",
    hospitalStay: "Day care",
    startingPrice: 35000,
    maxPrice: 90000,
    popular: true
  },
  {
    id: "surgery-7",
    name: "Angioplasty",
    category: "Cardiology",
    description: "Coronary angioplasty with stent placement",
    duration: "1-2 hours",
    recovery: "1-2 weeks",
    hospitalStay: "2-3 days",
    startingPrice: 150000,
    maxPrice: 400000,
    popular: true
  },
  {
    id: "surgery-8",
    name: "Hip Replacement",
    category: "Orthopedics",
    description: "Total hip replacement with ceramic implants",
    duration: "2-3 hours",
    recovery: "8-10 weeks",
    hospitalStay: "4-5 days",
    startingPrice: 200000,
    maxPrice: 450000,
    popular: false
  }
]

// Mock surgeons data
const surgeonsData = [
  {
    id: "surgeon-1",
    name: "Dr. Suresh Rao",
    specialty: "Orthopedic Surgeon",
    experience: 22,
    rating: 4.9,
    surgeries: 5000,
    recommendation: 99,
    hospital: "Apollo Hospital",
    hospitalAddress: "154, Bannerghatta Road, Bangalore",
    verified: true,
    consultationFee: 800,
    surgeryCategories: ["Orthopedics"]
  },
  {
    id: "surgeon-2",
    name: "Dr. Meera Krishnan",
    specialty: "Ophthalmologist",
    experience: 18,
    rating: 4.8,
    surgeries: 8000,
    recommendation: 98,
    hospital: "Sankara Eye Hospital",
    hospitalAddress: "22, Bannerghatta Road, Bangalore",
    verified: true,
    consultationFee: 600,
    surgeryCategories: ["Ophthalmology"]
  },
  {
    id: "surgeon-3",
    name: "Dr. Arun Sharma",
    specialty: "General Surgeon",
    experience: 15,
    rating: 4.7,
    surgeries: 3500,
    recommendation: 96,
    hospital: "Fortis Hospital",
    hospitalAddress: "14, Cunningham Road, Bangalore",
    verified: true,
    consultationFee: 700,
    surgeryCategories: ["General Surgery"]
  },
  {
    id: "surgeon-4",
    name: "Dr. Prakash Hegde",
    specialty: "Cardiac Surgeon",
    experience: 25,
    rating: 4.9,
    surgeries: 4000,
    recommendation: 99,
    hospital: "Narayana Health",
    hospitalAddress: "258, Bommasandra, Bangalore",
    verified: true,
    consultationFee: 1000,
    surgeryCategories: ["Cardiology"]
  }
]

const categories = ["All", "General Surgery", "Orthopedics", "Ophthalmology", "Cardiology"]

type BookingStep = "list" | "details" | "surgeons" | "consult"

export default function SurgeriesPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [step, setStep] = useState<BookingStep>("list")
  const [selectedSurgery, setSelectedSurgery] = useState<typeof surgeriesData[0] | null>(null)
  const [selectedSurgeon, setSelectedSurgeon] = useState<typeof surgeonsData[0] | null>(null)
  const [whatsappNotify, setWhatsappNotify] = useState(true)

  const filteredSurgeries = surgeriesData.filter(surgery => {
    const matchesSearch = surgery.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "All" || surgery.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const filteredSurgeons = selectedSurgery 
    ? surgeonsData.filter(surgeon => surgeon.surgeryCategories.includes(selectedSurgery.category))
    : []

  const handleSurgerySelect = (surgery: typeof surgeriesData[0]) => {
    setSelectedSurgery(surgery)
    setStep("details")
  }

  const handleSurgeonSelect = (surgeon: typeof surgeonsData[0]) => {
    setSelectedSurgeon(surgeon)
    setStep("consult")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center gap-4 px-4">
          <button 
            onClick={() => {
              if (step === "list") router.back()
              else if (step === "details") setStep("list")
              else if (step === "surgeons") setStep("details")
              else if (step === "consult") setStep("surgeons")
            }}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">C</span>
            </div>
            <span className="text-xl font-bold text-primary">CAREVIA</span>
          </div>
        </div>
      </header>

      <main className="container px-4 py-6 max-w-4xl mx-auto">
        {step === "list" && (
          <>
            {/* Page Title */}
            <div className="mb-6">
              <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">Book Surgeries</h1>
              <p className="text-muted-foreground">Expert surgeons at affordable prices</p>
            </div>

            {/* Promises */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
              <div className="flex flex-col items-center text-center p-3 bg-card rounded-xl border border-border">
                <Shield className="h-6 w-6 text-primary mb-2" />
                <p className="text-xs font-medium text-foreground">No Cost EMI</p>
              </div>
              <div className="flex flex-col items-center text-center p-3 bg-card rounded-xl border border-border">
                <FileText className="h-6 w-6 text-primary mb-2" />
                <p className="text-xs font-medium text-foreground">Free Consultation</p>
              </div>
              <div className="flex flex-col items-center text-center p-3 bg-card rounded-xl border border-border">
                <HeartPulse className="h-6 w-6 text-primary mb-2" />
                <p className="text-xs font-medium text-foreground">Expert Surgeons</p>
              </div>
              <div className="flex flex-col items-center text-center p-3 bg-card rounded-xl border border-border">
                <Bed className="h-6 w-6 text-primary mb-2" />
                <p className="text-xs font-medium text-foreground">Free Follow-up</p>
              </div>
            </div>

            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search surgeries..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12"
              />
            </div>

            {/* Categories */}
            <div className="flex gap-2 overflow-x-auto pb-4 -mx-4 px-4 mb-4">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="whitespace-nowrap"
                >
                  {category}
                </Button>
              ))}
            </div>

            {/* Surgeries List */}
            <div className="space-y-4">
              {filteredSurgeries.map((surgery) => (
                <Card 
                  key={surgery.id} 
                  className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => handleSurgerySelect(surgery)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-foreground">{surgery.name}</h3>
                          {surgery.popular && (
                            <Badge variant="secondary" className="text-[10px] bg-amber-100 text-amber-700">Popular</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">{surgery.description}</p>
                        <Badge variant="outline" className="mt-2 text-xs">{surgery.category}</Badge>
                        
                        <div className="flex flex-wrap gap-4 mt-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {surgery.duration}
                          </span>
                          <span className="flex items-center gap-1">
                            <Bed className="h-3 w-3" />
                            {surgery.hospitalStay}
                          </span>
                        </div>

                        <div className="mt-3">
                          <span className="text-sm text-muted-foreground">Starting from </span>
                          <span className="font-bold text-foreground">Rs. {surgery.startingPrice.toLocaleString()}</span>
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}

        {step === "details" && selectedSurgery && (
          <>
            <h2 className="text-xl font-bold text-foreground mb-2">{selectedSurgery.name}</h2>
            <Badge variant="outline" className="mb-6">{selectedSurgery.category}</Badge>

            {/* Surgery Details */}
            <Card className="mb-6">
              <CardContent className="p-4">
                <p className="text-muted-foreground">{selectedSurgery.description}</p>
                
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="p-3 bg-secondary/50 rounded-lg">
                    <p className="text-xs text-muted-foreground">Duration</p>
                    <p className="font-medium text-foreground">{selectedSurgery.duration}</p>
                  </div>
                  <div className="p-3 bg-secondary/50 rounded-lg">
                    <p className="text-xs text-muted-foreground">Hospital Stay</p>
                    <p className="font-medium text-foreground">{selectedSurgery.hospitalStay}</p>
                  </div>
                  <div className="p-3 bg-secondary/50 rounded-lg">
                    <p className="text-xs text-muted-foreground">Recovery Time</p>
                    <p className="font-medium text-foreground">{selectedSurgery.recovery}</p>
                  </div>
                  <div className="p-3 bg-secondary/50 rounded-lg">
                    <p className="text-xs text-muted-foreground">Cost Range</p>
                    <p className="font-medium text-foreground">
                      Rs. {selectedSurgery.startingPrice.toLocaleString()} - {selectedSurgery.maxPrice.toLocaleString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* What's Included */}
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">What&apos;s Included</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Pre-surgery consultation</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Surgery by expert surgeon</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Hospital stay as required</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Post-surgery follow-ups</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Insurance assistance</span>
                </div>
              </CardContent>
            </Card>

            {/* CTA */}
            <Button 
              className="w-full h-12"
              onClick={() => setStep("surgeons")}
            >
              View Available Surgeons
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </>
        )}

        {step === "surgeons" && selectedSurgery && (
          <>
            <h2 className="text-xl font-bold text-foreground mb-2">Select Surgeon</h2>
            <p className="text-muted-foreground mb-6">Expert surgeons for {selectedSurgery.name}</p>

            <div className="space-y-4">
              {filteredSurgeons.map((surgeon) => (
                <Card key={surgeon.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <div className="flex-shrink-0">
                        <div className="w-16 h-16 rounded-xl bg-secondary flex items-center justify-center">
                          <span className="text-xl font-bold text-primary">
                            {surgeon.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                          </span>
                        </div>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-foreground">{surgeon.name}</h3>
                          {surgeon.verified && <Verified className="h-4 w-4 text-primary" />}
                        </div>
                        <p className="text-sm text-muted-foreground">{surgeon.specialty}</p>
                        <p className="text-sm text-muted-foreground">{surgeon.experience} years experience</p>
                        
                        <div className="flex flex-wrap items-center gap-3 mt-2">
                          <div className="flex items-center gap-1">
                            <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                            <span className="text-sm font-medium">{surgeon.rating}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <ThumbsUp className="h-3.5 w-3.5 text-emerald-500" />
                            <span className="text-sm text-emerald-600">{surgeon.recommendation}%</span>
                          </div>
                          <span className="text-xs text-muted-foreground">{surgeon.surgeries.toLocaleString()}+ surgeries</span>
                        </div>

                        <div className="flex items-start gap-2 mt-3">
                          <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                          <div>
                            <p className="text-sm font-medium text-foreground">{surgeon.hospital}</p>
                            <p className="text-xs text-muted-foreground">{surgeon.hospitalAddress}</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
                          <div>
                            <span className="text-sm text-muted-foreground">Consultation: </span>
                            <span className="font-semibold text-foreground">Rs. {surgeon.consultationFee}</span>
                          </div>
                          <Button size="sm" onClick={() => handleSurgeonSelect(surgeon)}>
                            Book Consultation
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}

        {step === "consult" && selectedSurgery && selectedSurgeon && (
          <>
            <h2 className="text-xl font-bold text-foreground mb-6">Book Surgery Consultation</h2>

            {/* Surgeon Details */}
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <div className="w-16 h-16 rounded-xl bg-secondary flex items-center justify-center flex-shrink-0">
                    <span className="text-xl font-bold text-primary">
                      {selectedSurgeon.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                    </span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-foreground">{selectedSurgeon.name}</h3>
                      {selectedSurgeon.verified && <Verified className="h-4 w-4 text-primary" />}
                    </div>
                    <p className="text-sm text-muted-foreground">{selectedSurgeon.specialty}</p>
                    <p className="text-sm text-muted-foreground">{selectedSurgeon.hospital}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Surgery Info */}
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Surgery Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <Scissors className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium text-foreground">{selectedSurgery.name}</p>
                    <p className="text-sm text-muted-foreground">
                      Estimated cost: Rs. {selectedSurgery.startingPrice.toLocaleString()} - {selectedSurgery.maxPrice.toLocaleString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Bill Details */}
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Consultation Fee</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Surgeon Consultation</span>
                  <span>Rs. {selectedSurgeon.consultationFee}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Platform Fee</span>
                  <span className="text-emerald-600">FREE</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="font-semibold">Total</span>
                  <span className="font-bold text-lg text-primary">Rs. {selectedSurgeon.consultationFee}</span>
                </div>
              </CardContent>
            </Card>

            {/* CareVia Promises */}
            <Card className="mb-6 bg-primary/5 border-primary/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  CareVia Surgery Assurance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>No hidden charges - transparent pricing</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Free cab for hospital visits</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Insurance & EMI assistance</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  <span>Dedicated care coordinator</span>
                </div>
              </CardContent>
            </Card>

            {/* WhatsApp Notification */}
            <div className="flex items-center gap-3 p-4 mb-6 bg-card rounded-xl border border-border">
              <Checkbox 
                id="whatsapp" 
                checked={whatsappNotify}
                onCheckedChange={(checked) => setWhatsappNotify(!!checked)}
              />
              <Label htmlFor="whatsapp" className="flex items-center gap-2 cursor-pointer">
                <MessageCircle className="h-5 w-5 text-emerald-500" />
                <span className="text-sm">Get surgery updates on WhatsApp</span>
              </Label>
            </div>

            {/* CTA Buttons */}
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1 gap-2">
                <Phone className="h-4 w-4" />
                Call Us
              </Button>
              <Button 
                className="flex-1"
                onClick={() => router.push("/surgeries/success")}
              >
                Book Consultation
              </Button>
            </div>
          </>
        )}
      </main>
    </div>
  )
}
