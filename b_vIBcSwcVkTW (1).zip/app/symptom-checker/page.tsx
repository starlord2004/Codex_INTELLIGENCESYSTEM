"use client"

import Link from "next/link"
import { ArrowLeft, Check, AlertCircle, FileText, ShoppingCart, Pill, PhoneCall } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { useState } from "react"
import { useRouter } from "next/navigation"

const commonSymptoms = [
  { id: "fever", label: "Fever" },
  { id: "cough", label: "Cough" },
  { id: "cold", label: "Cold/Runny Nose" },
  { id: "sore_throat", label: "Sore Throat" },
  { id: "headache", label: "Headache" },
  { id: "body_ache", label: "Body Ache" },
  { id: "fatigue", label: "Fatigue" },
  { id: "nausea", label: "Nausea/Vomiting" },
  { id: "diarrhea", label: "Diarrhea" },
  { id: "abdominal_pain", label: "Abdominal Pain" },
  { id: "chest_pain", label: "Chest Pain" },
  { id: "shortness_breath", label: "Shortness of Breath" },
  { id: "dizziness", label: "Dizziness" },
  { id: "rash", label: "Skin Rash" },
  { id: "joint_pain", label: "Joint Pain" },
  { id: "insomnia", label: "Insomnia" },
]

const diseaseDatabase: Record<string, {
  name: string
  description: string
  medicines: Array<{ name: string; price: number }>
  severity: "mild" | "moderate" | "severe"
  consultDoctor: boolean
  recommendedSpecialties: string[]
}> = {
  common_cold: {
    name: "Common Cold",
    description: "A viral infection affecting the upper respiratory tract, usually self-limiting within 7-10 days.",
    medicines: [
      { name: "Paracetamol 500mg", price: 45 },
      { name: "Cough Syrup", price: 120 },
      { name: "Vitamin C Supplement", price: 85 },
      { name: "Honey-Lemon Drink", price: 60 }
    ],
    severity: "mild",
    consultDoctor: false,
    recommendedSpecialties: ["General Physician", "ENT Specialist"],
  },
  flu: {
    name: "Influenza (Flu)",
    description: "A more severe viral infection that can cause systemic symptoms including fever, body aches, and fatigue.",
    medicines: [
      { name: "Oseltamivir (Tamiflu)", price: 280 },
      { name: "Ibuprofen 400mg", price: 65 },
      { name: "Antitussive", price: 140 },
      { name: "Electrolyte Drink", price: 80 }
    ],
    severity: "moderate",
    consultDoctor: true,
    recommendedSpecialties: ["General Physician", "Pulmonologist"],
  },
  gastroenteritis: {
    name: "Gastroenteritis",
    description: "An inflammation of the stomach and intestines, commonly called stomach flu or food poisoning.",
    medicines: [
      { name: "Loperamide", price: 50 },
      { name: "Omeprazole", price: 95 },
      { name: "Electrolyte Solution", price: 75 },
      { name: "Ginger Tea", price: 40 },
      { name: "Probiotics", price: 150 }
    ],
    severity: "moderate",
    consultDoctor: true,
    recommendedSpecialties: ["General Physician"],
  },
  migraine: {
    name: "Migraine",
    description: "A neurological condition characterized by intense, throbbing headaches often accompanied by nausea.",
    medicines: [
      { name: "Ibuprofen 400mg", price: 65 },
      { name: "Sumatriptan", price: 320 },
      { name: "Antimigraine Spray", price: 180 },
      { name: "Relaxation Aids", price: 200 }
    ],
    severity: "moderate",
    consultDoctor: true,
    recommendedSpecialties: ["Neurologist"],
  },
  sinusitis: {
    name: "Sinusitis",
    description: "Inflammation of the sinuses causing nasal congestion, sore throat, and headache.",
    medicines: [
      { name: "Nasal Decongestant", price: 110 },
      { name: "Antibiotics (Amoxicillin)", price: 140 },
      { name: "Saline Rinse", price: 95 },
      { name: "Ibuprofen", price: 65 }
    ],
    severity: "mild",
    consultDoctor: false,
    recommendedSpecialties: ["ENT Specialist"],
  },
  bronchitis: {
    name: "Bronchitis",
    description: "Inflammation of the bronchial tubes that carry air to the lungs, causing persistent cough.",
    medicines: [
      { name: "Cough Suppressant", price: 120 },
      { name: "Expectorant", price: 135 },
      { name: "Corticosteroid Inhaler", price: 450 },
      { name: "Antibiotics (if bacterial)", price: 160 }
    ],
    severity: "moderate",
    consultDoctor: true,
    recommendedSpecialties: ["Pulmonologist", "General Physician"],
  },
  angina: {
    name: "Angina",
    description: "Chest pain caused by reduced blood flow to the heart. Requires immediate medical attention.",
    medicines: [
      { name: "Nitroglycerin", price: 250 },
      { name: "Beta-blockers", price: 180 },
      { name: "Aspirin", price: 55 }
    ],
    severity: "severe",
    consultDoctor: true,
    recommendedSpecialties: ["Cardiologist"],
  },
  anxiety: {
    name: "Anxiety Disorder",
    description: "A mental health condition characterized by excessive worry, dizziness, and chest discomfort.",
    medicines: [
      { name: "SSRIs (Sertraline)", price: 120 },
      { name: "Anti-anxiety Medication", price: 95 },
      { name: "Valerian Root (Herbal)", price: 85 },
      { name: "Magnesium Supplement", price: 110 }
    ],
    severity: "moderate",
    consultDoctor: true,
    recommendedSpecialties: ["Psychiatry"],
  },
}

// All doctors with their specialties
const allDoctors = [
  { id: "dr-priya-patel", name: "Dr. Priya Patel", specialty: "General Physician", rating: 4.8, fee: 450 },
  { id: "dr-priya-sharma", name: "Dr. Priya Sharma", specialty: "Cardiologist", rating: 4.9, fee: 600 },
  { id: "dr-mahesh-verma", name: "Dr. Mahesh Verma", specialty: "Orthopedic", rating: 4.9, fee: 600 },
  { id: "dr-rajesh-nair", name: "Dr. Rajesh Nair", specialty: "ENT Specialist", rating: 4.8, fee: 550 },
  { id: "dr-suresh-nair", name: "Dr. Suresh Nair", specialty: "Pulmonologist", rating: 4.8, fee: 550 },
  { id: "dr-meera-nair", name: "Dr. Meera Nair", specialty: "Neurologist", rating: 4.8, fee: 700 },
  { id: "dr-deepak-patel", name: "Dr. Deepak Patel", specialty: "Cardiologist", rating: 4.8, fee: 650 },
  { id: "dr-sharma", name: "Dr. Amit Sharma", specialty: "General Physician", rating: 4.9, fee: 500 },
  { id: "dr-arun-sharma", name: "Dr. Arun Sharma", specialty: "Psychiatry", rating: 4.7, fee: 600 },
  { id: "dr-neha-gupta", name: "Dr. Neha Gupta", specialty: "Neurologist", rating: 4.8, fee: 700 },
]

export default function SymptomCheckerPage() {
  const router = useRouter()
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([])
  const [diagnosis, setDiagnosis] = useState<keyof typeof diseaseDatabase | null>(null)
  const [showResults, setShowResults] = useState(false)
  const [selectedMedicines, setSelectedMedicines] = useState<string[]>([])

  const handleSymptomChange = (symptomId: string) => {
    setSelectedSymptoms((prev) =>
      prev.includes(symptomId)
        ? prev.filter((s) => s !== symptomId)
        : [...prev, symptomId]
    )
  }

  const predictDisease = () => {
    if (selectedSymptoms.length === 0) return

    let predictedDisease: keyof typeof diseaseDatabase | null = null
    const symptomSet = new Set(selectedSymptoms)

    // Disease prediction logic based on symptoms
    if (
      symptomSet.has("chest_pain") &&
      (symptomSet.has("shortness_breath") || symptomSet.has("body_ache"))
    ) {
      predictedDisease = "angina"
    } else if (
      symptomSet.has("nausea") &&
      symptomSet.has("diarrhea") &&
      symptomSet.has("abdominal_pain")
    ) {
      predictedDisease = "gastroenteritis"
    } else if (
      symptomSet.has("headache") &&
      (symptomSet.has("nausea") || symptomSet.has("body_ache"))
    ) {
      predictedDisease = "migraine"
    } else if (
      symptomSet.has("cough") &&
      (symptomSet.has("cold") || symptomSet.has("sore_throat"))
    ) {
      predictedDisease = "bronchitis"
    } else if (
      symptomSet.has("dizziness") &&
      (symptomSet.has("chest_pain") || symptomSet.has("insomnia"))
    ) {
      predictedDisease = "anxiety"
    } else if (symptomSet.has("cold") || symptomSet.has("sore_throat")) {
      predictedDisease = "sinusitis"
    } else if (
      (symptomSet.has("fever") || symptomSet.has("cough")) &&
      (symptomSet.has("body_ache") || symptomSet.has("fatigue"))
    ) {
      predictedDisease = "flu"
    } else if (symptomSet.has("fever") || symptomSet.has("cough")) {
      predictedDisease = "common_cold"
    } else {
      predictedDisease = "common_cold"
    }

    setDiagnosis(predictedDisease)
    setShowResults(true)
    setSelectedMedicines([])
  }

  const getRecommendedDoctors = () => {
    if (!diagnosis) return []
    const disease = diseaseDatabase[diagnosis]
    return allDoctors.filter(doc =>
      disease.recommendedSpecialties.includes(doc.specialty)
    )
  }

  const handleOrderMedicines = () => {
    if (selectedMedicines.length === 0) {
      alert("Please select at least one medicine")
      return
    }
    // Navigate to medicines page with selected medicines
    const medicineNames = selectedMedicines.map(m => 
      diseaseDatabase[diagnosis!].medicines[parseInt(m)].name
    ).join(",")
    router.push(`/medicines?search=${encodeURIComponent(medicineNames)}`)
  }

  const handleBookAppointment = (doctorId: string) => {
    router.push(`/doctors/${doctorId}/book`)
  }

  if (showResults && diagnosis) {
    const disease = diseaseDatabase[diagnosis]
    const recommendedDoctors = getRecommendedDoctors()

    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur">
          <div className="container px-4 flex h-16 items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              className="gap-2"
              onClick={() => {
                setShowResults(false)
                setDiagnosis(null)
                setSelectedSymptoms([])
              }}
            >
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
            <div className="flex-1">
              <h1 className="text-xl font-bold">Diagnosis Results</h1>
            </div>
          </div>
        </header>

        <main className="container px-4 py-8">
          {/* Diagnosis Card */}
          <Card className="mb-8 border-2 border-primary/30 bg-gradient-to-br from-primary/5 to-primary/0">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-2xl mb-2">{disease.name}</CardTitle>
                  <div className="flex items-center gap-2">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      disease.severity === "mild" ? "bg-green-100 text-green-800" :
                      disease.severity === "moderate" ? "bg-yellow-100 text-yellow-800" :
                      "bg-red-100 text-red-800"
                    }`}>
                      {disease.severity.charAt(0).toUpperCase() + disease.severity.slice(1)} Severity
                    </span>
                  </div>
                </div>
                <AlertCircle className={`h-8 w-8 ${
                  disease.severity === "mild" ? "text-green-600" :
                  disease.severity === "moderate" ? "text-yellow-600" :
                  "text-red-600"
                }`} />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground break-words">{disease.description}</p>
              {disease.severity === "severe" && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-sm font-semibold text-red-900">⚠️ Important: This condition requires immediate medical attention. Please consult a doctor immediately.</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Medicines Section */}
          <div className="mb-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Pill className="h-5 w-5" />
                  Recommended Medicines
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {disease.medicines.map((medicine, idx) => (
                    <label key={idx} className="flex items-center gap-3 p-3 border rounded-lg hover:bg-secondary/50 cursor-pointer">
                      <Checkbox
                        checked={selectedMedicines.includes(idx.toString())}
                        onCheckedChange={() => {
                          setSelectedMedicines(prev =>
                            prev.includes(idx.toString())
                              ? prev.filter(m => m !== idx.toString())
                              : [...prev, idx.toString()]
                          )
                        }}
                      />
                      <div className="flex-1">
                        <p className="font-medium">{medicine.name}</p>
                      </div>
                      <span className="text-primary font-semibold">₹{medicine.price}</span>
                    </label>
                  ))}
                </div>
                <Button
                  className="w-full mt-4"
                  onClick={handleOrderMedicines}
                  disabled={selectedMedicines.length === 0}
                >
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Order Selected Medicines ({selectedMedicines.length})
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Recommended Doctors Section */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PhoneCall className="h-5 w-5" />
                  Recommended Doctors
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recommendedDoctors.length > 0 ? (
                    recommendedDoctors.map((doctor) => (
                      <div key={doctor.id} className="p-4 border rounded-lg hover:border-primary/50 transition">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <p className="font-semibold">{doctor.name}</p>
                            <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center gap-1 text-sm font-semibold text-amber-500">
                              ⭐ {doctor.rating}
                            </div>
                            <p className="text-sm text-muted-foreground">₹{doctor.fee} consultation</p>
                          </div>
                        </div>
                        <Button
                          className="w-full"
                          onClick={() => handleBookAppointment(doctor.id)}
                        >
                          Book Appointment
                        </Button>
                      </div>
                    ))
                  ) : (
                    <p className="text-muted-foreground text-center py-8">No doctors available for this condition</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur">
        <div className="container px-4 flex h-16 items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold">Symptom Checker</h1>
            <p className="text-sm text-muted-foreground">AI-powered disease prediction</p>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8">
        {/* Hero Section */}
        <div className="mb-12 p-8 bg-gradient-to-r from-primary/10 to-primary/5 rounded-xl border border-primary/20">
          <h2 className="text-2xl font-bold mb-2">Check Your Symptoms</h2>
          <p className="text-muted-foreground break-words">
            Select your symptoms below and our AI will help identify possible conditions. This is not a substitute for professional medical advice.
          </p>
        </div>

        {/* Symptoms Selection */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Select Your Symptoms</CardTitle>
            <p className="text-sm text-muted-foreground mt-2">Choose all symptoms you are experiencing</p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {commonSymptoms.map((symptom) => (
                <label key={symptom.id} className="flex items-center gap-3 p-3 border rounded-lg hover:bg-secondary/50 cursor-pointer transition">
                  <Checkbox
                    checked={selectedSymptoms.includes(symptom.id)}
                    onCheckedChange={() => handleSymptomChange(symptom.id)}
                  />
                  <span className="font-medium break-words">{symptom.label}</span>
                </label>
              ))}
            </div>

            {selectedSymptoms.length > 0 && (
              <div className="mt-6 pt-6 border-t">
                <p className="text-sm text-muted-foreground mb-4">
                  Selected symptoms: {selectedSymptoms.length}
                </p>
                <Button
                  className="w-full"
                  size="lg"
                  onClick={predictDisease}
                >
                  <Check className="h-5 w-5 mr-2" />
                  Get AI Diagnosis
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Information */}
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-blue-900 mb-1">Disclaimer</p>
                <p className="text-sm text-blue-800 break-words">
                  This symptom checker is for informational purposes only. It is not a substitute for professional medical advice, diagnosis, or treatment. Always consult with a healthcare professional for proper medical guidance.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
